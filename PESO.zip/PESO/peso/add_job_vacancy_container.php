<?php
$query = "SELECT * FROM ps_employer_registry ORDER BY em_company_name ASC";
$fetch= mysql_query($query) or die(mysql_errno());
?>
 <div class="container shadow col-md-10 col-md-offset-1 ">

<div class="col-md-12">
<?php
  if(isset($_SESSION['result'])){
    echo $_SESSION['result'];
    unset($_SESSION['result']);
  }
?>
</div>

 <form method="post" action="add_job_vacancy_form.php" enctype="multipart/form-data">
       
          <div class="form-group">
                  <label for="inputForEmployer">Company Name:</label>
                  <select id="inputForEmployer" class="form-control" name="employer">                 
              <option value="default" selected="selected">--SELECT--</option>
              <?php while($row = mysql_fetch_array($fetch)) { ?>
              <option value="<?php echo $row['em_company_name']?>"><?php echo $row['em_company_name']?></option>
              <?php } ?>
              </select>
            </div>

<div class= "form-group">
<label for="inputForVacancy">Job Vacancy:</label>
   <div>      
      <input type="text" class="form-control" id="inputForVacancy" placeholder="Job Vacancy" name="vacancy" autocomplete="off" required="true">
   </div>
</div>

            <div class="form-group">
                  <label for="inputForNoVacancy">Number of Available Vacant:</label>
              <div>      
                <input type="text" class="form-control" id="inputForNoVacancy" placeholder="Number of Available Vacant" name="novacancy" autocomplete="off" required="true"> 
             </div>        
            </div>
            
            <div class="form-group">
                  <label for="gender">Gender:</label>
                  <div class="btn-group" data-toggle="buttons">
                  <label class="btn btn-primary btn-enhance-primary">
                  <input type="radio" name="gender" value="Male" id="gender">&nbsp;Male&nbsp;&nbsp;
                  </label>
                  <label class="btn btn-primary btn-enhance-primary">
                  <input type="radio" name="gender" value="Female" id="gender">&nbsp;Female&nbsp;&nbsp;
                  </label>
                  <label class="btn btn-primary btn-enhance-primary">
                  <input type="radio" name="gender" value="Male & Female" id="gender">&nbsp;Male & Female
                  </label>
                  </div>
            </div>
            <div class="form-group col-md-3">
                  <label for="inputDatePosting">Date of Posting</label>
                  <input type="text" class="form-control datepicker" id="inputDatePosting" placeholder="mm/dd/yyyy" name="dateposting" autocomplete="off" required>
            </div>
            <div class="form-group col-md-3">
                  <label for="inputForStatus">Status</label>
                  <input type="text" class="form-control" id="inputForStatus" placeholder="Status" name="status" autocomplete="off" required>
            </div>
            <div class="form-group col-md-3">
                  <label for="inputForDate">Date</label>
                  <input type="text" class="form-control datepicker" id="inputForDate" placeholder="mm/dd/yyyy" name="date" autocomplete="off" required>
            </div>

            <br>
            <br>
            <br>
            <br>
            <br>

            <div class= "form-group">
            <input class="btn btn-success save col-xs-3 col-xs-offset-4 col-sm-2 col-sm-offset-5 col-md-2 col-md-offset-5" type="submit" value="Save">
            </div>

            <br>
            <br>
        
    </form>
</div>