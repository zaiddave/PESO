<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/DataTables-1.10.12/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<link href="assets/ie10-viewport-bug-workaround.css" rel="stylesheet">


<link href="assets/style.css" rel="stylesheet">


<link href="bootstrap/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet">
<!--custom jquery ui min css for the calendar display in inputy text -->
<link href="assets/jquery-ui-1.11.4.custom/jquery-ui.min.css" rel="stylesheet">
<!--Datatables css-->
<link href="assets/DataTables-1.10.12/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="assets/DataTables-1.10.12/css/buttons.dataTables.min.css" rel="stylesheet" >

<script src="bootstrap/js/jquery.min.js"  type="text/javascript"></script>
<!--custom jquery ui min js for the calendar display in inputy text -->
<script src="assets/jquery-ui-1.11.4.custom/jquery-ui.min.js"  type="text/javascript"></script>
<script src="bootstrap/js/bootstrap.min.js"  type="text/javascript" ></script>

<script src="assets/DataTables-1.10.12/js/jquery.dataTables.bootstrap.min.js"  type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/dataTables.bootstrap.min.js"  type="text/javascript" ></script>


<!--Datatables script responsible for adding print functionality-->
<script src="assets/DataTables-1.10.12/js/jquery.dataTables.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/dataTables.buttons.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/buttons.flash.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/jszip.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/pdfmake.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/vfs_fonts.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/buttons.html5.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/buttons.print.min.js" type="text/javascript" ></script>