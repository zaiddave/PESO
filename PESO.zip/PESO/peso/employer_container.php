 <div class="container shadow col-md-10 col-md-offset-1">

<div class="col-sm-12">
  <?php
  if(isset($_SESSION['result'])){
    echo $_SESSION['result'];
    unset($_SESSION['result']);
  }
  ?>
</div>

 <form class="form-horizontal" action="employer_form.php" method="post" enctype="multipart/form-data">
 
<div class="form-group">
    <label for="type" class="text-color-2 col-sm-2 control-label">Type of Employment:</label>
    <div class="col-sm-10">
      <select class="form-control" id="type" name="type" required>
        <option value="default" selected="selected">--SELECT--</option>
        <option value="POEA Licensed Agencies">POEA Licensed Agencies</option>
        <option value="LOCAL Companies">LOCAL Companies</option>
        <option value="BPO Companies">BPO Companies</option>
      </select>
    </div>
</div>

  <div class="form-group">
    <label for="company" class="text-color-2 col-sm-2 control-label">Company Name:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="company" placeholder="Employer/Company Name" name="company" autocomplete="off" required="true">
    </div>
  </div>

  <div class="form-group">  
  <label for="checkbox1" class="text-color-2 col-sm-2 control-label">Business Requirements:</label>&nbsp;&nbsp;&nbsp;
  <div class="btn-group" data-toggle="buttons">
  <a data-toggle="tooltip" data-placement="top" title="Select 1 or more of these options.">
  <label class="btn btn-primary btn-enhance-primary">
    <input type="checkbox" name="business" value="Business Permit (DTI)">  Business Permit (DTI) &nbsp;&nbsp;
  </label>    
  <label class="btn btn-primary btn-enhance-primary">
    <input type="checkbox" name="mayor" value="Mayor's Permit"> Mayor's Permit &nbsp;&nbsp;
  </label>    
  <label class="btn btn-primary btn-enhance-primary">
    <input type="checkbox" name="bir" value="BIR/SEC Registration"> BIR/SEC Registration
  </label>    
  </a>
  </div>
  </div>


<div class= "form-group">
  <label for="representative" class="text-color-2 col-sm-2 control-label">Official Representative:</label>
   <div class="col-sm-10">
      <textarea rows="2" class="form-control" id="representative" placeholder="Official Representative" name="representative" ></textarea>
    </div>

</div> 

<div class= "form-group">
  <label for="designation" class="text-color-2 col-sm-2 control-label">Designation:</label>
   <div class="col-sm-10">
      <textarea rows="2" class="form-control" id="designation" placeholder="Designation" name="designation"></textarea>
    </div>
</div> 



<div class= "form-group">
  <label for="contact" class="text-color-2 col-sm-2 control-label">Contact Details:</label>
  <label for="telephone" class="text-color-2 col-sm-2 control-label">Company No.:</label>
   <div class="col-sm-4"> 
      <textarea rows="2" class="form-control" id="telephone" placeholder="Company No." name="telephone"></textarea>
    </div>        
</div> 

<div class= "form-group">
<label for="cell" class="col-md-offset-2 text-color-2 col-sm-2 control-label">Cellphone No.:</label>
   <div class="col-sm-4 ">      
      <textarea rows="2" class="form-control" id="cellphone" placeholder="Cellphone No." name="cell"></textarea>
   </div>
</div>

<div class= "form-group">
<label for="email" class="col-md-offset-2 text-color-2 col-sm-2 control-label">Email Address:</label>
   <div class="col-sm-4 ">
      <textarea rows="2" class="form-control" id="email" placeholder="Email Address" name="email"></textarea>      
    </div>
</div>


<br>
<div class= "form-group">
<input class="btn btn-success save col-xs-3 col-xs-offset-4 col-sm-2 col-sm-offset-5 col-md-2 col-md-offset-5" type="submit" value="Save">

</div>
</form>
</div>