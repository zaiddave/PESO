<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>SRA Summary Report</b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>
	                    <table id="table" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">									
									<th rowspan="2"><center>Date</center></th>
									<th rowspan="2"><center>Venue</center></th>
									<th colspan="3"><center>Registrants</center></th>									
									<th rowspan="2"><center>Qualified</center></th>
									<th rowspan="2"><center>HOTS</center></th>
								</tr>								
								<tr>
									<td class="head-kulay"><center>Total</center></td>
									<td class="head-kulay"><center>Male</center></td>
									<td class="head-kulay"><center>Female</center></td>
								</tr>
							</thead>
							<tbody>								
								<?php
										$fetch = mysql_query("SELECT DISTINCT j_type, j_year FROM ps_job_interview_form WHERE j_type = 'SRA' ORDER BY j_year DESC");
										while($row = mysql_fetch_array($fetch)){
										$type = mysql_real_escape_string($row['j_type']);
										$year = mysql_real_escape_string($row['j_year']);
								?>
								<tr>
									<td class="job-fair-year">
										<?php echo "<h3><center><b> ".$row['j_type']." ".$row['j_year']." </b></center></h3>";?>
									</td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr>
									<?php
										$fetch1 = mysql_query("SELECT DISTINCT j_date, j_venue FROM ps_job_interview_form WHERE j_type = '$type' && j_year = '$year' ORDER BY j_date DESC");
										while($row1 = mysql_fetch_array($fetch1)){
										$venue = mysql_real_escape_string($row1['j_venue']);
										$date = mysql_real_escape_string($row1['j_date']);
										?>
									<td class="job-fair"><center><?php echo $row1['j_date']?></center></td>
									<td class="job-fair"><center><?php echo $row1['j_venue']?></center></td>
									<td class="job-fair"><center><?php
									$total = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_type = '$type' && j_year = '$year' && j_date = '$date' && j_venue = '$venue' ");
									echo mysql_num_rows($total);
									?></center></td>
									<td  class="job-fair"><center><?php
									$totalMale = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_type = '$type' && j_year = '$year' && j_date = '$date' && j_venue = '$venue' && j_gender = 'Male' ");
									echo mysql_num_rows($totalMale);
									?></center></td>
									<td class="job-fair"><center><?php
									$totalFemale = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_type = '$type' && j_year = '$year' && j_date = '$date' && j_venue = '$venue' && j_gender = 'Female' ");
									echo mysql_num_rows($totalFemale);
									?></center></td>
									<td class="job-fair"><center><?php
									$totalQualified = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_type = '$type' && j_year = '$year' && j_date = '$date' && j_venue = '$venue' && j_status = 'Qualified' ");
									echo mysql_num_rows($totalQualified);
									?></center></td>
									<td class="job-fair"><center><?php
									$totalHOTS = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_type = '$type' && j_year = '$year' && j_date = '$date' && j_venue = '$venue' && j_status = 'HOTS' ");
									echo mysql_num_rows($totalHOTS);
									?></center></td>
								</tr>
								<?php } ?>
								<?php } ?>
						
							</tbody>
						</table>
                  </div>
                </div>