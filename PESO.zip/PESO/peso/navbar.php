<nav class="navbar navbar-custom navbar-fixed-top " role="navigation">
  <div class="container-fluid ">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php" >
        <span><img src="images/peso.png" alt="PESO" height="25px" width="25px" style="margin-top: -7px;"></span>
        PESO
      </a>
    </div>
    <div>
    <div class="collapse navbar-collapse" id="navbar-collapse"> 
      <p class="navbar-text navbar-left" id="ct"></p>
      <ul class="nav navbar-nav navbar-right">
        <li> 
            <div class="btn-group custom-btn-group" role="group">
              <button type="button" class="btn btn-primary custom-btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span class="glyphicon glyphicon-file" aria-hidden="true"></span> Report
                <span class="caret"></span>
                <span class="sr-only">Toggle Dropdown</span>
              </button>
              <ul class="dropdown-menu custom">
                <li><a href="employer_report.php"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> Company & Job Available</a></li>
                <li><a href="applicant_report.php"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> Applicant</a></li>                
                <li role="separator" class="divider"></li>
                <li><a href="qualified_report.php"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> Qualified</a></li>
                <li><a href="not_qualified_report.php"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> Not Qualified</a></li>
                <li><a href="ffi_report.php"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> FFI</a></li>
                <li><a href="hots_report.php"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> HOTS</a></li>
              </ul>
            </div>             
        </li>

        <li> 
            <div class="btn-group custom-btn-group" role="group">
              <button type="button" class="btn btn-primary custom-btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span> Manage
                <span class="caret"></span>
                <span class="sr-only">Toggle Dropdown</span>
              </button>
              <ul class="dropdown-menu custom">
                <li><a href="employer_manage.php"><span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span> Company & Job Available</a></li>
                <li><a href="applicant_manage.php"><span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span> Applicant</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="qualified_manage.php"><span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span> Qualified</a></li>
                <li><a href="not_qualified_manage.php"><span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span> Not Qualified</a></li>
                <li><a href="ffi_manage.php"><span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span> FFI</a></li>
                <li><a href="hots_manage.php"><span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span> HOTS</a></li>                
              </ul>
            </div>             
        </li>        
        <li> 
            <div class="btn-group custom-btn-group" role="group">
              <button type="button" class="btn btn-primary custom-btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Total
                <span class="caret"></span>
                <span class="sr-only">Toggle Dropdown</span>
              </button>
              <ul class="dropdown-menu custom">
                <li><a href="general_total.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Job Interview General Report</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="qualified_total.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Qualified</a></li>
                <li><a href="not_qualified_total.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Not Qualified</a></li>
                <li><a href="ffi_total.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> FFI</a></li>
                <li><a href="hots_total.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> HOTS</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="overseas_total.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Overseas</a></li>
                <li><a href="bpo_total_report.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> BPO Companies</a></li>
                <li><a href="local_total_report.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Local Companies</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="job_fair.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Job Fair</a></li>
                <li><a href="job_sra.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> SRA</a></li>
                <li><a href="job_lra.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> LRA</a></li>
              </ul>
            </div>             
        </li>
        <li> 
            <div class="btn-group custom-btn-group" role="group">
              <button type="button" class="btn btn-primary custom-btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span class="glyphicon glyphicon-file" aria-hidden="true"></span> SPES
                <span class="caret"></span>
                <span class="sr-only">Toggle Dropdown</span>
              </button>
              <ul class="dropdown-menu custom">
                <li><a href="spes_report_general.php"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> SPES General Report</a></li>
                <li><a href="spes_report_generated.php"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> SPES Generated Report</a></li>
                <li><a href="spes_report.php"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> SPES Overview</a></li></ul>
            </div>             
        </li>
    </ul>
    </div>
    </div>
  </div>
</nav>