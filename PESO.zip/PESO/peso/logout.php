<?php
session_start();
unset($_SESSION['fname']);
unset($_SESSION['mname']);
unset($_SESSION['lname']);
unset($_SESSION['user']);
unset($_SESSION['type']);
unset($_SESSION['$queryAvail']);
unset($_SESSION['$queryYear']);
unset($_SESSION['$queryBatch']);
unset($_SESSION['$queryEdu']);
unset($_SESSION['$avail']);
session_write_close();
header("location: login.php");

 ?>