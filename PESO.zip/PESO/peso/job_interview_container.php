<div class="container shadow col-md-10 col-md-offset-1">


<div class="col-md-12">
<?php
if(isset($_SESSION['result1'])){
  echo $_SESSION['result1'];
  unset($_SESSION['result1']);
}
?>
</div>

<br>

 <form class="form-horizontal" action="job_interview_form.php" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label for="company" class="text-color-2 col-sm-2 control-label">Applicant Name:</label>
    <div class="col-sm-3">
      <input type="text" class="form-control" id="fname" placeholder="First Name" name="fname" autocomplete="off" required>
    </div>
    <div class="col-sm-3">
      <input type="text" class="form-control" id="mname" placeholder="Middle Name" name="mname" autocomplete="off">
    </div>
    <div class="col-sm-3">
      <input type="text" class="form-control" id="lname" placeholder="Last Name" name="lname" autocomplete="off" required>
    </div>
  </div>  

  <div class="form-group">
    <label for="position" class="text-color-2 col-sm-2 control-label">Position Applied For:</label>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="position" placeholder="Position" name="position" autocomplete="off" required>
    </div>
  </div>

<div class="form-group">
    <label for="gender" class="text-color-2 col-sm-2 control-label">Gender:</label>
        <div class="col-sm-10" style="padding-top:6px;">
        <div class="btn-group" data-toggle="buttons">
        <label class="btn btn-primary btn-enhance-primary">
          <input type="radio" name="gender" value="Male" id="gender" required>&nbsp;Male
        </label>
        <label class="btn btn-primary btn-enhance-primary">
          <input type="radio" name="gender" value="Female" id="gender" required>&nbsp;Female
        </label>
        </div>
        </div>
</div>


<div class="form-group">
    <label for="company" class="text-color-2 col-sm-2 control-label">Age:</label>
    <div class="col-sm-2">
      <input type="text" class="form-control" id="fname" placeholder="Age" autocomplete="off" name="age">
  </div>
</div>

<div class= "form-group">
   <label for="cell" class="text-color-2 col-sm-2 control-label">Cellphone No.:</label>
   <div class="col-sm-4 ">
   <textarea rows="2" class="form-control" id="cell" placeholder="Cellphone No." name="cell" ></textarea>      
   </div>
</div> 

<div class="form-group">
    <label for="address" class="text-color-2 col-sm-2 control-label">Address:</label>
    <div class="col-sm-10">      
      <textarea rows="2" class="form-control" id="address" placeholder="Address" name="address" required></textarea>      
    </div>
</div>

<div class="form-group">
    <label for="sponsor" class="text-color-2 col-sm-2 control-label">Sponsor/Organizer:</label>
    <div class="col-sm-10">      
     <input type="text" class="form-control" id="sponsor" placeholder="Name of Sponsor/Organizer" autocomplete="off" name="sponsor">
    </div>
</div>

<div class="form-group">
    <label for="venue" class="text-color-2 col-sm-2 control-label">Venue:</label>
    <div class="col-sm-6">      
    <input type="text" class="form-control typeahead tt-query" id="auto_venue" placeholder="Venue" name="venue" autocomplete="off" spellcheck="off">
    </div>
</div>

<div class="form-group">
    <label for="recruitment" class="text-color-2 col-sm-2 control-label">Recruitment Type:</label>
    <div class="col-sm-2">      
      <select class="form-control" id="ryear" name="ryear" required>
        <option value="default" selected="selected">Select Year</option>
        <?php 
        for ($i=2000; $i <=2100 ; $i++) { 
          echo "<option value='$i'>$i</option>";
        }
        ?>        
      </select>
    </div>    
    <div class="col-sm-2">
    <select class="form-control" id="rmonth" name="rmonth" required>
        <option value="default" selected="selected">Select Month</option>
        <option value="January">January</option>
        <option value="February">February</option>
        <option value="March">March</option>
        <option value="April">April</option>
        <option value="May">May</option>
        <option value="June">June</option>
        <option value="July">July</option>
        <option value="August">August</option>
        <option value="September">September</option>
        <option value="October">October</option>
        <option value="November">November</option>
        <option value="December">December</option>
      </select>
    </div>
    <div class="col-sm-2">
      <select class="form-control" id="recruitment" name="recruitment" required>
        <option value="default" selected="selected">Select Type</option>
        <option value="Job Fair">Job Fair</option>
        <option value="SRA">SRA</option> 
        <option value="LRA">LRA</option>             
      </select>
    </div>    
</div>

<div class="form-group">
    <label for="date" class="text-color-2 col-sm-2 control-label">Date:</label>
    <div class="col-sm-6">
      <input type="text" class="form-control datepicker" id="date" placeholder="Activity Date" name="date" autocomplete="off" required>
    </div>
  </div>

  <div class="form-group">
    <label for="company" class="text-color-2 col-sm-2 control-label">Name of Company:</label>
    <div class="col-sm-6">
    <input type="text" class="form-control typeahead tt-query" id="auto_company" placeholder="Company Name" name="company" autocomplete="off" spellcheck="off">
    </div>
  </div>

  <div class="form-group">
    <label for="employmentType" class="text-color-2 col-sm-2 control-label">Employment Type:</label>
    <div class="col-sm-6">
    <select class="form-control" id="employmentType" name="employmentType" required>
        <option value="default" selected="selected">--SELECT--</option>
        <option value="POEA Licensed Agencies">POEA Licensed Agencies</option>
        <option value="LOCAL Companies">LOCAL Companies</option>
        <option value="BPO Companies">BPO Companies</option>        
      </select>
    </div>
  </div>

  <div class="form-group">
    <label for="status" class="text-color-2 col-sm-2 control-label">Status:</label>
        <div class="col-sm-10" style="padding-top:6px;">
        <div class="btn-group" data-toggle="buttons">
        <label class="btn btn-warning btn-enhance-warning">
          <input type="radio" name="status" value="Qualified" id="status" required>&nbsp;Qualified
        </label>
        <label class="btn btn-warning btn-enhance-warning">
          <input type="radio" name="status" value="Not Qualified" id="status" required>&nbsp;Not Qualified
        </label>
        <label class="btn btn-warning btn-enhance-warning">
          <input type="radio" name="status" value="FFI" id="status" required>&nbsp;FFI
        </label>
        <label class="btn btn-warning btn-enhance-warning">
          <input type="radio" name="status" value="HOTS" id="status" required>&nbsp;HOTS
        </label>
        </div>
        </div>
  </div> 
<br>
<div class= "form-group">
<input class="btn btn-success save col-xs-3 col-xs-offset-4 col-sm-2 col-sm-offset-5 col-md-2 col-md-offset-5" type="submit" value="Save">
</div>
<p><small><b>*</b>Consider that all information encoded are correct before submitting. Informations such as <b>Recruitment Type</b> and <b>Date</b> won't be editted in the Manage Section under the Report Category otherwise you'll have to delete the incorrect submitted data and register them again.</small></p>

</form>
</div>
</div>