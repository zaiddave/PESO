<?
$fetch = mysql_query("SELECT * FROM ps_login WHERE l_fname = 'Sharon'");
$row= mysql_fetch_array($fetch);

$fetch1 = mysql_query("SELECT * FROM ps_login WHERE l_id = '3'");
$row1= mysql_fetch_array($fetch1);


$fetch2 = mysql_query("SELECT * FROM ps_login WHERE l_id = '4'");
$row2= mysql_fetch_array($fetch2);
?>
<div id="official" class="tab-pane fade in active">
  
  <div class="panel-group">
  <div class="panel panel-primary">
    <div class="panel-heading">
        <p><b>Name:</b> <? echo $row['l_fname']. ' '.$row['l_mname'].' '.$row['l_lname']?> <button class="btn btn-info btn-update pull-right" name="update" data-toggle="modal" data-target="#official_update"
        data-id="<? echo $row['l_id']?>"
        data-id1="<? echo $row1['l_id']?>"
        data-id2="<? echo $row2['l_id']?>"
        data-fname="<? echo $row['l_fname']?>"
        data-mname="<? echo $row['l_mname']?>"
        data-lname="<? echo $row['l_lname']?>"
        data-desig="<? echo $row['l_desig']?>"
        data-email="<? echo $row['l_email']?>"        
        data-con="<? echo $row['l_con']?>"
        data-img="<? echo $row['l_image']?>"
        data-gfname="<? echo $row1['l_fname']?>"
        data-gmname="<? echo $row1['l_mname']?>"
        data-glname="<? echo $row1['l_lname']?>"
        data-mfname="<? echo $row2['l_fname']?>"
        data-mmname="<? echo $row2['l_mname']?>"
        data-mlname="<? echo $row2['l_lname']?>"
        ><span class="glyphicon glyphicon-edit"></span> Update Personal Information</button></p>
    </div>
    <div class="panel-body">
      <br>      
      <div class="col-md-3">
          <img src="<? echo $row['l_image']?>" class="img-responsive img-thumbnail center-block" height="250px" width="200px" alt="No Image">
      </div>

      <div class="col-md-8 col-md-offset-1">
      	  <div class="row">
            <div class="col-md-2">
              <p><b>Designation:</b><p>
            </div>
            <div class="col-md-10">
              <p><? echo $row['l_desig']?></p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>Contact:</b><p>
            </div>
            <div class="col-md-10">
              <p><? echo $row['l_con']?></p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>Username:</b><p>
            </div>
            <div class="col-md-10">
              <p><? echo $row['l_username']?></p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>Email:</b><p>
            </div>
            <div class="col-md-10">
              <p><? echo $row['l_email']?></p>
            </div>
          </div>          
          <div class="row">
            <div class="col-md-2">
              <p><b>Provincial Governor:</b><p>
            </div>
            <div class="col-md-10">
              <p><? echo $row1['l_fname'].' '.$row1['l_mname'].' '.$row1['l_lname']?></p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>PESO Neg. Occ. Manager:</b><p>
            </div>
            <div class="col-md-10">
              <p><? echo $row2['l_fname'].' '.$row2['l_mname'].' '.$row2['l_lname']?></p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>Last Login:</b><p>
            </div>
            <div class="col-md-10">
              <p><? echo $row['l_time']?></p>
            </div>
          </div>
      </div>
      <div class="row col-md-12">
        <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseUpdate" aria-expanded="false" aria-controls="collapseExample"><span class="glyphicon glyphicon-edit"></span> Change Username and Password</button>
            <div class="collapse" id="collapseUpdate">
              <div class="well">                   
                <form class="form-horizontal" method="post" action="admin_official_password.php?id=<?php echo $row['l_id']?>" enctype="multipart/form-data">                 
                    <div class="form-group">        
                        <label for="user" class="text-color-2 col-sm-2 control-label">Username:</label>
                        <div class="col-md-3">
                        <input type="text" class="form-control" id="user" placeholder="Username" name="user" autocomplete="off" value="<?php echo $row['l_username']?>" >
                        </div>
                        <label for="prev" class="text-color-2 col-sm-2 control-label">Previous Password:</label>
                        <div class="col-md-3">      
                        <input type="password" class="form-control" id="prev" placeholder="Type Your Previous Password" name="prev" autocomplete="off" required> 
                        </div>            
                    </div>
                    <div class="form-group">
                      <label for="pass" class="text-color-2 col-sm-2 control-label">New Password:</label>
                        <div class="col-md-3">      
                        <input type="password" class="form-control" id="pass" placeholder="Password" name="pass" autocomplete="off" required> 
                        </div>
                        <label for="confirm" class="text-color-2 col-sm-2 control-label">Confirm Password:</label>
                        <div class="col-md-3">      
                        <input type="password" class="form-control" id="confirm" placeholder="Confirm Password" name="confirm" autocomplete="off" required> 
                        </div>
                    </div>
                    <button class="btn btn-info btn-update" type="submit" ><span class="glyphicon glyphicon-edit"></span> Save changes</button>
                    </form>
              </div>
            </div>
            </div>
    </div><!--panel body-->
    </div><!--panel-->
  </div><!--panel group-->
</div><!-- tab pane fade-->