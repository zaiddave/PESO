
	                    <table id="job_table" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Company Name</th>
									<th>Job Vacancy</th>
									<th>Number of Vacant</th>
									<th>Gender</th>
									<th>Date Posted</th>
									<th>Status</th>
									<th>Date</th>
								</tr>
							</thead>
							<tbody>
							<?php 																		
									$fetch = mysql_query("SELECT DISTINCT em_company_name FROM ps_vacancy ORDER BY em_company_name ASC ") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                					$name = mysql_real_escape_string($row['em_company_name']);
                  			?>
								<tr>
									<td class="job-fair-year"><?php echo $row['em_company_name'] ?></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
								</tr>
								<tr>
								<?php 																		
									$fetch1 = mysql_query("SELECT * FROM ps_vacancy WHERE em_company_name = '$name' ") or die(mysql_error());
                					while($row1 = mysql_fetch_array($fetch1)){
                  				?>
									<td></td>
									<td class="job-fair"><?php echo nl2br($row1['vac_vacancy']."\n") ?></td>
									<td class="job-fair"><?php echo nl2br($row1['vac_no_of_vacancy']."\n") ?></td>
									<td class="job-fair"><?php echo $row1['vac_gender'] ?></td>
									<td class="job-fair"><?php echo $row1['vac_date_posting'] ?></td>
									<td class="job-fair"><?php echo $row1['vac_status'] ?></td>
									<td class="job-fair"><?php echo $row1['vac_date'] ?></td>
								</tr>
								<?php } ?>
								<?php } ?>
							</tbody>
						</table>
                  