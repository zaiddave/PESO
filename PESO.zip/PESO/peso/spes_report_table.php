<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>SPES Overview Report Table</b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <?if(isset($_SESSION['result'])){
                  	echo $_SESSION['result'];
                  	unset($_SESSION['result']);
                  	}?>
                  <br><br>

	                    <table id="table0" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr>									
									<th rowspan="4" class="report-date"><center>NAME</center></th>
									<th rowspan="4" class="report-date"><center>LGU</center></th>
									<th rowspan="4" class="report-date"><center>GENDER</center></th>
									<th colspan="24" class="report-date"><center>YEAR OF AVAILMENT</center></th>
									<th rowspan="4" class="report-date"><center>SPES BABY</center></th>
									<th rowspan="4" class="report-date"><center>Manage</center></th>
								</tr>
								<tr>
									<th colspan="8" class="report-employment"><center>1st</center></th>
									<th colspan="8" class="report-employment"><center>2nd</center></th>
									<th colspan="8" class="report-employment"><center>3rd</center></th>									
								</tr>
								<tr>
									<th colspan="2" class="report-company"><center>Batch 1</center></th>
									<th colspan="2" class="report-company"><center>Batch 2</center></th>
									<th colspan="2" class="report-company"><center>Batch 3</center></th>
									<th colspan="2" class="report-company"><center>Batch 4</center></th>
									<th colspan="2" class="report-company"><center>Batch 1</center></th>
									<th colspan="2" class="report-company"><center>Batch 2</center></th>
									<th colspan="2" class="report-company"><center>Batch 3</center></th>
									<th colspan="2" class="report-company"><center>Batch 4</center></th>
									<th colspan="2" class="report-company"><center>Batch 1</center></th>
									<th colspan="2" class="report-company"><center>Batch 2</center></th>
									<th colspan="2" class="report-company"><center>Batch 3</center></th>
									<th colspan="2" class="report-company"><center>Batch 4</center></th>
								</tr>
								<tr>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
									<th class="report-gender"><center>Year</center></th>
									<th class="report-status"><center>Grade</center></th>
								</tr>
							</thead>
							<tbody>
							<?
							$query = "SELECT * FROM ps_spes ORDER BY sp_lname ASC";
							$fetch = mysql_query($query);
							while($row = mysql_fetch_array($fetch)) {
							?>
								<tr>									
									<td class="job-fair"><center><? echo $row['sp_lname'].', '.$row['sp_fname'].' '.$row['sp_mname'] ?></center></td>
									<td class="job-fair"><center><? echo $row['sp_lgu'] ?></center></td>
									<td class="job-fair"><center><? echo $row['sp_gender'] ?></center></td>
									<td class="td-green"><center>
										<?
											if($row['sp_batch_first_year'] == "Batch 1"){
												echo $row['sp_first_year'];
											}
											else{
												echo "";
											}
										?>
									</center></th>
									<td class="td-green"><center>
										<?
											if($row['sp_batch_first_year'] == "Batch 1"){
												echo $row['sp_grade_first'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-green"><center>
										<?
											if($row['sp_batch_first_year'] == "Batch 2"){
												echo $row['sp_first_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-green"><center>
										<?
											if($row['sp_batch_first_year'] == "Batch 2"){
												echo $row['sp_grade_first'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-green"><center>
										<?
											if($row['sp_batch_first_year'] == "Batch 3"){
												echo $row['sp_first_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-green"><center>
										<?
											if($row['sp_batch_first_year'] == "Batch 3"){
												echo $row['sp_grade_first'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-green"><center>
										<?
											if($row['sp_batch_first_year'] == "Batch 4"){
												echo $row['sp_first_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-green"><center>
										<?
											if($row['sp_batch_first_year'] == "Batch 4"){
												echo $row['sp_grade_first'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-yellow"><center>
										<?
											if($row['sp_batch_second_year'] == "Batch 1"){
												echo $row['sp_second_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-yellow"><center>
										<?
											if($row['sp_batch_second_year'] == "Batch 1"){
												echo $row['sp_grade_second'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-yellow"><center>
										<?
											if($row['sp_batch_second_year'] == "Batch 2"){
												echo $row['sp_second_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-yellow"><center>
										<?
											if($row['sp_batch_second_year'] == "Batch 2"){
												echo $row['sp_grade_second'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-yellow"><center>
										<?
											if($row['sp_batch_second_year'] == "Batch 3"){
												echo $row['sp_second_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-yellow"><center>
										<?
											if($row['sp_batch_second_year'] == "Batch 3"){
												echo $row['sp_grade_second'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-yellow"><center>
										<?
											if($row['sp_batch_second_year'] == "Batch 4"){
												echo $row['sp_second_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-yellow"><center>
										<?
											if($row['sp_batch_second_year'] == "Batch 4"){
												echo $row['sp_grade_second'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-red"><center>
										<?
											if($row['sp_batch_third_year'] == "Batch 1"){
												echo $row['sp_third_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-red"><center>
										<?
											if($row['sp_batch_third_year'] == "Batch 1"){
												echo $row['sp_grade_third'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-red"><center>
										<?
											if($row['sp_batch_third_year'] == "Batch 2"){
												echo $row['sp_third_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>									
									<td class="td-red"><center>
										<?
											if($row['sp_batch_third_year'] == "Batch 2"){
												echo $row['sp_grade_third'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-red"><center>
										<?
											if($row['sp_batch_third_year'] == "Batch 3"){
												echo $row['sp_third_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>									
									<td class="td-red"><center>
										<?
											if($row['sp_batch_third_year'] == "Batch 3"){
												echo $row['sp_grade_third'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-red"><center>
										<?
											if($row['sp_batch_third_year'] == "Batch 4"){
												echo $row['sp_third_year'];
											}
											else{
												echo "";
											}
										?>
									</center></td>
									<td class="td-red"><center>
										<?
											if($row['sp_batch_third_year'] == "Batch 4"){
												echo $row['sp_grade_third'];
											}
											else{
												echo "";
											}
										?>
									</center></td>									
									<td class="job-fair"><center>										
										<?php if($row['sp_first_availment'] == 'First Availment' && $row['sp_second_availment'] != 'Not Yet Availed' && $row['sp_third_availment'] != 'Not Yet Availed'){ ?>
											<button type="button" data-toggle="modal" data-id="<?php echo $row['sp_id']?>" data-target="#certificate_year" class="btn btn-primary"><span class='glyphicon glyphicon-print'></span></button>

										<?php } ?>
									</center></td>
									<td class="job-fair"><center>
									<button type="button" class="btn btn-info" data-container="body" data-toggle="popover" data-html="true" data-placement="top" data-trigger="focus"
									data-content=" <button class='btn btn-primary' aria-label='Edit' data-toggle='modal' data-target='#spes_manage' data-id='<?php echo $row['sp_id']?>'><span class='glyphicon glyphicon-edit'></span></button>&nbsp;<button class='btn btn-danger' aria-label='Delete' data-toggle='modal' data-target='#delete_spes' data-id='<?php echo $row['sp_id']?>'><span class='glyphicon glyphicon-trash'></span></button>">
									Manage
									</button>
									</center></td>
								</tr>
							<? } ?>
							</tbody>
						</table>
                  </div>
                </div>
                
                