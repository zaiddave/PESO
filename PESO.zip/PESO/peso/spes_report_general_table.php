<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>SPES General Report Table</b></h4></center>
                    </h4>
                  </div>
                  <div>
                  <br><br>
	                    <table id="table" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Name</th>
									<th>Gender</th>
									<th>Birthdate</th>
									<th>Age</th>
									<th>Address</th>
									<th>LGU</th>									
									<th>First Availment</th>
									<th>Educational Level</th>
									<th>Year</th>
									<th>Batch</th>
									<th>Second Availment</th>
									<th>Educational Level</th>
									<th>Year</th>
									<th>Batch</th>
									<th>Third Availment</th>
									<th>Educational Level</th>
									<th>Year</th>
									<th>Batch</th>
									<th>Remark</th>
								</tr>
							</thead>
							<tbody>
							<?php 																	
									$fetch = mysql_query("SELECT * FROM ps_spes ORDER BY sp_lname ASC") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                  			?>
								<tr>
									<td class="job-fair"><?php echo $row['sp_lname'] .", ".$row['sp_fname']." ".$row['sp_mname']?></td>
									<td class="job-fair"><?php echo $row['sp_gender'] ?></td>
									<td class="job-fair"><?php echo $row['sp_date_of_birth'] ?></td>
									<td class="job-fair"><?php echo $row['sp_age'] ?></td>
									<td class="job-fair"><?php echo $row['sp_brgy'].', '.$row['sp_city'] ?></td>
									<td class="job-fair"><?php echo $row['sp_lgu'] ?></td>
									<td class="td-green"><?php echo $row['sp_first_availment'] ?></td>
									<td class="td-green"><?php echo $row['sp_edu1'] ?></td>
									<td class="td-green"><?php echo $row['sp_first_year'] ?></td>
									<td class="td-green"><?php echo $row['sp_batch_first_year'] ?></td>
									<td class="td-yellow"><?php echo $row['sp_second_availment'] ?></td>
									<td class="td-yellow"><?php echo $row['sp_edu2'] ?></td>
									<td class="td-yellow"><?php echo $row['sp_second_year'] ?></td>
									<td class="td-yellow"><?php echo $row['sp_batch_second_year'] ?></td>
									<td class="td-red"><?php echo $row['sp_third_availment'] ?></td>
									<td class="td-red"><?php echo $row['sp_edu3'] ?></td>
									<td class="td-red"><?php echo $row['sp_third_year'] ?></td>
									<td class="td-red"><?php echo $row['sp_batch_third_year'] ?></td>
									<td class="job-fair"><?php echo $row['sp_remark']?></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                  </div>
                </div>
  
  