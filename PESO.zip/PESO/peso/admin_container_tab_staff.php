<?
  $query = mysql_query("SELECT * FROM ps_login WHERE l_type = 'Staff' ORDER BY l_fname ASC");
?>
<div id="staff" class="tab-pane fade in">
<button class="btn btn-success" name="add" data-toggle="modal" data-target="#staff_add"><span class="glyphicon glyphicon-save"></span></button>
<br><br>
<? while($row = mysql_fetch_array($query)){ ?>
 <div class="panel-group">
  <div class="panel panel-warning">  
    <div class="panel-heading">
        <button class="btn btn-danger pull-right" name="delete" data-toggle="modal" data-target="#delete_staff"
        data-id="<? echo $row['l_id']?>"><span class="glyphicon glyphicon-trash"></span></button><p><b>Name:</b> <? echo $row['l_fname'].' '.$row['l_mname'].' '.$row['l_lname']?> </p>
    </div>    
    <div class="panel-body">
      <br>
      <div class="col-md-3">
          <img src="<?php echo $row['l_image'] ?>" class="img-responsive img-thumbnail center-block" height="250px" width="200px" alt="No Image">
      </div>

      <div class="col-md-8 col-md-offset-1">
     	<div class="row">
            <div class="col-md-2">
              <p><b>Designation:</b><p>
            </div>
            <div class="col-md-10">
              <p><?php echo $row['l_desig'] ?> </p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>Contact:</b><p>
            </div>
            <div class="col-md-10">
              <p><?php echo $row['l_con'] ?> </p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>Username:</b><p>
            </div>
            <div class="col-md-10">
              <p><?php echo $row['l_username'] ?> </p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>Email:</b><p>
            </div>
            <div class="col-md-10">
              <p><?php echo $row['l_email'] ?> </p>
            </div>
          </div>   
          <div class="row">
            <div class="col-md-2">
              <p><b>Last Login:</b><p>
            </div>
            <div class="col-md-10">
              <p><?php echo $row['l_time'] ?> </p>
            </div>
          </div>      
      </div>
    </div><!--panel body-->    
    </div><!--panel-->
  </div><!--panel group-->
  <? }?>
</div><!-- tab pane fade-->