
<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>Manage Your Applicant Report</b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>
                  <div class="col-sm-12">
  <?php
  if(isset($_SESSION['result'])){
    echo $_SESSION['result'];
    unset($_SESSION['result']);
  }
  ?>
</div>
	                    <table id="table1" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Applicant Name</th>
									<th>Gender</th>
									<th>Birthdate</th>
									<th>Address</th>
									<th>OSY</th>
									<th>In School</th>
									<th>Indigenous People</th>
									<th>PWD</th>
									<th>Contact Number/s</th>
									<th>Email</th>
									<th>Course</th>
									<th>Preferred Job</th>
									<th>Highest Educational Attainment</th>
									<th>Manage</th>
								</tr>
							</thead>
							<tbody>
							<?php 									
									
									$fetch = mysql_query("SELECT * FROM ps_applicant_registry ORDER BY ap_lname ASC ") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                  			?>
								<tr>
									<td class="job-fair"><?php echo $row['ap_lname'] .", ".$row['ap_fname']." ".$row['ap_mname']?></td>
									<td class="job-fair"><?php echo $row['ap_gender'] ?></td>
									<td class="job-fair"><?php echo $row['ap_bdate'] ?></td>
									<td class="job-fair"><?php echo $row['ap_address'] ?></td>
									<td class="job-fair"><?php echo $row['ap_osy']?></td>
									<td class="job-fair"><?php echo $row['ap_inschool']?></td>
									<td class="job-fair"><?php echo $row['ap_ip']?></td>
									<td class="job-fair"><?php echo $row['ap_pwd']?></td>
									<td class="job-fair"><?php echo nl2br($row['ap_telephone'] ."\n") .nl2br($row['ap_cellphone'] ."\n") ?></td>
									<td class="job-fair"><?php echo nl2br($row['ap_email']."\n") ?></td>
									<td class="job-fair"><?php echo $row['ap_course'] ?></td>
									<td class="job-fair"><?php echo $row['ap_pref_job'] ?></td>
									<td class="job-fair"><?php echo $row['ap_educ_bg'] ?></td>
									<td class="job-fair">
									<a data-toggle="tooltip" data-placement="bottom" title="Update.">
									<button class="btn btn-primary" aria-label="Edit" data-toggle="modal" data-target="#update_applicant" data-applicant-id="<?php echo $row['ap_id']?>"
										data-fname="<?php echo $row['ap_fname']?>"
										data-mname="<?php echo $row['ap_mname']?>"
										data-lname="<?php echo $row['ap_lname']?>"
										data-bdate="<?php echo $row['ap_bdate']?>"
										data-address="<?php echo $row['ap_address']?>"
										data-telephone="<?php echo $row['ap_telephone']?>"
										data-cellphone="<?php echo $row['ap_cellphone']?>"
										data-email="<?php echo $row['ap_email']?>"
										data-course="<?php echo $row['ap_course']?>"
										data-start="<?php echo $row['ap_from_date']?>"
										data-end="<?php echo $row['ap_to_date']?>"
										data-job="<?php echo $row['ap_pref_job']?>"
										data-edubg="<?php echo $row['ap_educ_bg']?>" ><span class="glyphicon glyphicon-edit"></span></button></a><br><br>
									<a data-toggle="tooltip" data-placement="top" title="Delete.">
									<button class="btn btn-danger" aria-label="Delete" data-toggle="modal" data-target="#delete_applicant" data-delete-id="<?php echo $row['ap_id']?>"><span class="glyphicon glyphicon-trash"></span></button></a>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                  </div>
                </div>
                
                