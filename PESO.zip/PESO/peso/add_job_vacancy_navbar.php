<nav class="navbar navbar-custom navbar-fixed-top " role="navigation">
  <div class="container-fluid ">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php" >
        <span><img src="images/peso.png" alt="PESO" height="25px" width="25px" style="margin-top: -7px;"></span>
        PESO
      </a>
    </div>
    <div>
    <div class="collapse navbar-collapse" id="navbar-collapse">       
      <ul class="nav navbar-nav navbar-right" style="margin: 1px 0px 0px 0px;">       
                <li><a href="employer.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Company Registration</a></li>
                <li class="active" style="margin:0px 1px 0px 1px"><a href="add_job_vacancy.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Job Vacancy</a></li>
                <li><a href="applicant.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Applicant Registration</a></li>                
                <li><a href="job_interview.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Job Interview Form</a></li>
                <li><a href="spes.php"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> SPES Registration</a></li>
    </ul>
    </div>
    </div>
  </div>
</nav>