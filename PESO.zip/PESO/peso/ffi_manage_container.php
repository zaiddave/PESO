<div class="col-md-12">
 <div class="container shadow col-md-12">
    <?php include('ffi_manage_table.php') ?> 
</div>
</div>


<?php include('update_ffi.php') ?>
<?php include('delete_ffi.php') ?>