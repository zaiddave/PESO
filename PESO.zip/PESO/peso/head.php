<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/DataTables-1.10.12/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<link href="assets/ie10-viewport-bug-workaround.css" rel="stylesheet">


<link href="assets/style.css" rel="stylesheet">


<link href="bootstrap/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet">
<!--custom jquery ui min css for the calendar display in inputy text -->
<link href="assets/jquery-ui-1.11.4.custom/jquery-ui.min.css" rel="stylesheet">
<!--Datatables css-->
<link href="assets/DataTables-1.10.12/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="assets/DataTables-1.10.12/css/buttons.dataTables.min.css" rel="stylesheet" >

<script src="bootstrap/js/jquery.min.js"  type="text/javascript"></script>
<!--custom jquery ui min js for the calendar display in inputy text -->
<script src="assets/jquery-ui-1.11.4.custom/jquery-ui.min.js"  type="text/javascript"></script>
<script src="bootstrap/js/bootstrap.min.js"  type="text/javascript" ></script>

<script src="assets/DataTables-1.10.12/js/jquery.dataTables.bootstrap.min.js"  type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/dataTables.bootstrap.min.js"  type="text/javascript" ></script>


<!--Datatables script responsible for adding print functionality-->
<script src="assets/DataTables-1.10.12/js/jquery.dataTables.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/dataTables.buttons.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/buttons.flash.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/jszip.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/pdfmake.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/vfs_fonts.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/buttons.html5.min.js" type="text/javascript" ></script>
<script src="assets/DataTables-1.10.12/js/buttons.print.min.js" type="text/javascript" ></script>

<script type="text/javascript">
    
    $(window).load(function(){
    $('#loading').hide()
    });

    $(document).ready(function(){
    $(".datepicker").each(function() {
        $(this).datepicker();
    });
    $('[data-toggle="tooltip"]').tooltip()
    $("[data-toggle=popover]").popover({ html:true });
    $('#table0').DataTable({
        dom: '<l>Bfrtip',
        buttons: [       
        ],
        "ordering": false,
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "scrollX": true

    });

    $('#table').DataTable({
        dom: '<l>Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        "ordering": false,
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "scrollX": true
    });

    $('#job_table').DataTable({
        dom: '<l>Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        "ordering": false,
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
        
    });

    $('#table1').DataTable({
        dom: '<l>Bfrtip',
        buttons: [       
        ],
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "scrollX": true
    });

    $('#job_table2').DataTable({
        dom: '<l>Bfrtip',
        buttons: [       
        ],
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });

    $('#update_employer').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('company-id');
        var type = $(e.relatedTarget).data('type');
        var company = $(e.relatedTarget).data('company');
        var representative = $(e.relatedTarget).data('representative');
        var designation = $(e.relatedTarget).data('designation');
        var telephone = $(e.relatedTarget).data('telephone');
        var cellphone = $(e.relatedTarget).data('cellphone');
        var email = $(e.relatedTarget).data('email');

        $(e.currentTarget).find('input[name="id"]').val(id);
        $('#type').val(type);
        $('#company').val(company);
        $('#representative').val(representative);
        $('#designation').val(designation);
        $('#telephone').val(telephone);
        $('#cellphone').val(cellphone);
        $('#email').val(email);

     });


    $('#update_vacancy').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('vacancy-id');
        var company = $(e.relatedTarget).data('company');
        var vacancy = $(e.relatedTarget).data('vacancy');
        var novacancy = $(e.relatedTarget).data('novacancy');
        var dateposting = $(e.relatedTarget).data('dateposting');
        var status = $(e.relatedTarget).data('status');
        var date = $(e.relatedTarget).data('date');

        $(e.currentTarget).find('input[name="id"]').val(id);
        $('#inputForEmployer').val(company);
        $('#inputForVacancy').val(vacancy);
        $('#inputForNoVacancy').val(novacancy);
        $('#inputDatePosting').val(dateposting);
        $('#inputForStatus').val(status);
        $('#inputForDate').val(date);

     });

 $('#update_applicant').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('applicant-id');
        var fname = $(e.relatedTarget).data('fname');
        var mname = $(e.relatedTarget).data('mname');
        var lname = $(e.relatedTarget).data('lname');
        var bdate = $(e.relatedTarget).data('bdate');
        var address = $(e.relatedTarget).data('address');
        var telephone = $(e.relatedTarget).data('telephone');
        var cellphone = $(e.relatedTarget).data('cellphone');
        var email = $(e.relatedTarget).data('email');
        var course = $(e.relatedTarget).data('course');
        var start = $(e.relatedTarget).data('start');
        var end = $(e.relatedTarget).data('end');
        var job = $(e.relatedTarget).data('job');
        var edubg = $(e.relatedTarget).data('edubg');

        $(e.currentTarget).find('input[name="id"]').val(id);
        $('#fname').val(fname);
        $('#mname').val(mname);
        $('#lname').val(lname);
        $('#bdate').val(bdate);
        $('#address').val(address);
        $('#telephone').val(telephone);
        $('#cell').val(cellphone);
        $('#email').val(email);
        $('#course').val(course);
        $('#start').val(start);
        $('#end').val(end);
        $('#job').val(job);
        $('#educational').val(edubg);
        
     });


 $('#update_hots').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('hots-id');
        var fname = $(e.relatedTarget).data('fname');
        var mname = $(e.relatedTarget).data('mname');
        var lname = $(e.relatedTarget).data('lname');
        var age = $(e.relatedTarget).data('age');
        var cellphone = $(e.relatedTarget).data('cellphone');
        var address = $(e.relatedTarget).data('address');
        var applied = $(e.relatedTarget).data('applied');
        var sponsor = $(e.relatedTarget).data('sponsor');
        var company = $(e.relatedTarget).data('company');
        var venue = $(e.relatedTarget).data('venue');

        $(e.currentTarget).find('input[name="id"]').val(id);
        $('#fname').val(fname);
        $('#mname').val(mname);
        $('#lname').val(lname);
        $('#age').val(age);
        $('#cell').val(cellphone);
        $('#address').val(address);        
        $('#applied').val(applied);
        $('#sponsor').val(sponsor);
        $('#company').val(company);
        $('#venue').val(venue);
        
     });

$('#delete_employer').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('delete-id');

        $(e.currentTarget).find('input[name="id"]').val(id);

    });

$('#delete_job').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('delete-id');

        $(e.currentTarget).find('input[name="id"]').val(id);

    });

$('#delete_applicant').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('delete-id');

        $(e.currentTarget).find('input[name="id"]').val(id);

    });

$('#delete_hots').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('delete-id');

        $(e.currentTarget).find('input[name="id"]').val(id);

    });

 $('#update_qualified').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('qualified-id');
        var fname = $(e.relatedTarget).data('fname');
        var mname = $(e.relatedTarget).data('mname');
        var lname = $(e.relatedTarget).data('lname');
        var age = $(e.relatedTarget).data('age');
        var cellphone = $(e.relatedTarget).data('cellphone');
        var address = $(e.relatedTarget).data('address');
        var applied = $(e.relatedTarget).data('applied');
        var sponsor = $(e.relatedTarget).data('sponsor');
        var company = $(e.relatedTarget).data('company');
        var venue = $(e.relatedTarget).data('venue');

        $(e.currentTarget).find('input[name="id"]').val(id);
        $('#fname').val(fname);
        $('#mname').val(mname);
        $('#lname').val(lname);
        $('#age').val(age);
        $('#cell').val(cellphone);
        $('#address').val(address);
        $('#applied').val(applied);
        $('#sponsor').val(sponsor);
        $('#company').val(company);
        $('#venue').val(venue);

        
     });

$('#delete_qualified').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('delete-id');

        $(e.currentTarget).find('input[name="id"]').val(id);

    });

 $('#update_notqualified').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('notqualified-id');
        var fname = $(e.relatedTarget).data('fname');
        var mname = $(e.relatedTarget).data('mname');
        var lname = $(e.relatedTarget).data('lname');
        var age = $(e.relatedTarget).data('age');
        var cellphone = $(e.relatedTarget).data('cellphone');
        var address = $(e.relatedTarget).data('address');
        var applied = $(e.relatedTarget).data('applied');
        var sponsor = $(e.relatedTarget).data('sponsor');
        var company = $(e.relatedTarget).data('company');
        var venue = $(e.relatedTarget).data('venue');

        $(e.currentTarget).find('input[name="id"]').val(id);
        $('#fname').val(fname);
        $('#mname').val(mname);
        $('#lname').val(lname);
        $('#age').val(age);
        $('#cell').val(cellphone);
        $('#address').val(address);
        $('#applied').val(applied);
        $('#sponsor').val(sponsor);
        $('#company').val(company);
        $('#venue').val(venue);
        
     });

$('#delete_notqualified').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('delete-id');

        $(e.currentTarget).find('input[name="id"]').val(id);

    });

 $('#update_ffi').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('ffi-id');
        var fname = $(e.relatedTarget).data('fname');
        var mname = $(e.relatedTarget).data('mname');
        var lname = $(e.relatedTarget).data('lname');
        var age = $(e.relatedTarget).data('age');
        var cellphone = $(e.relatedTarget).data('cellphone');
        var address = $(e.relatedTarget).data('address');
        var applied = $(e.relatedTarget).data('applied');
        var sponsor = $(e.relatedTarget).data('sponsor');
        var company = $(e.relatedTarget).data('company');
        var venue = $(e.relatedTarget).data('venue');

        $(e.currentTarget).find('input[name="id"]').val(id);
        $('#fname').val(fname);
        $('#mname').val(mname);
        $('#lname').val(lname);
        $('#age').val(age);
        $('#cell').val(cellphone);
        $('#address').val(address);
        $('#applied').val(applied);
        $('#sponsor').val(sponsor);
        $('#company').val(company);
        $('#venue').val(venue);
        
     });

$('#delete_ffi').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('delete-id');

        $(e.currentTarget).find('input[name="id"]').val(id);

    });

$('#spes_manage').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('id');

        $(e.currentTarget).find('input[name="id"]').val(id);
        $(e.currentTarget).find('input[name="sid"]').val(id);
        $(e.currentTarget).find('input[name="eid"]').val(id);

    });

$('#delete_spes').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('id');

        $(e.currentTarget).find('input[name="id"]').val(id);

    });

$('#official_update').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('id');
        var id1 = $(e.relatedTarget).data('id1');
        var id2 = $(e.relatedTarget).data('id2');
        var fname = $(e.relatedTarget).data('fname');
        var mname = $(e.relatedTarget).data('mname');
        var lname = $(e.relatedTarget).data('lname');
        var desig = $(e.relatedTarget).data('desig');
        var email = $(e.relatedTarget).data('email');
        var con = $(e.relatedTarget).data('con');
        var gfname = $(e.relatedTarget).data('gfname');
        var gmname = $(e.relatedTarget).data('gmname');
        var glname = $(e.relatedTarget).data('glname');
        var mfname = $(e.relatedTarget).data('mfname');
        var mmname = $(e.relatedTarget).data('mmname');
        var mlname = $(e.relatedTarget).data('mlname');
        

        $(e.currentTarget).find('input[name="id"]').val(id);
        $(e.currentTarget).find('input[name="id1"]').val(id1);
        $(e.currentTarget).find('input[name="id2"]').val(id2);
        $('#fname').val(fname);
        $('#mname').val(mname);
        $('#lname').val(lname);
        $('#desig').val(desig);
        $('#email').val(email);
        $('#con').val(con);
        $('#gfname').val(gfname);
        $('#gmname').val(gmname);
        $('#glname').val(glname);
        $('#mfname').val(mfname);
        $('#mmname').val(mmname);
        $('#mlname').val(mlname);
     });

$('#update_staff').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('id');
        var fname = $(e.relatedTarget).data('fname');
        var mname = $(e.relatedTarget).data('mname');
        var lname = $(e.relatedTarget).data('lname');
        var desig = $(e.relatedTarget).data('desig');
        var con = $(e.relatedTarget).data('con');
        var email = $(e.relatedTarget).data('email');
        

        $(e.currentTarget).find('input[name="id"]').val(id);        
        $('#fname').val(fname);
        $('#mname').val(mname);
        $('#lname').val(lname);
        $('#desig').val(desig);
        $('#con').val(con);
        $('#email').val(email);
     });

    $('#delete_staff').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('id');

        $(e.currentTarget).find('input[name="id"]').val(id);

    });

    $('#certificate_year').on('show.bs.modal', function (e) {
        var id = $(e.relatedTarget).data('id');

        $(e.currentTarget).find('input[name="id"]').val(id);

    });


    });

function display_c(){
var refresh=1000; // Refresh rate in milli seconds
mytime=setTimeout('display_ct()',refresh)
}

function display_ct() {
var strcount
var x = new Date()
document.getElementById('ct').innerHTML = x;
tt=display_c();
}

/*
$(window).scroll(
    {
        previousTop:0
    },

    function() {
        var currentTop = $(window).scrollTop();
    if(currentTop <= this.previousTop){
        $(".navbar-custom").css("opacity", "1");
    }else{
        $(".navbar-custom").css("opacity", "0");
    }this.previousTop = currentTop;
    });*/








</script>



<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<div id="loading">
    <img src="images/loadingBar.gif" id="loading-image" alt="Loading...">
    <strong id="loading-text text-color"><small>LOADING PLEASE WAIT...</small></strong>
</div>
<body class="bg" onload=display_ct();>