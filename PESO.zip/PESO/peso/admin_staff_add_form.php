<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}

//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

$img = clean($_FILES['pic']['name']);
$fname = clean($_POST['fname']);
$mname = clean($_POST['mname']);
$lname = clean($_POST['lname']);
$desig = clean($_POST['desig']);
$user = clean($_POST['user']);
$pass = clean($_POST['pass']);
$email = clean($_POST['email']);
$con = clean($_POST['con']);
$type = "Staff";


//source of image
$sourcePath = $_FILES['pic']['tmp_name'];
//where the image is to be placed
$path= 'C:/xampp/htdocs/peso/admin/'.$_FILES['pic']['name'];

$info = getimagesize($_FILES["pic"]["tmp_name"]);


$fetch = mysql_query("SELECT * FROM ps_login WHERE l_username = '$user' ");

if(mysql_num_rows($fetch)>0){
		$success = '<div class="alert alert-danger" role="alert"><b>Username</b> already exist <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
}

//no file uploaded
elseif ($_FILES['pic']['error'] == 4)
{
    $query = "INSERT INTO ps_login (l_fname, l_mname, l_lname, l_desig, l_type, l_username, l_password, l_email, l_con) VALUES  ('$fname', '$mname', '$lname', '$desig', '$type', '$user', md5('$pass'), '$email', '$con')";

	mysql_query($query) or die(mysql_error());

	$success = '<div class="alert alert-success" role="alert"><b>Successfully</b> added <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
}

else{
	if (file_exists($path)) {
    $success = '<div class="alert alert-warning" role="alert"><b>File name</b> already exist <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}


elseif(is_array($_FILES)) {

	if($info === FALSE) {
        $success = '<div class="alert alert-danger" role="alert"><b>Uploaded file</b> is not an image <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
    }

    if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
   		$success = '<div class="alert alert-danger" role="alert"><b>Uploaded file</b> is not a <b>.jpg</b>, <b>.jpeg</b> or <b>.png</b> extension <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}

else{						

	if(is_uploaded_file($_FILES['pic']['tmp_name'])) {

	if(move_uploaded_file($sourcePath,$path)) {
		$query = "INSERT INTO ps_login (l_fname, l_mname, l_lname, l_desig, l_type, l_username, l_password, l_email, l_con, l_image) VALUES  ('$fname', '$mname', '$lname', '$desig', '$type', '$user', md5('$pass'), '$email', '$con', 'admin/$img')";

	mysql_query($query) or die(mysql_error());

		$success = '<div class="alert alert-success" role="alert"><b>Successfully</b> added <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
		}
	}
	}
}
$_SESSION['result'] = $success;
header('location:admin.php');
}
?>