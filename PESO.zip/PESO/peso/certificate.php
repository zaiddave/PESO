<?php 
session_start();
require_once('db_con/connect.php');
require('fpdf.php');
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}

//function to sanitizes values received from the form. Prevents SQL injection

function clean($str){
	$str = @trim($str);
	if(get_magic_quotes_gpc()){
		$str = stripslashes($str);
	}
	return mysql_real_escape_string($str);
}

$id = clean($_POST['id']);
$day = clean($_POST['day']);
$month = clean($_POST['month']);
$year = clean($_POST['year']);

$query = "SELECT * FROM ps_spes WHERE sp_id = '$id'";
$fetch = mysql_query($query);
$row = mysql_fetch_array($fetch);
$fname = strtoupper($row['sp_fname']);
$mname = strtoupper($row['sp_mname']);
$lname = strtoupper($row['sp_lname']);
$age = $row['sp_age'];
$gender = strtoupper($row['sp_gender']);
$city = strtoupper($row['sp_city']);

if($gender == 'MALE'){
	$pronoun = 'HE';
}
elseif($gender == 'FEMALE'){
	$pronoun = 'SHE';
}

$availy1 = $row['sp_first_year'];
$availy2 = $row['sp_second_year'];
$availy3 = $row['sp_third_year'];

$gra1 = $row['sp_grade_first'];
$gra2 = $row['sp_grade_second'];
$gra3 = $row['sp_grade_third'];

$queryCoordinator = "SELECT * FROM ps_login WHERE l_type = 'Official' AND l_desig = 'Coordinator'";
$fetchCoordinator = mysql_query($queryCoordinator);
$rowCoordinator = mysql_fetch_array($fetchCoordinator);
$cFName = strtoupper($rowCoordinator['l_fname']);
$cMName = strtoupper($rowCoordinator['l_mname']);
$cLName = strtoupper($rowCoordinator['l_lname']);

$queryManager = "SELECT * FROM ps_login WHERE l_type = 'Official' AND l_desig = 'Manager'";
$fetchManager = mysql_query($queryManager);
$rowManager = mysql_fetch_array($fetchManager);
$mFName = strtoupper($rowManager['l_fname']);
$mMName = strtoupper($rowManager['l_mname']);
$mLName = strtoupper($rowManager['l_lname']);

$queryGovernor = "SELECT * FROM ps_login WHERE l_type = 'Official' AND l_desig = 'Governor'";
$fetchGovernor = mysql_query($queryGovernor);
$rowGovernor = mysql_fetch_array($fetchGovernor);
$gFName = strtoupper($rowGovernor['l_fname']);
$gMName = strtoupper($rowGovernor['l_mname']);
$gLName = strtoupper($rowGovernor['l_lname']);


$rep = "Republic of the Philippines";
$prov = "Province of Negros Occidental";
$peso = "Public Employment Service Office (PESO)";

$cert = "CERTIFICATION";

$para1 = "          This is to certify that ".$fname." ".$mname." ".$lname.", ".$age." years old, ".$gender.", resident of ".$city.", NEGROS OCCIDENTAL has been a beneficiary of the Special Program for Employment of Students (SPES), a program which extends assistance and support to our poor and deserving students who always value education despite the hardship their parents encountered in sending them to school.";

$para2 = "          The above mentioned beneficiary is hereby considered as SPES Baby since ".$pronoun." has availed of the program for (3) years and maintained an average grade of _____ and above:";

$avail1 = "1st availment";
$avail2 = "2nd availment";
$avail3 = "3rd availment";

$year1 = $availy1;
$year2 = $availy2;
$year3 = $availy3;

$ave1 = "average grade:";
$ave2 = "average grade:";
$ave3 = "average grade:";

$grade1 = $gra1;
$grade2 = $gra2;
$grade3 = $gra3;

$note = "*The Special Program for Employment of Students (SPES) shall continue to provide employment to deserving students and out-of-school youths coming from poor families during summer and/or Christmas vacations as provided for under Republic Act No. 7323 to enable them to pursue their education. It will provide employment to poor but deserving students between 15 to 30 years old within the Province of Negros Occidental.";

$copy = "Certified true and correct:";	

$coordinator = $cFName." ".$cMName." ".$cLName;
$manager = $mFName." ".$mMName." ".$mLName;
$governor = $gFName." ".$gMName." ".$gLName;

$desig1 = "PESO Neg. Occ. - Coordinator";
$desig2 = "PESO Neg. Occ. - Manager";
$desig3 = "Provincial Governor";

$parab1 = "For being a SPES Baby, availed of the program for three (3) years and maintained an average grade of _____ and above per year of availment of the SPES Program.";

$parab2 = "Given this ".$day." day of ".$month.", ".$year;

$parab3 = "at the Provincial Public Employment Service Office, Negros Occidental.";


$pdf=new FPDF('P','mm','Letter');
$pdf->AddPage();
$pdf->SetMargins(15,15,15);
$pdf->SetFont('Arial','',10);
$pdf->SetFontSize(10);
$pdf->SetFillColor(255,255,255);
$pdf->Cell(0,5,$rep,0,1,'C');
$pdf->Cell(0,5,$prov,0,1,'C');
$pdf->Cell(0,5,$peso,0,1,'C');
$pdf->Ln(16);
$pdf->SetFont('Arial','B',10);
$pdf->SetFontSize(20);
$pdf->Cell(0,5,$cert,0,1,'C');
$pdf->Ln(8);
$pdf->SetFont('Arial','',10);
$pdf->SetFontSize(12);
$pdf->MultiCell(0,6,$para1,0,'J',1);
$pdf->Ln(8);
$pdf->MultiCell(0,6,$para2,0,'J',1);
$pdf->Ln(0);
$pdf->SetFontSize(10);
$pdf->Cell(60,5,$avail1,0,0,'R');
$pdf->Cell(15,5,$year1,0,0,'L');
$pdf->Cell(50,5,$ave1,0,0,'R');
$pdf->Cell(15,5,$grade1,0,1,'L');
$pdf->Cell(60,5,$avail2,0,0,'R');
$pdf->Cell(15,5,$year2,0,0,'L');
$pdf->Cell(50,5,$ave2,0,0,'R');
$pdf->Cell(15,5,$grade2,0,1,'L');
$pdf->Cell(60,5,$avail3,0,0,'R');
$pdf->Cell(15,5,$year3,0,0,'L');
$pdf->Cell(50,5,$ave3,0,0,'R');
$pdf->Cell(15,5,$grade3,0,1,'L');
$pdf->Ln(8);
$pdf->SetFontSize(6);
$pdf->MultiCell(0,3,$note,0,'J',1);
$pdf->Ln(8);
$pdf->SetFont('Arial','',10);
$pdf->SetFontSize(12);
$pdf->MultiCell(0,6,$copy,0,'J',1);
$pdf->Ln(16);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(60,5,$coordinator,0,0,'L');
$pdf->Cell(110,5,$manager,0,1,'R');
$pdf->SetFont('Arial','',10);
$pdf->Cell(60,5,$desig1,0,0,'L');
$pdf->Cell(110,5,$desig2,0,0,'R');
$pdf->Ln(24);
$pdf->SetFont('Arial','',10);
$pdf->Cell(0,5,'Noted:',0,1,'C');
$pdf->Ln(24);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(0,5,$governor,0,1,'C');
$pdf->SetFont('Arial','',10);
$pdf->Cell(0,5,$desig3,0,1,'C');
//recognition
$pdf->AddPage();
$pdf->SetMargins(15,15,15);
$pdf->SetFont('Arial','',10);
$pdf->SetFontSize(10);
$pdf->SetFillColor(255,255,255);
$pdf->Cell(0,5,$rep,0,1,'C');
$pdf->Cell(0,5,$prov,0,1,'C');
$pdf->Cell(0,5,$peso,0,1,'C');
$pdf->Ln(8);
$pdf->SetFont('Arial','B',10);
$pdf->SetFontSize(20);
$pdf->Cell(0,5,'Certificate of Recognition',0,1,'C');
$pdf->Ln(8);
$pdf->SetFont('Arial','',10);
$pdf->SetFontSize(10);
$pdf->Cell(0,5,'to',0,1,'C');
$pdf->Ln(16);
$pdf->SetFont('Arial','B',10);
$pdf->SetFontSize(20);
$pdf->Cell(0,5,$fname." ".$mname." ".$lname,0,1,'C');
$pdf->Ln(12);
$pdf->SetFont('Arial','',10);
$pdf->SetFontSize(10);
$pdf->MultiCell(0,6,$parab1,0,'C',1);
$pdf->Ln(8);
$pdf->MultiCell(0,6,$parab2,0,'C',1);
$pdf->MultiCell(0,6,$parab3,0,'C',1);
$pdf->Ln(24);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(0,5,$governor,0,1,'C');
$pdf->SetFont('Arial','',10);
$pdf->Cell(0,5,$desig3,0,1,'C');
$pdf->Output();
?>