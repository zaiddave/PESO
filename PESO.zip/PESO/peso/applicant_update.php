<?php
session_start();
require_once("db_con/connect.php");
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}
//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values
	$id = clean($_POST['id']);
	$fname = strtoupper(clean($_POST['fname']));
	$mname = strtoupper(clean($_POST['mname']));
	$lname = strtoupper(clean($_POST['lname']));
	$bdate = clean($_POST['bdate']);
	$gender = clean($_POST['gender']);
	$address = strtoupper(clean($_POST['address']));
	$osy = clean($_POST['osy']);
	$inschool = clean($_POST['inschool']);
	$ip = clean($_POST['ip']);
	$pwd = clean($_POST['pwd']);
	$telephone = clean($_POST['telephone']);
	$cellphone = clean($_POST['cell']);
	$email = clean($_POST['email']);
	$course = strtoupper(clean($_POST['course']));
	$var = clean($_POST['startdate']);
	$date = str_replace('/', '-', $var);
	$start = date('Y-m-d', strtotime($date));
	$job = strtoupper(clean($_POST['job']));
	$edubg = clean($_POST['educational']);

	
	
	if($bdate == "Not Specified"){
	$age = "Not Specified";

	$query = "UPDATE ps_applicant_registry SET ap_fname = '$fname', ap_mname = '$mname', ap_lname = '$lname', ap_gender = '$gender', ap_bdate = '$bdate', ap_age = '$age', ap_address = '$address', ap_osy = '$osy', ap_inschool = '$inschool', ap_ip = '$ip', ap_pwd = '$pwd', ap_telephone = '$telephone', ap_cellphone = '$cellphone', ap_email = '$email', ap_course = '$course', ap_from_date = '$var', ap_pref_job = '$job', ap_educ_bg = '$edubg' WHERE ap_id = $id";

	mysql_query($query) or die(mysql_error());

	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated <b>'.$fname.' '.$mname.' '.$lname.'</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';
    $_SESSION['result'] = $success;
	header('location:applicant_manage.php');
	}
	else{

	//explode the date to get month, day and year
  $birthDate = explode("/", $bdate);
  //get age from date or birthdate
  $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
    ? ((date("Y") - $birthDate[2]) - 1)
    : (date("Y") - $birthDate[2]));

	$query = "UPDATE ps_applicant_registry SET ap_fname = '$fname', ap_mname = '$mname', ap_lname = '$lname', ap_gender = '$gender', ap_bdate = '$bdate', ap_age = '$age', ap_address = '$address', ap_osy = '$osy', ap_inschool = '$inschool', ap_ip = '$ip', ap_pwd = '$pwd', ap_telephone = '$telephone', ap_cellphone = '$cellphone', ap_email = '$email', ap_course = '$course', ap_from_date = '$var', ap_pref_job = '$job', ap_educ_bg = '$edubg' WHERE ap_id = $id";

	mysql_query($query) or die(mysql_error());

	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated <b>'.$fname.' '.$mname.' '.$lname.'</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';
    $_SESSION['result'] = $success;
	header('location:applicant_manage.php');
	}
	


?>