<div class="modal fade" data-keyboard="false" data-backdrop="static" id="update_employer" tabindex="-1" role="dialog" aria-labelledby="update_employerLabel" aria-hidden="true">
  <div class="modal-dialog ">
    <div class="modal-content">
      <div class="modal-header update">
        <button type="button" data-dismiss="modal" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="update_employerLabel" ><center><strong>Update</strong></center></h4>
      </div>

      <div class="modal-body">

      

      
<form id="form" class="form-horizontal" action="employer_update.php" method="post" enctype="multipart/form-data">
<div style="margin-right:20px; margin-left:20px;">

<input type="hidden" class="form-control" name="id" id="id">

<div class="form-group">
    <label for="type" class="text-color-2">Type of Employment:</label><br>
      <select class="form-control" id="type" name="type" required>
        <option value="default" selected="selected">--SELECT--</option>
        <option value="POEA Licensed Agencies">POEA Licensed Agencies</option>
        <option value="LOCAL Companies">LOCAL Companies</option>
        <option value="BPO Companies">BPO Companies</option>
      </select>
</div>

  <div class="form-group">  	
    <label for="company" class="text-color-2">Company's Name:</label><br>
    
      <input type="text" class="form-control" id="company" placeholder="Employer/Company Name" name="company" required="true" autocomplete="off">
    
  </div>
  <div class="form-group">
  <label for="checkbox1" class="text-color-2">Business Requirements:</label>
   <div class="btn-group" data-toggle="buttons">
   <a data-toggle="tooltip" data-placement="top" title="Select 1 or more of these options.">
    <label class="btn btn-primary btn-enhance-primary">
      <input type="checkbox" name="business" id="business" value="Business Permit (DTI)">  Business Permit (DTI)
    </label>    
    <label class="btn btn-primary btn-enhance-primary">
      <input type="checkbox" name="mayor" id="mayor" value="Mayor's Permit"> Mayor's Permit
    </label>    
    <label class="btn btn-primary btn-enhance-primary">
      <input type="checkbox" name="bir" id="bir" value="BIR/SEC Registration"> BIR/SEC Registration
    </label>    
    </a>
    </div>
  </div>


<div class= "form-group">
  <label for="representative" class="text-color-2">Official Representative:</label><br>
      <textarea rows="2" class="form-control" id="representative" placeholder="Official Representative" name="representative" required></textarea>
</div> 

<div class= "form-group">
  <label for="designation" class="text-color-2 col-sm-2 control-label">Designation:</label><br>   
      <textarea rows="2" class="form-control" id="designation" placeholder="Designation" name="designation" required></textarea>
  </div> 

<div class= "form-group">
  <label for="contact" class="text-color-2 control-label">Contact Details:</label>
</div>

<div class= "form-group">
  <label for="telephone" class="col-md-offset-2 text-color-2 col-sm-2 control-label">Company No.:</label>
   <div class="col-sm-5"> 
      <textarea rows="2" class="form-control" id="telephone" placeholder="Company No." name="telephone"></textarea>
    </div>        
</div> 

<div class= "form-group">
<label for="cell" class="col-md-offset-2 text-color-2 col-sm-2 control-label">Cellphone No.:</label>
   <div class="col-sm-5 ">      
      <textarea rows="2" class="form-control" id="cellphone" placeholder="Cellphone No." name="cell"></textarea>
   </div>
</div>

<div class= "form-group">
<label for="email" class="col-md-offset-2 text-color-2 col-sm-2 control-label">Email Address:</label>
   <div class="col-sm-5 ">
      <textarea rows="2" class="form-control" id="email" placeholder="Email Address" name="email"></textarea>      
    </div>
</div>


<br>
<div class="form-group modal-footer">
                 <input
                  class="btn btn-info btn-update col-xs-3 col-xs-offset-4 col-sm-2 col-sm-offset-5 col-md-2 col-md-offset-5" type="submit" value="Update">
</div>
</div>
</form>

	  </div>

    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->