<?php
session_start();
include('meta.php') ?>
<title>PESO</title>
<?php include('head.php') ?>

<?php include('navbar.php') ?>

<?php include('hots_total_container.php') ?> 


</body>
</html>