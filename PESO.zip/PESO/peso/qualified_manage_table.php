<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>Manage Lists of Qualified Applicants </b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>
                  <div class="col-sm-12">
  <?php
  if(isset($_SESSION['result'])){
    echo $_SESSION['result'];
    unset($_SESSION['result']);
  }
  ?>
</div>
	                    <table id="table1" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Applicant Name</th>
									<th>Gender</th>
									<th>Age</th>
									<th>Contact Number/s</th>									
									<th>Address</th>
									<th>Position Applied</th>
									<th>Company</th>
									<th>Manage</th>
								</tr>
							</thead>
							<tbody>
							<?php 									
									
									$fetch = mysql_query("SELECT * FROM ps_qualified ORDER BY q_lname ASC") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){      
                					$id = mysql_real_escape_string($row['j_id']);          						
                  			?>
								<tr>
									<td class="job-fair"><?php echo $row['q_lname'] .", ".$row['q_fname']." ".$row['q_mname']?></td>
									<td class="job-fair"><?php echo $row['q_gender'] ?></td>
									<td class="job-fair"><?php echo $row['q_age'] ?></td>
									<td class="job-fair"><?php echo $row['q_cellphone'] ?></td>									
									<td class="job-fair"><?php echo $row['q_address'] ?></td>
									<td class="job-fair"><?php echo $row['q_applied'] ?></td>
									<td class="job-fair">
									<a href="#!" data-toggle="tooltip" data-placement="top" title="<?php
									$fetch2 = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_id = $id ");
									$tip = mysql_fetch_array($fetch2);
									echo $tip['j_employment_type'];
									 ?>">
									<?php echo $row['q_company'] ?>
									</a>
									</td>
									<td class="job-fair">
									<a data-toggle="tooltip" data-placement="bottom" title="Update.">
									<button class="btn btn-primary" aria-label="Edit" data-toggle="modal" data-target="#update_qualified"
									data-qualified-id="<?php echo $row['j_id'] ?>"
									data-fname="<?php echo $row['q_fname']?>"
									data-mname="<?php echo $row['q_mname']?>"
									data-lname="<?php echo $row['q_lname']?>"
									data-age="<?php echo $row['q_age']?>"
									data-cellphone="<?php echo $row['q_cellphone']?>"
									data-address="<?php echo $row['q_address']?>"
									data-applied="<?php echo $row['q_applied']?>"
									data-sponsor="<?php echo $row['q_sponsor']?>"
									data-company="<?php echo $row['q_company']?>"
									data-venue="<?php echo $row['q_venue']?>"
									>
									<span class="glyphicon glyphicon-edit"></span></button></a><br><br>
									<a data-toggle="tooltip" data-placement="top" title="Delete.">
									<button class="btn btn-danger" aria-label="Delete" data-toggle="modal" data-target="#delete_qualified"
									data-delete-id="<?php echo $row['j_id']?>" >
									<span class="glyphicon glyphicon-trash"></span></button></a></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                  </div>
                </div>