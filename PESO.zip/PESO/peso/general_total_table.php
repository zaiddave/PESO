<?php
$mquery = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_gender = 'Male' ");
$wMale = mysql_num_rows($mquery);
$fquery = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_gender = 'Female' ");
$wFemale = mysql_num_rows($fquery);
$tQualifiedQuery = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_status = 'Qualified' ");
$tQualified = mysql_num_rows($tQualifiedQuery);
$tNotQualifiedQuery = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_status = 'Not Qualified' ");
$tNotQualified = mysql_num_rows($tNotQualifiedQuery);
$tFFIQuery = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_status = 'FFI' ");
$tFFI = mysql_num_rows($tFFIQuery);
$tHOTSQuery = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_status = 'HOTS' ");
$tHOTS = mysql_num_rows($tHOTSQuery);
?>
<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>Job Interview General Report</b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>
	                    <table id="table" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
							<!-- head -->
								<tr  class="head-color">
									<th>Recruitment Type</th>
									<th>Date/Venue</th>
									<th>Employment Type</th>
									<th>Company Name</th>
									<th>Positions Applied</th>
									<th>Male</th>
									<th>Female</th>
									<th>Qualified</th>
									<th>Not Qualified</th>
									<th>FFI</th>
									<th>HOTS</th>
								</tr>
							<!-- /head -->
							</thead>
							<tbody>
							<!--total-->
								<tr>
									<th></th>
									<th></th>
									<th></th>
									<th></th>
									<th></th>
									<th><h4><strong><?php echo $wMale?></strong></h4></th>
									<th><h4><strong><?php echo $wFemale?></strong></h4></th>
									<th><h4><strong><a href="qualified_report.php"><?php echo $tQualified?></a></strong></h4></th>
									<th><h4><strong><a href="not_qualified_report.php"><?php echo $tNotQualified?></a></strong></h4></th>
									<th><h4><strong><a href="ffi_report.php"><?php echo $tFFI?></a></strong></h4></th>
									<th><h4><strong><a href="hots_report.php"><?php echo $tHOTS?></a></strong></h4></th>
								</tr>
								<!--/total-->
								<?php
								$fetch = mysql_query("SELECT DISTINCT j_recruitment_type FROM ps_job_interview_form ORDER BY j_recruitment_type DESC ");
								while($row = mysql_fetch_array($fetch)){
									$recr = mysql_real_escape_string($row['j_recruitment_type']);
								?>
								<!--recruitment-->
								<tr>
									<td class="report-recruitment">
									<h4><strong>
									<?php echo $row['j_recruitment_type'] ?>
									</strong></h4>
									</td>
									<td class="report-recruitment"></td>
									<td class="report-recruitment"></td>
									<td class="report-recruitment"></td>
									<td class="report-recruitment"></td>
									<td class="report-recruitment">
									<h4><strong>
									<?php
									$total_male_per_recruitment = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_gender = 'Male' ");
									 echo mysql_num_rows($total_male_per_recruitment);
									?>
									</strong></h4>
									</td>
									<td class="report-recruitment">
									<h4><strong>
									<?php
									$total_female_per_recruitment = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_gender = 'Female' ");
									 echo mysql_num_rows($total_female_per_recruitment);
									?>
									</strong></h4>
									</td>
									<td class="report-recruitment">
									<h4><strong>
									<?php
									$total_qualified_per_recruitment = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_status = 'Qualified' ");
									 echo mysql_num_rows($total_qualified_per_recruitment);
									?>
									</strong></h4>
									</td>
									<td class="report-recruitment">
									<h4><strong>
									<?php
									$total_not_qualified_per_recruitment = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_status = 'Not Qualified' ");
									 echo mysql_num_rows($total_not_qualified_per_recruitment);
									?>
									</strong></h4>
									</td>
									<td class="report-recruitment">
									<h4><strong>
									<?php
									$total_ffi_per_recruitment = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_status = 'FFI' ");
									 echo mysql_num_rows($total_ffi_per_recruitment);
									?>
									</strong></h4>
									</td>
									<td class="report-recruitment">
									<h4><strong>
									<?php
									$total_hots_per_recruitment = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_status = 'HOTS' ");
									 echo mysql_num_rows($total_hots_per_recruitment);
									?>
									</strong></h4>
									</td>
								</tr>
								<!--/recruitment-->
								<?php
								$fetch1 = mysql_query("SELECT DISTINCT j_activity_date FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' ORDER BY j_activity_date DESC ");
								while($row1 = mysql_fetch_array($fetch1)){
									$date = mysql_real_escape_string($row1['j_activity_date']);
								?>
								<!--date/venue-->
								<tr>
									<td></td>
									<td class="report-date">
									<h5><strong>
									<?php echo $row1['j_activity_date'] ?>
									</strong></h5>
									</td>
									<td class="report-date"></td>
									<td class="report-date"></td>
									<td class="report-date"></td>
									<td class="report-date">
									<h5><strong>
									<?php
									$total_male_per_date_and_venue = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_gender = 'Male' ");
									 echo mysql_num_rows($total_male_per_date_and_venue);
									?>
									</strong></h5>
									</td>
									<td class="report-date">
									<h5><strong>
									<?php
									$total_female_per_date_and_venue = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_gender = 'Female' ");
									 echo mysql_num_rows($total_female_per_date_and_venue);
									?>
									</strong></h5>
									</td>
									<td class="report-date">
									<h5><strong>
									<?php
									$total_qualified_per_date_and_venue = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_status = 'Qualified' ");
									 echo mysql_num_rows($total_qualified_per_date_and_venue);
									?>
									</strong></h5>
									</td>
									<td class="report-date">
									<h5><strong>
									<?php
									$total_not_qualified_per_date_and_venue = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_status = 'Not Qualified' ");
									 echo mysql_num_rows($total_not_qualified_per_date_and_venue);
									?>
									</strong></h5>
									</td>
									<td class="report-date">
									<h5><strong>
									<?php
									$total_ffi_per_date_and_venue = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_status = 'FFI' ");
									 echo mysql_num_rows($total_ffi_per_date_and_venue);
									?>
									</strong></h5>
									</td>
									<td class="report-date">
									<h5><strong>
									<?php
									$total_hots_per_date_and_venue = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_status = 'HOTS' ");
									 echo mysql_num_rows($total_hots_per_date_and_venue);
									?>
									</strong></h5>
									</td>
								</tr>
								<!--/date/venue-->
								<?php
								$fetch2 = mysql_query("SELECT DISTINCT j_employment_type FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' ");
								while($row2 = mysql_fetch_array($fetch2)){
									$employment = mysql_real_escape_string($row2['j_employment_type']);
								?>
								<!--employment type-->
								<tr>
									<td></td>
									<td></td>
									<td class="report-employment">
									<h5><strong>
									<?php echo $row2['j_employment_type'] ?>
									</strong></h5>
									</td>
									<td class="report-employment"></td>
									<td class="report-employment"></td>
									<td class="report-employment">
									<h5><strong>
									<?php
									$total_male_per_employment_type = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_gender = 'Male' ");
									 echo mysql_num_rows($total_male_per_employment_type);
									?>
									</strong></h5>
									</td>
									<td class="report-employment">
									<h5><strong>
									<?php
									$total_female_per_employment_type = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_gender = 'Female' ");
									 echo mysql_num_rows($total_female_per_employment_type);
									?>
									</strong></h5>
									</td>
									<td class="report-employment">
									<h5><strong>
									<?php
									$total_qualified_per_employment_type = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_status = 'Qualified' ");
									 echo mysql_num_rows($total_qualified_per_employment_type);
									?>
									</strong></h5>
									</td>
									<td class="report-employment">
									<h5><strong>
									<?php
									$total_not_qualified_per_employment_type = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_status = 'Not Qualified' ");
									 echo mysql_num_rows($total_not_qualified_per_employment_type);
									?>
									</strong></h5>
									</td>
									<td class="report-employment">
									<h5><strong>
									<?php
									$total_ffi_per_employment_type = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_status = 'FFI' ");
									 echo mysql_num_rows($total_ffi_per_employment_type);
									?>
									</strong></h5>
									</td>
									<td class="report-employment">
									<h5><strong>
									<?php
									$total_hots_per_employment_type = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_status = 'HOTS' ");
									 echo mysql_num_rows($total_hots_per_employment_type);
									?>
									</strong></h5>
									</td>
								</tr>				
								<!--end employment type-->				
								<?php
								$fetch3 = mysql_query("SELECT DISTINCT j_company_name FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' ");
								while($row3 = mysql_fetch_array($fetch3)){
									$company = mysql_real_escape_string($row3['j_company_name']);
								?>
								<!--company name-->
								<tr>
									<td></td>
									<td></td>
									<td></td>
									<td class="report-company">										
									<h5><strong>
									<?php echo $row3['j_company_name'] ?>
									</strong></h5>
									</td>
									<td class="report-company"></td>
									<td class="report-company">
									<h5><strong>
									<?php
									$total_male_in_company = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_gender = 'Male' ");
									 echo mysql_num_rows($total_male_in_company);									
									?>
									</strong></h5>
									</td>
									<td class="report-company">
									<h5><strong>
									<?php
									$total_female_in_company = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_gender = 'Female' ");
									 echo mysql_num_rows($total_female_in_company);									
									?>
									</strong></h5>
									</td>
									<td class="report-company">
									<h5><strong>
									<?php
									$total_qualified_in_company = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_status = 'Qualified' ");
									 echo mysql_num_rows($total_qualified_in_company);									
									?>
									</strong></h5>
									</td>
									<td class="report-company">
									<h5><strong>
									<?php
									$total_not_qualified_in_company = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_status = 'Not Qualified' ");
									 echo mysql_num_rows($total_not_qualified_in_company);									
									?>
									</strong></h5>
									</td>
									<td class="report-company">
									<h5><strong>
									<?php
									$total_ffi_in_company = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_status = 'FFI' ");
									 echo mysql_num_rows($total_ffi_in_company);									
									?>
									</strong></h5>
									</td>
									<td class="report-company">
									<h5><strong>
									<?php
									$total_hots_in_company = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_status = 'HOTS' ");
									 echo mysql_num_rows($total_hots_in_company);									
									?>
									</strong></h5>
									</td>
								</tr>
								<!--end company name-->
								<?php
								$fetch4 = mysql_query("SELECT DISTINCT j_position_applied FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' ");
								while($row4 = mysql_fetch_array($fetch4)){
									$position = mysql_real_escape_string($row4['j_position_applied']);
								?>
								<tr>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td  class="report-positions">
									<h5><strong>
									<?php echo $row4['j_position_applied'] ?>
									</strong></h5>
									</td>
									<td class="report-gender">
									<?php
									$total_male = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_position_applied = '$position' AND j_gender = 'Male' ");
									 echo mysql_num_rows($total_male);									
									?>
									</td>
									<td class="report-gender">
									<?php
									$total_female = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_position_applied = '$position' AND j_gender = 'Female' ");
									 echo mysql_num_rows($total_female);									
									?>
									</td>
									<td class="report-status">
									<?php
									$total_qualified = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_position_applied = '$position' AND j_status = 'Qualified' ");
									 echo mysql_num_rows($total_qualified);									
									?>
									</td>
									<td class="report-status">
									<?php
									$total_not_qualified = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_position_applied = '$position' AND j_status = 'Not Qualified' ");
									 echo mysql_num_rows($total_not_qualified);									
									?>
									</td>
									<td class="report-status">
									<?php
									$total_ffi = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_position_applied = '$position' AND j_status = 'FFI' ");
									 echo mysql_num_rows($total_ffi);									
									?>
									</td>
									<td class="report-status">
									<?php
									$total_hots = mysql_query("SELECT j_status FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_company_name = '$company' AND j_position_applied = '$position' AND j_status = 'HOTS' ");
									 echo mysql_num_rows($total_hots);									
									?>
									</td>
								</tr>								
								<?php } ?>
								<?php } ?>
								<?php } ?>
								<?php } ?>
								<tr>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                  </div>
                </div>