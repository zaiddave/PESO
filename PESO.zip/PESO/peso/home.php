<?php
 session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/peso.png">

    <title>PESO</title>
    
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<link href="assets/ie10-viewport-bug-workaround.css" rel="stylesheet">
	<link href="bootstrap/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet">
  <link href="assets/font-awesome/fontawesome-icons/fonticon.css" rel="stylesheet">
	<script src="bootstrap/js/jquery.min.js"  type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js"  type="text/javascript" ></script>


<style type="text/css">

	body{
		position: relative;
		}
	nav{			
		position: absolute;
		z-index: 1;
		top: 200px;
		margin: 0px;
		}

	.nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
		color: #fff;
		background-color: #849b89;
	}

	.nav-pills>li:first-child>a {
		border-top-right-radius: 10px;
	}

	.nav-pills>li:last-child>a{
		border-bottom-right-radius:10px;
	}

	.nav-pills>li>a {
		color: #849b89;
		text-decoration: none;
		background-color: #555;
		border-radius: 0px;
	}
	.container-fluid {
    padding-top: 70px;
    padding-bottom: 70px;
  	}
  .admin-margin{
    margin-top: 150px
    margin-bottom:-100px;
    height: 650px;
  }
  .lang-margin{
    height: 100%;    
    width: 100%;
  }
  .admin-bg-1{
    background-color: #424242;
  }

  .admin-bg-2{
  	background-color: #616161;
  }
  .admin-bg-3{
    background-color: #2f2f2f;
  }
  a{
  	text-decoration: none;
  }
 

.disappear{
  position: fixed;
  background: #5bc0de;
  color: white;
  margin-top: -30px;
  z-index: 1;
  right: 0px;
  transition: 2s;
}
/* log out button style */
[class*="fontawesome-"]:before {
   font-family: "FontAwesome", sans-serif;
}

ul {
   list-style: none;
   margin: 0;
   padding: 0;
}
#sticky-social {
   right: 0;
   position: fixed;
   top: 50%;
}
#sticky-social a {
   background: #333;
   color: #fff;
   display: block;
   height: 35px;
   font: 16px "Open Sans", sans-serif;
   line-height: 35px;
   position: relative;
   text-align: center;
   width: 35px;
}
#sticky-social a span {
   line-height: 35px;
   right: -120px;
   position: absolute;
   text-align:center;
   width:120px;
}
#sticky-social a:hover span {
   right: 100%;
}
#sticky-social a[class*="logout"],
#sticky-social a[class*="logout"]:hover,
#sticky-social a[class*="logout"] span { background: #d43f3a; transition: 1s; }
/* end log out */

</style>
<script type="text/javascript">
    $(window).scroll(
    {
        previousTop:0
    },

    function() {
        var currentTop = $(window).scrollTop();
    if(currentTop <= this.previousTop){
        $(".disappear").css("opacity", "1");
    }else{
        $(".disappear").css("opacity", "0");
    }this.previousTop = currentTop;
    });  
</script>
</head>

<body data-spy="scroll" data-target="#scrollableHomeMenu" data-offset="100">
		
<aside id="sticky-social">
    <ul>
        <li><a href="logout.php" class="logout fontawesome-signout"><span>Logout</span></a></li>        
    </ul>
</aside>

<?include ('home-nav-scrollspy.php') ?>

<div class="container-fluid header-text admin-bg-3" id="peso3">	
  <p class="pull-right disappear">&nbsp;&nbsp;Welcome <?php echo '<b>'.$_SESSION['fname'].' '.$_SESSION['lname'].'</b> !'?>&nbsp;&nbsp;</p>
		<div id="carousel-1" class="carousel slide center-block" data-ride="carousel" style="width: 75%;">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-1" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-1" data-slide-to="1"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="images/1.png" alt="What is PESO?">
    </div>
    <div class="item">
      <img src="images/2.png" alt="Definition of PESO">
    </div>
    <div class="item">
      <img src="images/3.png" alt="What are the Objectives PESO?">
    </div>
    <div class="item">
      <img src="images/4.png" alt="List Objectives of PESO">
    </div>
    <div class="item">
      <img src="images/5.png" alt="What are the Functions PESO?">
    </div>
    <div class="item">
      <img src="images/6.png" alt="List Functions of PESO">
    </div>
    <div class="item">
      <img src="images/7.png" alt="What are the Services PESO?">
    </div>
    <div class="item">
      <img src="images/8.png" alt="List Services of PESO">
    </div>
    <div class="item">
      <img src="images/9.png" alt="Who are the Clients of PESO?">
    </div>
    <div class="item">
      <img src="images/10.png" alt="List of Clients of PESO">
    </div>
    <div class="item">
      <img src="images/11.png" alt="How to avail of PESO services?">
    </div>
    <div class="item">
      <img src="images/12.png" alt="List on how to avail of PESO">
    </div>
  
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-1" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-1" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

<div class="container-fluid header-text admin-bg-1" id="peso1">	
	<div class="col-md-12" id="img-lang">		
		<a href="employer.php"><img src="images/register1.png" class="img-responsive img-circle center-block" >
		<h1><b><center>Register</center></b></h1>
		</a>

	</div>
</div>

<div class="container-fluid header-text admin-bg-2" id="peso2" >

	<div class="col-md-12" id="img-user">
		<a href="employer_report.php"><img src="images/report1.png" class="img-responsive img-circle center-block" >
		<h1><b><center>Reports</center></b></h1>
		</a>		
	</div>
</div>

<div class="container-fluid header-text admin-bg-1" id="peso4" >

  <div class="col-md-12" id="img-admin">
    <a href="admin.php"><img src="images/admin.png" class="img-responsive img-circle center-block" >
    <h1><b><center>Admin</center></b></h1>
    </a>    
  </div>
</div>






<!--
<script type="text/javascript">
	$(window).scroll(function() {
		$('#img-user').each(function(){
		var imagePos = $(this).offset().top;

		var topOfWindow = $(window).scrollTop();
			if (imagePos < topOfWindow+300) {
				$(this).addClass("slideExpandUp");
			}
		});
	});


	$(window).scroll(function() {
		$('#img-lang').each(function(){
		var imagePos = $(this).offset().top;

		var topOfWindow = $(window).scrollTop();
			if (imagePos < topOfWindow+300) {
				$(this).addClass("hatch");
			}
		});
	});

</script>
-->
</body>
 <script src="assets/home_scrollable_menu.js" type="text/javascript"></script>
 </html>