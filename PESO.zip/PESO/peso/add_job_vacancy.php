
<?php
session_start();
include('meta.php') ?>

<title> PESO </title>

<?php

include('head.php');

include('add_job_vacancy_navbar.php');

//include('side_container.php');

include('add_job_vacancy_container.php') ?> 


</body>
<!--
<script src="assets/scrollable_menu.js" type="text/javascript"></script>
-->
</html>
