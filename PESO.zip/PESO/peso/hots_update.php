<?php
session_start();
require_once("db_con/connect.php");
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}
	//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

	//sanitize the POST values
	$id = clean($_POST['id']);
	$fname = strtoupper(clean($_POST['fname']));
	$mname = strtoupper(clean($_POST['mname']));
	$lname = strtoupper(clean($_POST['lname']));
	$age = clean($_POST['age']);
	$cellphone = clean($_POST['cell']);
	$address = strtoupper(clean($_POST['address']));	
	$applied=strtoupper(clean($_POST['applied']));
	$sponsor=strtoupper(clean($_POST['sponsor']));
	$company=strtoupper(clean($_POST['company']));
	$venue=strtoupper(clean($_POST['venue']));
	$gender=clean($_POST['gender']);
	$status=clean($_POST['status']);
	$employed = clean($_POST['employed']);
	$type=clean($_POST['employmentType']);

	$updateQuery = mysql_query("SELECT * FROM ps_hots WHERE j_id = '$id'");
	$fetchQueried = mysql_fetch_array($updateQuery) or die(mysql_error());
	$recruitment=mysql_real_escape_string($fetchQueried['hots_recruitment_type']);
	$date=mysql_real_escape_string($fetchQueried['hots_activity_date']);

	if(!is_numeric($age)){

	$error = '<div class="alert alert-danger" role="alert"><b>Oops</b> you seem to have added an invalid char in the age of '.$fname.' '.$mname.' '.$lname.'. Please input only numbers <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

    $_SESSION['result'] = $error;
	header('location:hots_manage.php');
	}
	elseif ($status == "FFI") {
		$ffi = "INSERT INTO ps_ffi (j_id, ffi_fname, ffi_mname, ffi_lname, ffi_applied, ffi_gender, ffi_age, ffi_cellphone, ffi_address, ffi_company, ffi_recruitment_type, ffi_activity_date, ffi_sponsor, ffi_venue) VALUES ('$id', '$fname', '$mname', '$lname', '$applied', '$gender', '$age', '$cellphone', '$address', '$company', '$recruitment', '$date', '$sponsor', '$venue')";
	mysql_query($ffi) or die(mysql_error());

	$job = "UPDATE ps_job_interview_form SET j_position_applied = '$applied', j_sponsor = '$sponsor', j_company_name = '$company', j_venue = '$venue', j_gender = '$gender', j_status = '$status', j_employment_type='$type' WHERE j_id = $id ";
	mysql_query($job) or die(mysql_error());

	$del = "DELETE FROM ps_hots WHERE j_id = '$id' ";
	mysql_query($del) or die(mysql_error());

	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated <b>'.$fname.'</b> and transferred to <b>FFI Report</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

    $_SESSION['result'] = $success;
	header('location:hots_manage.php');


	}
	elseif ($status == "Qualified") {
		$qualified = "INSERT INTO ps_qualified (j_id, q_fname, q_mname, q_lname, q_applied, q_gender, q_age, q_cellphone, q_address, q_company, q_recruitment_type, q_activity_date, q_sponsor, q_venue) VALUES ('$id', '$fname', '$mname', '$lname', '$applied', '$gender', '$age', '$cellphone', '$address', '$company', '$recruitment', '$date', '$sponsor', '$venue')";
	mysql_query($qualified) or die(mysql_error());

	$job = "UPDATE ps_job_interview_form SET j_position_applied = '$applied', j_sponsor = '$sponsor', j_company_name = '$company', j_venue = '$venue', j_gender = '$gender', j_status = '$status', j_employment_type='$type' WHERE j_id = $id ";
	mysql_query($job) or die(mysql_error());

	$del = "DELETE FROM ps_hots WHERE j_id = '$id' ";
	mysql_query($del) or die(mysql_error());

	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated <b>'.$fname.'</b> and transferred to <b>Qualified Report</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

    $_SESSION['result'] = $success;
	header('location:hots_manage.php');


	}

	elseif ($status == "Not Qualified") {
		$nQualified = "INSERT INTO ps_not_qualified (j_id, qn_fname, qn_mname, qn_lname, qn_applied, qn_gender, qn_age, qn_cellphone, qn_address, qn_company, qn_recruitment_type, qn_activity_date, qn_sponsor, qn_venue) VALUES ('$id', '$fname', '$mname', '$lname', '$applied', '$gender', '$age', '$cellphone', '$address', '$company', '$recruitment', '$date', '$sponsor', '$venue')";
	mysql_query($nQualified) or die(mysql_error());

	$job = "UPDATE ps_job_interview_form SET j_position_applied = '$applied', j_sponsor = '$sponsor', j_company_name = '$company', j_venue = '$venue', j_gender = '$gender', j_status = '$status', j_employment_type='$type' WHERE j_id = $id ";
	mysql_query($job) or die(mysql_error());

	$del = "DELETE FROM ps_hots WHERE j_id = '$id' ";
	mysql_query($del) or die(mysql_error());

	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated <b>'.$fname.'</b> and transferred to <b>Not Qualified Report</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

    $_SESSION['result'] = $success;
	header('location:hots_manage.php');


	}

	else{
	$query = "UPDATE ps_hots SET hots_fname = '$fname', hots_mname = '$mname', hots_lname = '$lname', hots_age = '$age', hots_cellphone = '$cellphone', hots_address = '$address', hots_applied = '$applied', hots_sponsor = '$sponsor', hots_company = '$company', hots_venue = '$venue', hots_gender = '$gender', hots_employed = '$employed' WHERE j_id = $id";
	mysql_query($query) or die(mysql_error());

	$job = "UPDATE ps_job_interview_form SET j_position_applied = '$applied', j_sponsor = '$sponsor', j_company_name = '$company', j_venue = '$venue', j_gender = '$gender', j_status = 'HOTS', j_employment_type='$type' WHERE j_id = $id ";
	mysql_query($job) or die(mysql_error());
	
	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated <b>'.$fname.'</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

    $_SESSION['result'] = $success;
	header('location:hots_manage.php');
	}

?>