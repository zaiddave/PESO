<?php
session_start();
include('meta.php') ?>

<title> PESO </title>

<?php include('head.php');

include('navbar_admin.php');

if($_SESSION['type'] == "Official"){
include('admin_container.php');
}
elseif($_SESSION['type'] == "Staff"){
include('admin_staff_info.php');
include('admin_staff_update.php');
} ?> 



</body>
<script type="text/javascript">
//this script is responsible for the tab location to stay in place after refreshing
var hash = document.location.hash;
var prefix = "tab_";
if (hash) {
    $('.nav-tabs a[href="'+hash.replace(prefix,"")+'"]').tab('show');
} 

// Change hash for page-reload
$('.nav-tabs a').on('shown.bs.tab', function (e) {
    window.location.hash = e.target.hash.replace("#", "#" + prefix);
});
</script>
</html>
