
<div class="modal fade bs-example-modal-lg" data-keyboard="false" data-backdrop="static" id="staff_add" tabindex="-1" role="dialog" aria-labelledby="staffAdd" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header update">
        <button type="button" class="close" aria-label="Close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="staffAdd" ><strong><center>Personal Information</center></strong></h4>
      </div>

      <div class="modal-body">
      <form class="form-horizontal" method="post" action="admin_staff_add_form.php" enctype="multipart/form-data">
      
      <div class="form-group">
      <label for="pic" class="text-color-2 col-sm-2 control-label">Image:</label>
            <div class="col-md-2">      
            <input type="file" id="pic" name="pic" autocomplete="off"> 
            </div>
        </div>
        <div class="form-group">
        <label for="company" class="text-color-2 col-sm-2 control-label">PESO Staff Name:</label>
        <div class="col-sm-3">
          <input type="text" class="form-control" id="fname" placeholder="First Name" name="fname" autocomplete="off" required>
        </div>
        <div class="col-sm-3">
          <input type="text" class="form-control" id="mname" placeholder="Middle Name" autocomplete="off" name="mname">
        </div>
        <div class="col-sm-3">
          <input type="text" class="form-control" id="lname" placeholder="Last Name" name="lname" autocomplete="off" required>
        </div>
        </div>
 
        <div class="form-group">
            <label for="desig" class="text-color-2 col-sm-2 control-label">Designation:</label>
            <div class="col-md-3">
            <input type="text" class="form-control" id="desig" placeholder="e.g. Trainee, Secretary..." name="desig" autocomplete="off" required>
            </div>
        </div>    
        <div class="form-group">        
            <label for="user" class="text-color-2 col-sm-2 control-label">Username:</label>
            <div class="col-md-3">
            <input type="text" class="form-control" id="user" placeholder="Username" name="user" autocomplete="off" required>
            </div>
            <label for="pass" class="text-color-2 col-sm-2 control-label">Password:</label>
            <div class="col-md-3">      
            <input type="password" class="form-control" id="pass" placeholder="Password" name="pass" autocomplete="off" required> 
            </div>
        </div>        
        <div class="form-group" >        
            <label for="email" class="text-color-2 col-sm-2 control-label">Email:</label>
            <div class="col-md-3">      
            <input type="email" class="form-control" id="email" placeholder="Email" name="email" autocomplete="off"> 
            </div>
            <label for="con" class="text-color-2 col-sm-2 control-label">Contact:</label>
            <div class="col-md-3">      
            <input type="text" class="form-control" id="con" placeholder="Contact" name="con" autocomplete="off"> 
            </div>
        </div>
      <div class="form-group modal-footer">
        <input class="btn btn-success save col-sm-3 col-sm-offset-5" type="submit" value="Save">
      </div>
      </form>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->