<div class="col-md-12">
 <div class="container shadow col-md-12">
    <?php include('not_qualified_manage_table.php') ?> 
</div>
</div>


<?php include('update_not_qualified.php') ?>
<?php include('delete_not_qualified.php') ?>