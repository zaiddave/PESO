<?php
session_start();
include('meta-index.php') ?>

<title> PESO </title>

<?php include('head.php');

include('navbar_applicant.php');

include('job_interview_container_index.php') ?>


</body>

<script type="text/javascript">
$(document).ready(function($){
    $("#auto_venue").autocomplete({
        source: "json_data/json_venue.php",
        minLength: 1
    });             
    $("#auto_company").autocomplete({
        source: "json_data/json_company.php",
        minLength: 1
    }); 
    $("#sponsor").autocomplete({
        source: "json_data/json_sponsor.php",
        minLength: 1
    });  
});
</script>
<script src="assets/scrollable_menu.js" type="text/javascript"></script>
</hmtl>