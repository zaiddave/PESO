<?php
session_start();
include('meta-login.php') ?>

<title> PESO: Login </title>

<?php include('head_index.php') ?>

<body class="login-bg">

 
  <form class="login-container-fluid login-container form-horizontal shadow" action="login_form.php" method="post">
  <div class="col-sm-12">
  <?php
  if(isset($_SESSION['errlog'])){
    echo $_SESSION['errlog'];
    unset($_SESSION['errlog']);
  }
  ?>
</div>
  <div class="form-group">
    <label for="username" class="text-color col-sm-2 control-label">Username</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="username" placeholder="Username" name="username" autocomplete="off">
    </div>
  </div>
  <div class="form-group">
    <label for="password" class="text-color col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" id="password" placeholder="Password" name="password" autocomplete="off">
    </div>
  </div><!--
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
        <label class="text-color">
          <small>Forgot password?</small>
        </label>
      </div>
    </div>-->
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary add-job">Login</button>
      <strong>or</strong>
      <a href="index.php"><input type="button" class="btn btn-default" value="Go to User's Page"></a>
    </div>
  </div>

</form>
</body>
</html>
