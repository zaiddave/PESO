<?php
session_start();
require_once("db_con/connect.php");
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}
//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values
	$id = clean($_POST['id']);
	$company = clean($_POST['employer']);
	$vacancy = clean($_POST['vacancy']);
	$novacancy = clean($_POST['novacancy']);
	$gender = clean($_POST['gender']);
	$dateposting = clean($_POST['dateposting']);
	$status = clean($_POST['status']);
	$date = clean($_POST['date']);

	$query = "UPDATE ps_vacancy SET em_company_name ='$company', vac_vacancy='$vacancy', vac_no_of_vacancy='$novacancy', vac_gender='$gender', vac_date_posting='$dateposting', vac_status = '$status', vac_date = '$date' WHERE vac_id = $id";

	mysql_query($query) or die(mysql_error());


	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated <b>'.$company.'</b><span class="glyphicon glyphicon-exclamation-sign"></span></div>';
    $_SESSION['result1'] = $success;
	header('location:employer_manage.php#tab_job');

	?>