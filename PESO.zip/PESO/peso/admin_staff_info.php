<?
$user = $_SESSION['user'];
$type = $_SESSION['type'];
  $query = mysql_query("SELECT * FROM ps_login WHERE l_type = '$type' AND l_username = '$user' ");
  $row = mysql_fetch_array($query);
?>
<div class="col-md-8 col-md-offset-2">
 <div class="container shadow col-md-12">
<br><br>
<?if(isset($_SESSION['result'])){
  echo $_SESSION['result'];
  unset($_SESSION['result']);
}
?>
 <div class="panel-group">
  <div class="panel panel-primary">  
    <div class="panel-heading">
        <button class="btn btn-info btn-update pull-right" name="update" data-toggle="modal" data-target="#update_staff"
        data-id="<? echo $row['l_id']?>"
        data-fname="<?php echo $row['l_fname']?>"
        data-mname="<?php echo $row['l_mname']?>"
        data-lname="<?php echo $row['l_lname']?>"
        data-desig="<?php echo $row['l_desig']?>"
        data-con="<?php echo $row['l_con']?>"
        data-email="<?php echo $row['l_email']?>"
        ><span class="glyphicon glyphicon-edit"></span></button><p><b>Name:</b> <? echo $row['l_fname'].' '.$row['l_mname'].' '.$row['l_lname']?> </p>
    </div>    
    <div class="panel-body">
      <br>
      <div class="col-md-3">
          <img src="<?php echo $row['l_image'] ?>" class="img-responsive img-thumbnail center-block" height="250px" width="200px" alt="Thumbnail">
      </div>

      <div class="col-md-8 col-md-offset-1">
      <div class="row">
            <div class="col-md-2">
              <p><b>Designation:</b><p>
            </div>
            <div class="col-md-10">
              <p><?php echo $row['l_desig'] ?> </p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>Contact:</b><p>
            </div>
            <div class="col-md-10">
              <p><?php echo $row['l_con'] ?> </p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>Username:</b><p>
            </div>
            <div class="col-md-10">
              <p><?php echo $row['l_username'] ?> </p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p><b>Email:</b><p>
            </div>
            <div class="col-md-10">
              <p><?php echo $row['l_email'] ?> </p>
            </div>
          </div>   
          <div class="row">
            <div class="col-md-2">
              <p><b>Last Login:</b><p>
            </div>
            <div class="col-md-10">
              <p><?php echo $row['l_time'] ?> </p>
            </div>
          </div>      
      </div>
      <div class="row col-md-12">
    <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseUpdate" aria-expanded="false" aria-controls="collapseExample"><span class="glyphicon glyphicon-edit"></span> Change Username and Password</button>
            <div class="collapse" id="collapseUpdate">
              <div class="well">                   
                <form class="form-horizontal" method="post" action="admin_staff_password.php?id=<?php echo $row['l_id']?>" enctype="multipart/form-data">                 
                    <div class="form-group">        
                        <label for="user" class="text-color-2 col-sm-2 control-label">Username:</label>
                        <div class="col-md-3">
                        <input type="text" class="form-control" id="user" placeholder="Username" name="user" autocomplete="off" value="<?php echo $row['l_username']?>" >
                        </div>
                        <label for="prev" class="text-color-2 col-sm-2 control-label">Previous Password:</label>
                        <div class="col-md-3">      
                        <input type="password" class="form-control" id="prev" placeholder="Type Your Previous Password" name="prev" autocomplete="off" required> 
                        </div>            
                    </div>
                    <div class="form-group">
                      <label for="pass" class="text-color-2 col-sm-2 control-label">New Password:</label>
                        <div class="col-md-3">      
                        <input type="password" class="form-control" id="pass" placeholder="Password" name="pass" autocomplete="off" required> 
                        </div>
                        <label for="confirm" class="text-color-2 col-sm-2 control-label">Confirm Password:</label>
                        <div class="col-md-3">      
                        <input type="password" class="form-control" id="confirm" placeholder="Confirm Password" name="confirm" autocomplete="off" required> 
                        </div>
                    </div>
                    <button class="btn btn-info btn-update" type="submit" ><span class="glyphicon glyphicon-edit"></span> Save changes</button>
                    </form>
              </div>
            </div>
      </div>
    </div>  
    </div><!--panel-->
  </div><!--panel group-->
</div>
</div>