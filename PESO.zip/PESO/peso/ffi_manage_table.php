<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>Manage Your Lists of For Further Interview</b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>
   <div class="col-sm-12">
  <?php
  if(isset($_SESSION['result'])){
    echo $_SESSION['result'];
    unset($_SESSION['result']);
  }
  ?>
</div>
	                    <table id="table1" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Applicant Name</th>
									<th>Gender</th>
									<th>Age</th>
									<th>Contact Number</th>
									<th>Address</th>
									<th>Position Applied</th>
									<th>Company</th>
									<th>Manage</th>
								</tr>
							</thead>
							<tbody>
							<?php 									
									
									$fetch = mysql_query("SELECT * FROM ps_ffi ORDER BY ffi_lname ASC ") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                					$id = mysql_real_escape_string($row['j_id']);          						
                  			?>
								<tr>
									<td class="job-fair"><?php echo $row['ffi_lname'] .", ".$row['ffi_fname']." ".$row['ffi_mname']?></td>
									<td class="job-fair"><?php echo $row['ffi_gender'] ?></td>
									<td class="job-fair"><?php echo $row['ffi_age'] ?></td>
									<td class="job-fair"><?php echo $row['ffi_cellphone'] ?></td>
									<td class="job-fair"><?php echo $row['ffi_address'] ?></td>
									<td class="job-fair"><?php echo $row['ffi_applied'] ?></td>
									<td class="job-fair">
									<a href="#!" data-toggle="tooltip" data-placement="top" title="<?php
									$fetch2 = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_id = $id ");
									$tip = mysql_fetch_array($fetch2);
									echo $tip['j_employment_type'];
									 ?>">
									<?php echo $row['ffi_company'] ?>
									</a>
									</td>
									<td class="job-fair"><a data-toggle="tooltip" data-placement="bottom" title="Update."><button class="btn btn-primary" aria-label="Edit" data-toggle="modal" data-target="#update_ffi"
									data-ffi-id="<?php echo $row['j_id'] ?>"
									data-fname="<?php echo $row['ffi_fname']?>"
									data-mname="<?php echo $row['ffi_mname']?>"
									data-lname="<?php echo $row['ffi_lname']?>"
									data-age="<?php echo $row['ffi_age']?>"
									data-cellphone="<?php echo $row['ffi_cellphone']?>"
									data-address="<?php echo $row['ffi_address']?>"									
									data-applied="<?php echo $row['ffi_applied']?>"
									data-sponsor="<?php echo $row['ffi_sponsor']?>"
									data-company="<?php echo $row['ffi_company']?>"
									data-venue="<?php echo $row['ffi_venue']?>"
									>
									<span class="glyphicon glyphicon-edit"></span></button></a><br>
									<br><a data-toggle="tooltip" data-placement="top" title="Delete."><button class="btn btn-danger" aria-label="Delete" data-toggle="modal" data-target="#delete_ffi" data-delete-id="<?php echo $row['j_id']?>" ><span class="glyphicon glyphicon-trash"></span></button></a></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                  </div>
                </div>