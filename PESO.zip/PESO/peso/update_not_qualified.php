<div class="modal fade" data-keyboard="false" data-backdrop="static" id="update_notqualified" tabindex="-1" role="dialog" aria-labelledby="update_notqualifiedLabel" aria-hidden="true">
	<div class="modal-dialog ">
    	<div class="modal-content">
      		<div class="modal-header update">
        		<button type="button" data-dismiss="modal" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        		<h4 class="modal-title" id="update_notqualifiedLabel"><center><strong>Update</strong></center></h4>
      		</div>

	<div class="modal-body">
		<form class="form-horizontal" method="post" action="not_qualified_update.php" enctype="multipart/form-data">
			<div style="margin-right:20px; margin-left:20px;">

    <input type="hidden" class="form-control" name="id">

    <div class="form-group">
        <label for="applicant" class="text-color-2">Applicant Name:</label><br>
      <div class="col-sm-4">
        <input type="text" class="form-control" id="fname" placeholder="First Name" name="fname" required>
      </div>
      <div class="col-sm-4">
          <input type="text" class="form-control" id="mname" placeholder="Middle Name" name="mname">
      </div>
      <div class="col-sm-4">
          <input type="text" class="form-control" id="lname" placeholder="Last Name" name="lname" required>
      </div>
    </div>

    <div class="form-group">
    <label for="gender" class="text-color-2">Gender:</label><br>
        <div class="col-sm-10" style="padding-top:6px;">
        <div class="btn-group" data-toggle="buttons">
        <label class="btn btn-primary btn-enhance-primary">
          <input type="radio" name="gender" value="Male" id="gender" required>&nbsp;Male
        </label>
        <label class="btn btn-primary btn-enhance-primary">
          <input type="radio" name="gender" value="Female" id="gender" required>&nbsp;Female
        </label>
        </div>
        </div>
  </div>

    <div class="form-group">
        <label for="address" class="text-color-2">Age:</label><br>
      <div class="col-sm-4">      
          <input type="text" class="form-control" id="age" placeholder="Age" name="age" required>      
      </div>
  </div>

  <div class= "form-group">
      <label for="cell" class="text-color-2">Cellphone No.:</label><br>
        <div class="col-sm-4 ">
        <textarea rows="2" class="form-control" id="cell" placeholder="Cellphone No." name="cell" ></textarea>      
        </div>
  </div>

  <div class="form-group">
        <label for="address" class="text-color-2">Address:</label><br>
      <div class="col-sm-12">      
          <textarea rows="2" class="form-control" id="address" placeholder="Address" name="address" required></textarea>      
      </div>
  </div>

<div class="form-group">
        <label for="applied" class="text-color-2">Position Applied:</label><br>
      <div class="col-sm-12">      
          <textarea rows="2" class="form-control" id="applied" placeholder="Position Applied" name="applied" required></textarea>      
      </div>
  </div>

  <div class="form-group">
        <label for="sponsor" class="text-color-2">Sponsor:</label><br>
      <div class="col-sm-12">      
          <input type="text" class="form-control" id="sponsor" placeholder="Sponsor/Organizer" name="sponsor" required>
      </div>
  </div>

  <div class="form-group">
        <label for="company" class="text-color-2">Company Name:</label><br>
      <div class="col-sm-12">      
          <input type="text" class="form-control" id="company" placeholder="Company" name="company" required>
      </div>
  </div>

  <div class="form-group">
        <label for="venue" class="text-color-2">Venue:</label><br>
      <div class="col-sm-12">      
          <input type="text" class="form-control" id="venue" placeholder="Venue" name="venue" required>
      </div>
  </div>

  <div class="form-group">
    <label for="employmentType" class="text-color-2">Employment Type:</label>
    <div class="col-sm-12">
    <select class="form-control" id="employmentType" name="employmentType" required>
        <option value="" selected="selected">SELECT</option>
        <option value="POEA Licensed Agencies">POEA Licensed Agencies</option>
        <option value="LOCAL Companies">LOCAL Companies</option>
        <option value="BPO Companies">BPO Companies</option>        
      </select>
    </div>
  </div>

   <div class="form-group">
    <label for="status" class="text-color-2">Status:</label>
        <div class="col-sm-12 btn-group" data-toggle="buttons" style="padding-top:6px;">        
        <label class="btn btn-warning btn-enhance-warning">
          <input type="radio" name="status" value="Qualified" id="status">Qualified
          </label>
          <label class="btn btn-warning btn-enhance-warning">
          <input type="radio" name="status" value="Not Qualified" id="status">Not Qualified
          </label>
          <label class="btn btn-warning btn-enhance-warning">
          <input type="radio" name="status" value="FFI" id="status">FFI              
          </label>
          <label class="btn btn-warning btn-enhance-warning">
          <input type="radio" name="status" value="HOTS" id="status">HOTS
          </label>
        </div>
  </div>

  <br>

<div class="form-group modal-footer">
                 <input class="btn btn-info btn-update col-xs-3 col-xs-offset-4 col-sm-2 col-sm-offset-5 col-md-2 col-md-offset-5" type="submit" value="Update">
</div>



</div>
</form>
</div>

      	</div>
	</div>
</div>