     <div class="col-sm-12">
  <?php
  if(isset($_SESSION['result'])){
    echo $_SESSION['result'];
    unset($_SESSION['result']);
  }
  ?>
</div>
	                    <table id="table1" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Type of Employment</th>
									<th>Company Name</th>
									<th>Available Permits</th>
									<th>Representative</th>
									<th>Designation</th>
									<th>Telephone Number</th>
									<th>Cellphone Number</th>
									<th>Email</th>
									<th>Manage</th>
								</tr>
							</thead>
							<tbody>
							<?php 									
									
									$fetch = mysql_query("SELECT * FROM ps_employer_registry ORDER BY em_company_name ASC ") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                  			?>
								<tr>
									<td class="job-fair-year"><strong><?php echo $row['em_employment_type'] ?></strong></td>
									<td class="job-fair"><?php echo $row['em_company_name'] ?></td>
									<td class="job-fair"><?php echo nl2br("&#x02022 ". $row['em_business']."\n &#x02022 ".$row['em_mayor']."\n &#x02022 ".$row['em_bir']) ?></td>
									<td class="job-fair"><?php echo nl2br($row['em_representative']."\n") ?> </td>
									<td class="job-fair"><?php echo nl2br($row['em_designation']."\n") ?></td>
									<td class="job-fair"><?php echo nl2br($row['em_telephone']."\n") ?></td>
									<td class="job-fair"><?php echo nl2br($row['em_cellphone']."\n") ?></td>
									<td class="job-fair"><?php echo nl2br($row['em_email']."\n") ?></td>
									<td class="job-fair"><a data-toggle="tooltip" data-placement="bottom" title="Update."><button class="btn btn-primary" aria-label="Edit" data-toggle="modal" data-target="#update_employer"
									data-company-id="<?php echo $row['em_id'] ?>"
									data-type="<?php echo $row['em_employment_type']?>"
									data-company="<?php echo $row['em_company_name'] ?>"
									data-representative="<?php echo $row['em_representative'] ?>"
									data-designation="<? echo $row['em_designation'] ?>"
									data-telephone="<?php echo $row['em_telephone'] ?>"
									data-cellphone="<?php echo $row['em_cellphone'] ?>"
									data-email="<?php echo $row['em_email'] ?>" >

									<span class="glyphicon glyphicon-edit"></span></button></a><br><br>
									<a data-toggle="tooltip" data-placement="top" title="Delete.">
									<button class="btn btn-danger" aria-label="Delete" data-toggle="modal" data-target="#delete_employer" data-delete-id="<?php echo $row['em_id']?>" ><span class="glyphicon glyphicon-trash"></span></button></a></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                
                