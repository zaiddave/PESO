<div class="col-md-12">
 <div class="container shadow col-md-12">
 	<ul class="nav nav-tabs nav-justified" id="admin-admin-tab">
    <li class="active"><a data-toggle="tab" href="#employer">Company Report</a></li>
    <li><a data-toggle="tab" href="#job">Job Vacancy Report</a></li>
</ul><!--nav tabs-->

<div class="tab-content">
    <? include('employer_report_tab.php') ?>
    <? include('vacancy_report_tab.php') ?>
</div><!--tab content-->
 </div>
 </div>