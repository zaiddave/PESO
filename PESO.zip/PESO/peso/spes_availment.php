<?php
session_start();
include('meta.php') ?>

<title> PESO </title>

<?php

include('spes_head.php');

?>

<script type="text/javascript">
    
    $(window).load(function(){
        $('#spes_availment').modal('show');
    });


    $(document).ready(function(){
    $('#table0').DataTable({
        dom: '<l>Bfrtip',
        buttons: [       
        ],
        "ordering": false,
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "scrollX": true

    });
	})

</script>




<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="bg" onload=display_ct();>

<?

include('navbar_registration.php');

include('spes_report_container.php') ?> 


</body>
</html>

<?
include('spes_availment_modal.php')
?>