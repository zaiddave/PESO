<div class="col-md-12">
 <div class="container shadow col-md-12">
 	<ul class="nav nav-tabs nav-justified" id="admin-admin-tab">
    <li class="active"><a data-toggle="tab" href="#employer">Company</a></li>
    <li><a data-toggle="tab" href="#job">Job Vacancy</a></li>
</ul><!--nav tabs-->

<div class="tab-content">
    <? include('employer_manage_tab.php') ?>
    <? include('vacancy_manage_tab.php') ?>
</div><!--tab content-->
 </div>
</div>

<?php include('update_employer.php') ?>
<?php include('delete_employer.php') ?>
<?php include('update_vacancy.php') ?>
<?php include('delete_vacancy.php') ?>