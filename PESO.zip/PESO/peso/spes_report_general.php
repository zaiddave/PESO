<?php
session_start();

include('meta.php') ?>

<title>PESO</title>
<?php
include('head.php');

include('navbar.php');

include('spes_report_general_container.php');

 ?> 


</body>
</html>