<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}

//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values

	$type = clean($_POST['type']);
	$company = strtoupper(clean($_POST['company']));
	$business = clean($_POST['business']);
	$mayor = clean($_POST['mayor']);
	$bir = clean($_POST['bir']);
  	$representative = strtoupper(clean($_POST['representative']));
  	$designation = strtoupper(clean($_POST['designation']));
	$telephone = clean($_POST['telephone']);
	$cell = clean($_POST['cell']);
	$email = clean($_POST['email']);

	

	
	if($type == "default"){
		$error = '<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign"></span> Please select an <b>Employment Type</b>.</div>';

      	$_SESSION['result'] = $error;
		header('location:employer.php');
	}
/*	elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
		$error = '<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign"></span> Invalid email address</div>';

      	$_SESSION['result'] = $error;
		header('location:employer.php');
	}*/
	else{
		$query = "SELECT * FROM  ps_employer_registry WHERE em_company_name = '$company' ";
		$result = mysql_query($query) or die(mysql_error());
	
	if($result) {
		//returns an error if there already exist another company name
		if(mysql_num_rows($result) > 0) {		
		$error = '<div class="alert alert-danger" role="alert">The company <b>'.$company.'</b> already exist. Please update it instead <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result'] = $error;
		header('location:employer.php');	
		}
		else{
				
			$query = "INSERT INTO ps_employer_registry (em_employment_type, em_company_name, em_business, em_mayor, em_bir, em_representative, em_designation, em_telephone, em_cellphone, em_email) VALUES  ('$type', '$company', '$business','$mayor','$bir', '$representative', '$designation', '$telephone', '$cell', '$email')";

			mysql_query($query) or die(mysql_error());

			$success = '<div class="alert alert-success" role="alert"><b>Successfully</b> save <b>'.$company.'</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      		$_SESSION['result'] = $success;
			header('location:employer.php');	
				
			}
		}
		else{
			die(mysql_error());
		}
	}
				




?>