<div class="col-md-12">
 <div class="container shadow col-md-12">
    <? include('applicant_manage_table.php') ?> 
</div>
</div>


<?php include('update_applicant.php') ?>
<?php include('delete_applicant.php') ?>