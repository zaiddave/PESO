<div id="employer" class="tab-pane fade in active">
  
  <div class="panel-group">
    <div class="panel panel-success">
      <div class="panel-heading"><center><h4><b>Company Report</b></h4></center></div>
        <div class="panel-body">
          <?php include('employer_report_table.php') ?>
      </div><!--body-->       
    </div><!--panel login-->
  </div><!--panel group-->
</div><!-- tab pane fade-->