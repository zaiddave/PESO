<div id="job" class="tab-pane fade in">
  
  <div class="panel-group">
    <div class="panel panel-warning">
      <div class="panel-heading"><center><h4><b>Manage Your Available Job Report</b></h4></center></div>
        <div class="panel-body">
          <?php include('vacancy_manage_table.php') ?>
      </div><!--body-->       
    </div><!--panel login-->
  </div><!--panel group-->
</div><!-- tab pane fade-->