-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 01, 2017 at 06:40 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `peso_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `ps_applicant_registry`
--

CREATE TABLE IF NOT EXISTS `ps_applicant_registry` (
  `ap_id` int(11) NOT NULL AUTO_INCREMENT,
  `ap_fname` varchar(255) NOT NULL,
  `ap_mname` varchar(255) NOT NULL,
  `ap_lname` varchar(255) NOT NULL,
  `ap_gender` varchar(255) NOT NULL,
  `ap_bdate` varchar(255) NOT NULL,
  `ap_age` varchar(255) NOT NULL,
  `ap_address` varchar(255) NOT NULL,
  `ap_telephone` varchar(255) NOT NULL,
  `ap_cellphone` varchar(255) NOT NULL,
  `ap_email` varchar(255) NOT NULL,
  `ap_course` varchar(255) NOT NULL,
  `ap_from_date` varchar(255) NOT NULL,
  `ap_pref_job` varchar(255) NOT NULL,
  `ap_educ_bg` varchar(255) NOT NULL,
  PRIMARY KEY (`ap_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ps_applicant_registry`
--

INSERT INTO `ps_applicant_registry` (`ap_id`, `ap_fname`, `ap_mname`, `ap_lname`, `ap_gender`, `ap_bdate`, `ap_age`, `ap_address`, `ap_telephone`, `ap_cellphone`, `ap_email`, `ap_course`, `ap_from_date`, `ap_pref_job`, `ap_educ_bg`) VALUES
(1, 'Miame', 'Carmen', 'Torreblanca', 'Female', '12/22/1980', '36', 'Royal Palm Subd., Bacolod City, Neg. Occ.', '', '09260524641', '', 'Bachelor of Elementary Education', '12/28/2016', 'Housekeeping;\r\nEncoder;\r\nAssistant Teacher', 'College Graduate');

-- --------------------------------------------------------

--
-- Table structure for table `ps_brgy`
--

CREATE TABLE IF NOT EXISTS `ps_brgy` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(255) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ps_city`
--

CREATE TABLE IF NOT EXISTS `ps_city` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(255) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ps_course`
--

CREATE TABLE IF NOT EXISTS `ps_course` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_course` varchar(255) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ps_course`
--

INSERT INTO `ps_course` (`c_id`, `c_course`) VALUES
(1, 'Bachelor of Elementary Education'),
(2, 'adasd');

-- --------------------------------------------------------

--
-- Table structure for table `ps_employer_registry`
--

CREATE TABLE IF NOT EXISTS `ps_employer_registry` (
  `em_id` int(11) NOT NULL AUTO_INCREMENT,
  `em_employment_type` varchar(255) NOT NULL,
  `em_company_name` varchar(255) NOT NULL,
  `em_business` varchar(255) NOT NULL,
  `em_mayor` varchar(255) NOT NULL,
  `em_bir` varchar(255) NOT NULL,
  `em_representative` varchar(255) NOT NULL,
  `em_designation` varchar(255) NOT NULL,
  `em_telephone` varchar(255) NOT NULL,
  `em_cellphone` varchar(255) NOT NULL,
  `em_email` varchar(255) NOT NULL,
  PRIMARY KEY (`em_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ps_employer_registry`
--

INSERT INTO `ps_employer_registry` (`em_id`, `em_employment_type`, `em_company_name`, `em_business`, `em_mayor`, `em_bir`, `em_representative`, `em_designation`, `em_telephone`, `em_cellphone`, `em_email`) VALUES
(1, '', '', '', '', '', '', '', '', '', ''),
(2, 'LOCAL Companies', 'D'' AVID', 'Business Permit (DTI)', '', 'BIR/SEC Registration', 'David', 'CEO', '09090909', '090909909', 'zaidd@gmail.com'),
(3, 'LOCAL Companies', 'DaViDe', '', 'Mayor''s Permit', '', 'Dave', 'CEO', '0909900', '09090909', 'asd@asdsa'),
(4, 'A VID', 'a vid', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ps_ffi`
--

CREATE TABLE IF NOT EXISTS `ps_ffi` (
  `ffi_id` int(11) NOT NULL AUTO_INCREMENT,
  `j_id` int(11) NOT NULL,
  `ffi_fname` varchar(255) NOT NULL,
  `ffi_mname` varchar(255) NOT NULL,
  `ffi_lname` varchar(255) NOT NULL,
  `ffi_applied` varchar(255) NOT NULL,
  `ffi_gender` varchar(255) NOT NULL,
  `ffi_age` int(11) NOT NULL,
  `ffi_telephone` varchar(255) NOT NULL,
  `ffi_cellphone` varchar(255) NOT NULL,
  `ffi_email` varchar(255) NOT NULL,
  `ffi_address` varchar(255) NOT NULL,
  `ffi_company` varchar(255) NOT NULL,
  `ffi_recruitment_type` varchar(255) NOT NULL,
  `ffi_activity_date` varchar(255) NOT NULL,
  `ffi_sponsor` varchar(255) NOT NULL,
  `ffi_venue` varchar(255) NOT NULL,
  PRIMARY KEY (`ffi_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ps_ffi`
--

INSERT INTO `ps_ffi` (`ffi_id`, `j_id`, `ffi_fname`, `ffi_mname`, `ffi_lname`, `ffi_applied`, `ffi_gender`, `ffi_age`, `ffi_telephone`, `ffi_cellphone`, `ffi_email`, `ffi_address`, `ffi_company`, `ffi_recruitment_type`, `ffi_activity_date`, `ffi_sponsor`, `ffi_venue`) VALUES
(1, 0, 'dave', '', '', '', '', 0, '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ps_hots`
--

CREATE TABLE IF NOT EXISTS `ps_hots` (
  `hots_id` int(11) NOT NULL AUTO_INCREMENT,
  `j_id` int(11) NOT NULL,
  `hots_fname` varchar(255) NOT NULL,
  `hots_mname` varchar(255) NOT NULL,
  `hots_lname` varchar(255) NOT NULL,
  `hots_applied` varchar(255) NOT NULL,
  `hots_gender` varchar(255) NOT NULL,
  `hots_age` int(11) NOT NULL,
  `hots_telephone` varchar(255) NOT NULL,
  `hots_cellphone` varchar(255) NOT NULL,
  `hots_email` varchar(255) NOT NULL,
  `hots_address` varchar(255) NOT NULL,
  `hots_company` varchar(255) NOT NULL,
  `hots_recruitment_type` varchar(255) NOT NULL,
  `hots_activity_date` varchar(255) NOT NULL,
  `hots_sponsor` varchar(255) NOT NULL,
  `hots_venue` varchar(255) NOT NULL,
  `hots_employed` varchar(255) NOT NULL,
  PRIMARY KEY (`hots_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ps_hots`
--

INSERT INTO `ps_hots` (`hots_id`, `j_id`, `hots_fname`, `hots_mname`, `hots_lname`, `hots_applied`, `hots_gender`, `hots_age`, `hots_telephone`, `hots_cellphone`, `hots_email`, `hots_address`, `hots_company`, `hots_recruitment_type`, `hots_activity_date`, `hots_sponsor`, `hots_venue`, `hots_employed`) VALUES
(1, 2, 'mark', 'mark', 'mark', 'mark', 'Female', 21, '1231', '32432423', 'mark@mark', 'bacolod', 'mark', '2017-January-Job Fair', '01/01/2017', 'sm', 'sm-event', 'Not Employed'),
(2, 3, 'Dave', 'O.', 'Diaz', 'Web', 'Male', 21, '1231', '12313', 'asdsa', '1231qweqw', 'Maw', '2017-January-SRA', '01/09/2017', 'qwe', 'qwe', '');

-- --------------------------------------------------------

--
-- Table structure for table `ps_job_interview_form`
--

CREATE TABLE IF NOT EXISTS `ps_job_interview_form` (
  `j_id` int(11) NOT NULL AUTO_INCREMENT,
  `j_year` varchar(255) NOT NULL,
  `j_month` varchar(255) NOT NULL,
  `j_type` varchar(255) NOT NULL,
  `j_recruitment_type` varchar(255) NOT NULL,
  `j_sponsor` varchar(255) NOT NULL,
  `j_date` varchar(255) NOT NULL,
  `j_venue` varchar(255) NOT NULL,
  `j_activity_date` varchar(255) NOT NULL,
  `j_employment_type` varchar(255) NOT NULL,
  `j_company_name` varchar(255) NOT NULL,
  `j_position_applied` varchar(255) NOT NULL,
  `j_gender` varchar(255) NOT NULL,
  `j_status` varchar(255) NOT NULL,
  PRIMARY KEY (`j_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ps_job_interview_form`
--

INSERT INTO `ps_job_interview_form` (`j_id`, `j_year`, `j_month`, `j_type`, `j_recruitment_type`, `j_sponsor`, `j_date`, `j_venue`, `j_activity_date`, `j_employment_type`, `j_company_name`, `j_position_applied`, `j_gender`, `j_status`) VALUES
(1, '2017', 'January', 'Job Fair', '2017-January-Job Fair', '', '01/01/2017', 'sm-event', '01/01/2017 - sm-event', 'POEA Licensed Agencies', 'mars', 'mars', 'Male', 'Qualified'),
(2, '2017', 'January', 'Job Fair', '2017-January-Job Fair', '', '01/01/2017', 'sm-event', '01/01/2017 - sm-event', 'POEA Licensed Agencies', 'mark', 'mark', 'Female', 'HOTS'),
(3, '2017', 'January', 'SRA', '2017-January-SRA', '', '01/09/2017', 'qwe', '01/09/2017 - qwe', 'POEA Licensed Agencies', 'Maw', 'Web', 'Male', 'HOTS');

-- --------------------------------------------------------

--
-- Table structure for table `ps_lgu`
--

CREATE TABLE IF NOT EXISTS `ps_lgu` (
  `l_id` int(11) NOT NULL AUTO_INCREMENT,
  `l_name` varchar(255) NOT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ps_login`
--

CREATE TABLE IF NOT EXISTS `ps_login` (
  `l_id` int(11) NOT NULL AUTO_INCREMENT,
  `l_fname` varchar(255) NOT NULL,
  `l_mname` varchar(255) NOT NULL,
  `l_lname` varchar(255) NOT NULL,
  `l_desig` varchar(255) NOT NULL,
  `l_type` varchar(255) NOT NULL,
  `l_username` varchar(255) NOT NULL,
  `l_password` varchar(255) NOT NULL,
  `l_email` varchar(255) NOT NULL,
  `l_con` varchar(255) NOT NULL,
  `l_image` varchar(255) NOT NULL,
  `l_time` datetime NOT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ps_login`
--

INSERT INTO `ps_login` (`l_id`, `l_fname`, `l_mname`, `l_lname`, `l_desig`, `l_type`, `l_username`, `l_password`, `l_email`, `l_con`, `l_image`, `l_time`) VALUES
(2, 'Sharon', 'A.', 'Juance', 'Coordinator', 'Official', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'test@test', '12345', 'admin/Koala.jpg', '2017-01-31 17:13:47'),
(3, 'Alfredo', 'G.', 'MaraÅˆon, Jr.', 'Governor', 'Official', '', '', '', '', '', '0000-00-00 00:00:00'),
(4, 'Gerard Inocentes', 'J.', 'Tupas', 'Manager', 'Official', '', '', '', '', '', '0000-00-00 00:00:00'),
(5, 'Joshua Matthew', 'Y', 'Antonio', 'Student Trainee', 'Staff', 'josh', 'f94adcc3ddda04a8f34928d862f404b4', 'josh@email', '00988765', 'admin/star1.png', '2017-02-01 13:40:09');

-- --------------------------------------------------------

--
-- Table structure for table `ps_not_qualified`
--

CREATE TABLE IF NOT EXISTS `ps_not_qualified` (
  `qn_id` int(11) NOT NULL AUTO_INCREMENT,
  `j_id` int(11) NOT NULL,
  `qn_fname` varchar(255) NOT NULL,
  `qn_mname` varchar(255) NOT NULL,
  `qn_lname` varchar(255) NOT NULL,
  `qn_applied` varchar(255) NOT NULL,
  `qn_gender` varchar(255) NOT NULL,
  `qn_age` int(11) NOT NULL,
  `qn_telephone` varchar(255) NOT NULL,
  `qn_cellphone` varchar(255) NOT NULL,
  `qn_email` varchar(255) NOT NULL,
  `qn_address` varchar(255) NOT NULL,
  `qn_company` varchar(255) NOT NULL,
  `qn_recruitment_type` varchar(255) NOT NULL,
  `qn_activity_date` varchar(255) NOT NULL,
  `qn_sponsor` varchar(255) NOT NULL,
  `qn_venue` varchar(255) NOT NULL,
  PRIMARY KEY (`qn_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ps_not_qualified`
--

INSERT INTO `ps_not_qualified` (`qn_id`, `j_id`, `qn_fname`, `qn_mname`, `qn_lname`, `qn_applied`, `qn_gender`, `qn_age`, `qn_telephone`, `qn_cellphone`, `qn_email`, `qn_address`, `qn_company`, `qn_recruitment_type`, `qn_activity_date`, `qn_sponsor`, `qn_venue`) VALUES
(1, 0, 'dave', '', '', '', '', 0, '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ps_preferred`
--

CREATE TABLE IF NOT EXISTS `ps_preferred` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_name` varchar(255) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ps_qualified`
--

CREATE TABLE IF NOT EXISTS `ps_qualified` (
  `q_id` int(11) NOT NULL AUTO_INCREMENT,
  `j_id` int(11) NOT NULL,
  `q_fname` varchar(255) NOT NULL,
  `q_mname` varchar(255) NOT NULL,
  `q_lname` varchar(255) NOT NULL,
  `q_applied` varchar(255) NOT NULL,
  `q_gender` varchar(255) NOT NULL,
  `q_age` int(11) NOT NULL,
  `q_telephone` varchar(255) NOT NULL,
  `q_cellphone` varchar(255) NOT NULL,
  `q_email` varchar(255) NOT NULL,
  `q_address` varchar(255) NOT NULL,
  `q_company` varchar(255) NOT NULL,
  `q_recruitment_type` varchar(255) NOT NULL,
  `q_activity_date` varchar(255) NOT NULL,
  `q_sponsor` varchar(255) NOT NULL,
  `q_venue` varchar(255) NOT NULL,
  PRIMARY KEY (`q_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ps_qualified`
--

INSERT INTO `ps_qualified` (`q_id`, `j_id`, `q_fname`, `q_mname`, `q_lname`, `q_applied`, `q_gender`, `q_age`, `q_telephone`, `q_cellphone`, `q_email`, `q_address`, `q_company`, `q_recruitment_type`, `q_activity_date`, `q_sponsor`, `q_venue`) VALUES
(1, 1, 'mars', 'mars', 'mars', 'mars', 'Male', 21, '42342', '324234', 'mars@mars', 'bacolod', 'mars', '2017-January-Job Fair', '01/01/2017', 'sm', 'sm-event');

-- --------------------------------------------------------

--
-- Table structure for table `ps_recruitment_type`
--

CREATE TABLE IF NOT EXISTS `ps_recruitment_type` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `r_type` varchar(255) NOT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ps_spes`
--

CREATE TABLE IF NOT EXISTS `ps_spes` (
  `sp_id` int(11) NOT NULL AUTO_INCREMENT,
  `sp_fname` varchar(255) NOT NULL,
  `sp_mname` varchar(255) NOT NULL,
  `sp_lname` varchar(255) NOT NULL,
  `sp_gender` varchar(255) NOT NULL,
  `sp_edu` varchar(255) NOT NULL,
  `sp_brgy` varchar(255) NOT NULL,
  `sp_city` varchar(255) NOT NULL,
  `sp_date_of_birth` varchar(255) NOT NULL,
  `sp_age` varchar(255) NOT NULL,
  `sp_lgu` varchar(255) NOT NULL,
  `sp_first_year` varchar(255) NOT NULL,
  `sp_second_year` varchar(255) NOT NULL,
  `sp_third_year` varchar(255) NOT NULL,
  `sp_batch_first_year` varchar(255) NOT NULL,
  `sp_batch_second_year` varchar(255) NOT NULL,
  `sp_batch_third_year` varchar(255) NOT NULL,
  `sp_first_availment` varchar(255) NOT NULL,
  `sp_second_availment` varchar(255) NOT NULL,
  `sp_third_availment` varchar(255) NOT NULL,
  `sp_grade_first` varchar(255) NOT NULL,
  `sp_grade_second` varchar(255) NOT NULL,
  `sp_grade_third` varchar(255) NOT NULL,
  PRIMARY KEY (`sp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `ps_spes`
--

INSERT INTO `ps_spes` (`sp_id`, `sp_fname`, `sp_mname`, `sp_lname`, `sp_gender`, `sp_edu`, `sp_brgy`, `sp_city`, `sp_date_of_birth`, `sp_age`, `sp_lgu`, `sp_first_year`, `sp_second_year`, `sp_third_year`, `sp_batch_first_year`, `sp_batch_second_year`, `sp_batch_third_year`, `sp_first_availment`, `sp_second_availment`, `sp_third_availment`, `sp_grade_first`, `sp_grade_second`, `sp_grade_third`) VALUES
(1, 'Davidee', 'O.', 'Diaz', 'Male', '5th Year College', 'Bata', 'Bacolod', '10/12/1995', '21', 'Bacolod', '2013', '2000', '2100', 'Batch 1', 'Batch 1', 'Batch 3', 'First Availment', 'Second Availment', 'Third Availment', '90', '90', '99'),
(2, 'Marceeaa', 'D.', 'De Los Santos', 'Male', '4th Year College', 'Sum-ag', 'Bacolod', '01/23/2017', '0', 'Sumbag', '2014', '2015', '2016', 'Batch 3', 'Batch 2', 'Batch 1', 'First Availment', 'Second Availment', 'Second Availment', '99', '98', '91'),
(4, 'DAVE', 'DAVE', 'DAVE', 'Male', '5th Year College', 'BATA', 'BACOLOD', '01/24/2017', '0', 'BACOLOD', '2016', 'Not Yet Availed', 'Not Yet Availed', 'Batch 1', 'Not Yet Availed', 'Not Yet Availed', 'First Availment', 'Not Yet Availed', 'Not Yet Availed', '99', '', ''),
(10, 'dad', 'dada', 'dad', 'Male', '2nd Year High School/Grade 8 (For Kto12)', 'dad', 'dada', '01/24/2017', '0', 'dada', '2000', 'Not Yet Availed', 'Not Yet Availed', 'Batch 1', 'Not Yet Availed', 'Not Yet Availed', 'First Availment', 'Not Yet Availed', 'Not Yet Availed', '90', '', ''),
(11, 'Princess', 'E.', 'A', 'Male', '2nd Year High School/Grade 8 (For Kto12)', 'asdas', 'asd', '01/24/2017', '0', 'asd', '2000', '2000', '2000', 'Batch 1', 'Batch 1', 'Batch 1', 'First Availment', 'Second Availment', 'Third Availment', '12', '12', '12'),
(15, 'DAVID', 'O', 'DIAZ', 'Male', '4th Year College', 'BATA', 'BACOLOD', '10/12/1995', '21', 'CITY', '2000', '2000', '2001', 'Batch 1', 'Batch 1', 'Batch 1', 'First Availment', 'Second Availment', 'Third Availment', '90', '90', '99'),
(16, 'Dave', 'O.', 'Diaz', 'Male', '5th Year College', 'Bata', 'Bacolod', '10/12/1995', '21', 'City', '2100', '2100', 'Not Yet Availed', 'Batch 4', 'Batch 4', 'Not Yet Availed', 'First Availment', 'Second Availment', 'Not Yet Availed', '90', '90', '');

-- --------------------------------------------------------

--
-- Table structure for table `ps_sponsor`
--

CREATE TABLE IF NOT EXISTS `ps_sponsor` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_name` varchar(255) NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ps_sponsor`
--

INSERT INTO `ps_sponsor` (`s_id`, `s_name`) VALUES
(1, 'sm'),
(2, 'qwe');

-- --------------------------------------------------------

--
-- Table structure for table `ps_vacancy`
--

CREATE TABLE IF NOT EXISTS `ps_vacancy` (
  `vac_id` int(11) NOT NULL AUTO_INCREMENT,
  `em_company_name` varchar(255) NOT NULL,
  `vac_vacancy` varchar(255) NOT NULL,
  `vac_no_of_vacancy` int(11) NOT NULL,
  `vac_gender` varchar(255) NOT NULL,
  `vac_date_posting` varchar(255) NOT NULL,
  `vac_status` varchar(255) NOT NULL,
  `vac_date` varchar(255) NOT NULL,
  PRIMARY KEY (`vac_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ps_vacancy`
--

INSERT INTO `ps_vacancy` (`vac_id`, `em_company_name`, `vac_vacancy`, `vac_no_of_vacancy`, `vac_gender`, `vac_date_posting`, `vac_status`, `vac_date`) VALUES
(1, 'D''avid', '', 0, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ps_venue`
--

CREATE TABLE IF NOT EXISTS `ps_venue` (
  `v_id` int(11) NOT NULL AUTO_INCREMENT,
  `v_name` varchar(255) NOT NULL,
  PRIMARY KEY (`v_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ps_venue`
--

INSERT INTO `ps_venue` (`v_id`, `v_name`) VALUES
(1, 'sm-event'),
(2, 'qwe');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
