
	                    <table id="table" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Type of Employment</th>
									<th>Company Name</th>
									<th>Available Permits</th>
									<th>Representative</th>
									<th>Designation</th>
									<th>Telephone Number</th>
									<th>Cellphone Number</th>
									<th>Email</th>
								</tr>
							</thead>
							<tbody>
							<?php 									
									
									$fetch = mysql_query("SELECT DISTINCT em_employment_type FROM ps_employer_registry ORDER BY em_employment_type ASC ") or die(mysql_error());

                					while($row = mysql_fetch_array($fetch)){
                					$employment = mysql_real_escape_string($row['em_employment_type']);
                  				?>
								<tr>
									<td class="job-fair-year"><?php echo $row['em_employment_type'] ?></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
									<td class="job-fair-year"></td>
								</tr>
								<tr>
								<?php 									
									
									$fetch1 = mysql_query("SELECT * FROM ps_employer_registry WHERE em_employment_type = '$employment' ORDER BY em_company_name ASC") or die(mysql_error());
                					while($row1 = mysql_fetch_array($fetch1)){
                  				?>
								<td></td>
								<td class="job-fair"><?php echo $row1['em_company_name'] ?></td>
									<td class="job-fair"><?php echo nl2br("&#x02022 ".$row1['em_business']."\n &#x02022 ".$row1['em_mayor']."\n &#x02022 ".$row1['em_bir']) ?></td>
									<td class="job-fair"><?php echo nl2br($row1['em_representative']."\n") ?></td>
									<td class="job-fair"><?php echo nl2br($row1['em_designation']."\n")?></td>
									<td class="job-fair"><?php echo nl2br($row1['em_telephone']."\n") ?></td>
									<td class="job-fair"><?php echo nl2br($row1['em_cellphone']."\n") ?></td>
									<td class="job-fair"><?php echo nl2br($row1['em_email']."\n") ?></td>
								</tr>
								<?php } ?>
								<?php } ?>
							</tbody>
						</table>
                
                
