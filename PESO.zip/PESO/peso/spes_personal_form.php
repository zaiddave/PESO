<?php
session_start();
require_once("db_con/connect.php");
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}
//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values
	$id = clean($_POST['id']);
	$fname = strtoupper(clean($_POST['fname']));
	$mname = strtoupper(clean($_POST['mname']));
	$lname = strtoupper(clean($_POST['lname']));
	$bdate = clean($_POST['bdate']);
	$gender = clean($_POST['gender']);
	$brgy = strtoupper(clean($_POST['brgy']));
	$city = strtoupper(clean($_POST['city']));
	$lgu  = strtoupper(clean($_POST['lgu']));
	$remark = strtoupper(clean($_POST['remark']));


	  //explode the date to get month, day and year
	  $birthDate = explode("/", $bdate);
	  //get age from date or birthdate
	  $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
	    ? ((date("Y") - $birthDate[2]) - 1)
	    : (date("Y") - $birthDate[2]));

	 $qbrgy = "INSERT INTO ps_brgy (b_name)
	SELECT * FROM (SELECT '$brgy') AS tmp
	WHERE NOT EXISTS (
    SELECT b_name FROM ps_brgy WHERE b_name = '$brgy'
	) LIMIT 1";
	mysql_query($qbrgy) or die(mysql_error());

	$qcity = "INSERT INTO ps_city (c_name)
	SELECT * FROM (SELECT '$city') AS tmp
	WHERE NOT EXISTS (
    SELECT c_name FROM ps_city WHERE c_name = '$city'
	) LIMIT 1";
	mysql_query($qcity) or die(mysql_error());

	$qlgu = "INSERT INTO ps_lgu (l_name)
	SELECT * FROM (SELECT '$lgu') AS tmp
	WHERE NOT EXISTS (
    SELECT l_name FROM ps_lgu WHERE l_name = '$lgu'
	) LIMIT 1";
	mysql_query($qlgu) or die(mysql_error());

	$query = "UPDATE ps_spes SET sp_fname = '$fname', sp_mname = '$mname', sp_lname = '$lname', sp_gender = '$gender', sp_date_of_birth = '$bdate', sp_age = '$age', sp_brgy = '$brgy', sp_city = '$city', sp_lgu = '$lgu', sp_remark = '$remark' WHERE sp_id = '$id' ";

	mysql_query($query) or die(mysql_error()); 

	$success = '<div class="alert alert-info" role="alert">SPES <b>'.$fname.' '.$lname.'</b> successfully updated <span class="glyphicon glyphicon-exclamation-sign"></span></div>';
    $_SESSION['result'] = $success;
	header('location:spes_report.php');
	


?>