
<div class="col-md-8 col-md-offset-2">
 <div class="container shadow col-md-12">
 	<ul class="nav nav-tabs nav-justified" id="admin-admin-tab">
    <li class="active"><a data-toggle="tab" href="#official"><b>PESO Official</b></a></li>
    <li><a data-toggle="tab" href="#staff"><b>PESO Staff</b></a></li>
</ul><!--nav tabs-->
<br><br><br>
<?if(isset($_SESSION['result'])){
	echo $_SESSION['result'];
	unset($_SESSION['result']);
}
?>
<div class="tab-content">
    <? include('admin_container_tab_official.php') ?>
    <? include('admin_container_tab_staff.php') ?>
</div><!--tab content-->
 </div>
</div>

<?
include('admin_official_update.php');
include('admin_staff_add.php');
include('admin_staff_delete.php')

?>

