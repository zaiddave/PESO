<div class="modal fade" data-keyboard="false" data-backdrop="static" id="update_applicant" tabindex="-1" role="dialog" aria-labelledby="update_applicantLabel" aria-hidden="true">
  <div class="modal-dialog ">
    <div class="modal-content">
      <div class="modal-header update">
        <button type="button" data-dismiss="modal" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="update_applicantLabel" ><center><strong>Update</strong></center></h4>
      </div>

      <div class="modal-body">
      
      <form class="form-horizontal" method="post" action="applicant_update.php" enctype="multipart/form-data">

      <div style="margin-right:20px; margin-left:20px;">

      <input type="hidden" class="form-control" name="id">
       <div class="form-group">
    <label for="company" class="text-color-2">Applicant Name:</label><br>
    
    <div class="col-sm-4">
      <input type="text" class="form-control" id="fname" placeholder="First Name" name="fname" required>
    </div>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="mname" placeholder="Middle Name" name="mname">
    </div>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="lname" placeholder="Last Name" name="lname" required>
    </div>
    </div>

  <div class="form-group">
                  <label for="bdate" class="text-color-2">Date of Birth:</label><br>
                  <div class="col-sm-4">
                  <input type="text" class="form-control datepicker" id="bdate" placeholder="mm/dd/yyyy" name="bdate" autocomplete="off">
                  </div>
                  <div class="col-sm-4">
                  <small><b>Not specified? Copy the text on the right and paste it on the Date of Birth:</b></small>
                  </div>
                  <div class="col-sm-4">
                  <input type="text" class="form-control" value="Not Specified" readonly="true">
                  </div>
  </div>

  <div class="form-group">
                  <label for="gender" class="text-color-2">Gender:</label>
                  <div class="col-sm-12" >
                  <div class="btn-group" data-toggle="buttons">
                  <label class="btn btn-primary btn-enhance-primary">
                  <input type="radio" name="gender" value="Male" id="gender" required>Male
                  </label>
                  <label class="btn btn-primary btn-enhance-primary">
                  <input type="radio" name="gender" value="Female" id="gender" required>Female
                  </label>
                  </div>
                  </div>
  </div>

  <div class="form-group">
    <label for="address" class="text-color-2">Address:</label><br>
    <textarea rows="3" class="form-control" id="address" placeholder="Address" name="address" required></textarea>      
  </div>

<div class="form-group">
    <label class="text-color-2">Status:</label><br>
    <div class="btn-group" data-toggle="buttons">
    <a data-toggle="tooltip" data-placement="top" title="Select 1 or more of these options that are applicable.">
    <label class="btn btn-warning btn-enhance-warning">
      <input type="checkbox" name="osy" value="Yes">  OSY &nbsp;&nbsp;
    </label>    
    <label class="btn btn-warning btn-enhance-warning">
      <input type="checkbox" name="inschool" value="Yes">  In School &nbsp;&nbsp;
    </label>    
    <label class="btn btn-warning btn-enhance-warning">
      <input type="checkbox" name="ip" value="Yes">  Indigenuos People &nbsp;&nbsp;
    </label>    
    <label class="btn btn-warning btn-enhance-warning">
      <input type="checkbox" name="pwd" value="Yes">  PWD &nbsp;&nbsp;
    </label>    
    </a>
    </div>
  </div>

<div class= "form-group">
  <label for="contact" class="text-color-2 control-label">Contact Details:</label>
</div>
<div class= "form-group">
  <label for="telephone" class="col-md-offset-2 text-color-2 col-sm-2 control-label">Telephone No.:</label>
   <div class="col-sm-5">      
      <textarea rows="2" class="form-control" id="telephone" placeholder="Telephone No." name="telephone"></textarea>      
   </div>        
</div> 

<div class= "form-group">
<label for="cell" class="col-md-offset-2 text-color-2 col-sm-2 control-label">Cellphone No.:</label>
   <div class="col-sm-5 ">
   <textarea rows="2" class="form-control" id="cell" placeholder="Cellphone No." name="cell"></textarea>      
   </div>
</div>

<div class= "form-group">
<label for="email" class="col-md-offset-2 text-color-2 col-sm-2 control-label">Email Address:</label>
   <div class="col-sm-5 ">      
      <textarea rows="2" class="form-control" id="email" placeholder="Email Address" name="email"></textarea>
    </div>
</div>

<div class="form-group">
    <label for="course" class="text-color-2">Course:</label><br>
      <input type="text" class="form-control" id="course" placeholder="Course" name="course">
</div>

<div class="form-group">         
    <label for="start" class="text-color-2">Registration Date:</label> 
        <input type="text" class="form-control datepicker " id="start" placeholder="mm/dd/yyyy" name="startdate" required>    
</div>

<div class="form-group">
    <label for="job" class="text-color-2">Preferred Job:</label><br>
      <textarea rows="2" class="form-control" id="job" placeholder="Preferred Job" name="job"></textarea>
</div>

<div class="form-group">
    <label for="educational" class="text-color-2">Highest Educational Attainment:</label><br>
       <select class="form-control" id="educational" name="educational" required>
        <option value="default" selected="selected">--SELECT--</option>
        <option value="Not Specified">Not Specified</option>
        <option value="No Educational Background">No Educational Background</option>
        <option value="Grade 1">Grade 1</option>
        <option value="Grade 2">Grade 2</option>
        <option value="Grade 3">Grade 3</option>
        <option value="Grade 4">Grade 4</option>
        <option value="Grade 5">Grade 5</option>
        <option value="Grade 6">Grade 6</option>
        <option value="Elementary Level">Elementary Level</option>
        <option value="Elementary Graduate">Elementary Graduate</option>
        <option value="Grade 7">Grade 7</option>
        <option value="Grade 8">Grade 8</option>
        <option value="1st Year High School/Grade 7 (For Kto12)">1st Year High School/Grade 7 (For Kto12)</option>
        <option value="2nd Year High School/Grade 8 (For Kto12)">2nd Year High School/Grade 8 (For Kto12)</option>
        <option value="3rd Year High School/Grade 9 (For Kto12)">3rd Year High School/Grade 9 (For Kto12)</option>
        <option value="4th Year High School/Grade 10 (For Kto12)">4th Year High School/Grade 10 (For Kto12)</option>
        <option value="Grade 11 (For Kto12)">Grade 11 (For Kto12)</option>
        <option value="Grade 12 (For Kto12)">Grade 12 (For Kto12)</option>
        <option value="High School Level">High School Level</option>
        <option value="High School Graduate">High School Graduate</option>
        <option value="Technical-Vocational Undergraduate">Technical-Vocational Undergraduate</option>
        <option value="Technical-Vocational Graduate">Technical-Vocational Graduate</option>
        <option value="1st Year College Level">1st Year College Level</option>
        <option value="2nd Year College Level">2nd Year College Level</option>  
        <option value="3rd Year College Level">3rd Year College Level</option> 
        <option value="4th Year College Level">4th Year College Level</option> 
        <option value="5th Year College Level">5th Year College Level</option>
        <option value="College Level">College Level</option>
        <option value="College Graduate">College Graduate</option>        
        <option value="Masteral/Post Graduate Level">Masteral/Post Graduate Level</option>   
        <option value="Masteral/Post Graduate">Masteral/Post Graduate</option>
      </select>
 </div>

    <div class="form-group modal-footer">
                 <input class="btn btn-info btn-update col-xs-3 col-xs-offset-4 col-sm-2 col-sm-offset-5 col-md-2 col-md-offset-5" type="submit" value="Update">
</div>

        </div>
      </form>
      </div>
      </div>
    </div>
  </div>