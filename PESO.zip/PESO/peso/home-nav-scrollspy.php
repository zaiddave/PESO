<nav  class="hidden-xs hidden-sm" id="scrollableHomeMenu">
	<ul class="nav nav-pills nav-stacked">
			<li><a href="#peso3"><i class="fa fa-info-circle fa-3x" aria-hidden="true"></i></a></li>
			<li><a href="#peso1"><i class="fa fa-pencil-square-o fa-3x" aria-hidden="true"></i></a></li>			
			<li><a href="#peso2"><i class="fa fa-folder-open-o fa-3x" aria-hidden="true"></i></a></li>
			<li><a href="#peso4"><i class="fa fa-users fa-3x" aria-hidden="true"></i></a></li>
		</ul>
</nav>