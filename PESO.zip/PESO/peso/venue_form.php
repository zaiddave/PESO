  <?php
session_start();

require_once('db_con/connect.php');

//function to sanitize values received from the form. Prevents SQL injection

  function clean($str){
    $str = @trim($str);
    if(get_magic_quotes_gpc()){
      $str = stripslashes($str);
    }
    return mysql_real_escape_string($str);
  }

$venue = clean($_POST['venue_']);
if($venue != ""){
  $result = mysql_query("SELECT * FROM ps_venue WHERE v_name = '$venue' ");
  if ($result){
    if(mysql_num_rows($result) > 0){
      $error = '<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign"></span> <b>Oops!</b> This '.$venue.' must have already been added. </div>';

      $_SESSION['result2'] = $error;
      header("location: job_interview.php");
    }
    else{
    mysql_query("INSERT INTO ps_venue (v_name) VALUES ('$venue') ") or die(mysql_error());
    $success =  '<div class="alert alert-success" role="alert">'. $venue .' successfully Added</div>';
    $_SESSION['result2'] = $success;
    header("location: job_interview.php");

    }
  }
}
else{
   $error = '<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign"></span> Please fill in the <b>Venue Form</b>. </div>';
   $_SESSION['result2'] = $error;
   header("location: job_interview.php");
}
  

?>