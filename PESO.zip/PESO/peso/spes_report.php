<?php
session_start();

include('meta.php') ?>

<title>PESO</title>
<?php
include('head.php');

include('navbar.php');

include('spes_report_container.php');

 ?> 


</body>
</html>

<?
include('spes_manage.php');

include('spes_delete.php');

include('certificate_year.php')
?>