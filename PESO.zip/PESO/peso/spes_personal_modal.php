<?
//function to sanitize values received from the form. Prevents SQL injection

  function clean($str){
    $str = @trim($str);
    if(get_magic_quotes_gpc()){
      $str = stripslashes($str);
    }
    return mysql_real_escape_string($str);
  }

  $id = clean($_POST['id']);
  $query = mysql_query("SELECT * FROM ps_spes WHERE sp_id = '$id'");
  $row = mysql_fetch_array($query);

?>
<div class="modal fade bs-example-modal-lg" data-keyboard="false" data-backdrop="static" id="spes_personal" tabindex="-1" role="dialog" aria-labelledby="spes_personallabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header update">
      <a href="spes_report.php">
        <button type="button" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button></a>
        <h4 class="modal-title" id="spes_personallabel" ><strong><center>Personal Information</center></strong></h4>
      </div>

      <div class="modal-body">
      <form class="form-horizontal" method="post" action="spes_personal_form.php" enctype="multipart/form-data">
      <input type="hidden" name="id" value="<? echo $id?>" >
        <div class="form-group">
        <label for="company" class="text-color-2 col-sm-2 control-label">Applicant Name:</label>
        <div class="col-sm-3">
          <input type="text" class="form-control" id="pfname" placeholder="First Name" name="fname" autocomplete="off" value="<? echo $row['sp_fname'] ?>" required>
        </div>
        <div class="col-sm-3">
          <input type="text" class="form-control" id="pmname" placeholder="Middle Name" autocomplete="off" name="mname" value="<? echo $row['sp_mname']?>">
        </div>
        <div class="col-sm-3">
          <input type="text" class="form-control" id="plname" placeholder="Last Name" name="lname" autocomplete="off" value="<? echo $row['sp_lname']?>" required>
        </div>
        </div>

        <div class="form-group">
        <label for="bdate" class="text-color-2 col-sm-2 control-label">Date of Birth:</label>
        <div class="col-sm-2">
          <input type="text" class="form-control datepicker" id="pbdate" placeholder="mm/dd/yyyy" name="bdate" autocomplete="off" value="<? echo $row['sp_date_of_birth']?>">
        </div>
        </div>

        <div class="form-group">
            <label for="gender" class="text-color-2 col-sm-2 control-label">Gender:</label>
            <div class="col-sm-3">
            <div class="btn-group" data-toggle="buttons">
            <label class="btn btn-primary btn-enhance-primary">
            <input type="radio" name="gender" value="Male" id="gender" required>Male
            </label>
            <label class="btn btn-primary btn-enhance-primary">
            <input type="radio" name="gender" value="Female" id="gender" required>Female
            </label>
            </div>
            </div>
        </div>

        <div class="form-group">
            <label for="barangay" class="text-color-2 col-sm-2 control-label">Barangay:</label>
            <div class="col-md-2">
            <input type="text" class="form-control" id="pbrgy" placeholder="Barangay" name="brgy" autocomplete="off" value="<? echo $row['sp_brgy']?>">
            </div>
            <label for="city" class="text-color-2 col-sm-1 control-label">City:</label>
            <div class="col-md-2">
            <input type="text" class="form-control" id="pcity" placeholder="City" name="city" autocomplete="off" value="<? echo $row['sp_city']?>">
            </div>
            <label for="lgu" class="text-color-2 col-sm-1 control-label">LGU:</label>
            <div class="col-md-2">      
            <input type="text" class="form-control" id="plgu" placeholder="Name of LGU" name="lgu" autocomplete="off" value="<? echo $row['sp_lgu']?>"> 
            </div>
        </div>      
        <div class="form-group">
          <label for="remark" class="text-color-2 col-sm-2 control-label">Remarks:</label>
          <div class="col-sm-4">
          <textarea rows="2" class="form-control" name="remark" id="remark"><?php echo $row['sp_remark']?></textarea>
          </div>
        </div>
      <div class="form-group modal-footer">
        <input class="btn btn-info btn-update col-sm-3 col-sm-offset-5" type="submit" value="Update">
      </div>
      </form>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->