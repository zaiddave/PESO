<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>Applicant Report Table</b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>
	                    <table id="table" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Applicant Name</th>
									<th>Gender</th>
									<th>Birthdate</th>
									<th>Age</th>
									<th>Address</th>
									<th>OSY</th>
									<th>In School</th>
									<th>Indigenous People</th>
									<th>PWD</th>
									<th>Contact Number/s</th>
									<th>Email</th>
									<th>Course</th>
									<th>Preferred Job</th>
									<th>Highest Educational Attainment</th>
									<th>Date Registered</th>
								</tr>
							</thead>
							<tbody>
							<?php 									
									
									$fetch = mysql_query("SELECT * FROM ps_applicant_registry ORDER BY ap_lname ASC") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                  			?>
								<tr>
									<td class="job-fair"><?php echo $row['ap_lname'] .", ".$row['ap_fname']." ".$row['ap_mname']?></td>
									<td class="job-fair"><?php echo $row['ap_gender'] ?></td>
									<td class="job-fair"><?php echo $row['ap_bdate'] ?></td>
									<td class="job-fair"><?php echo $row['ap_age'] ?></td>
									<td class="job-fair"><?php echo $row['ap_address'] ?></td>
									<td class="job-fair"><?php echo $row['ap_osy']?></td>
									<td class="job-fair"><?php echo $row['ap_inschool']?></td>
									<td class="job-fair"><?php echo $row['ap_ip']?></td>
									<td class="job-fair"><?php echo $row['ap_pwd']?></td>
									<td class="job-fair"><?php echo nl2br($row['ap_telephone'] ."\n"). nl2br($row['ap_cellphone']."\n") ?></td>
									<td class="job-fair"><?php echo nl2br($row['ap_email']."\n") ?></td>
									<td class="job-fair"><?php echo $row['ap_course'] ?></td>
									<td class="job-fair"><?php echo nl2br($row['ap_pref_job'] ."\n") ?></td>
									<td class="job-fair"><?php echo $row['ap_educ_bg'] ?></td>
									<td class="job-fair"><?php echo $row['ap_from_date']?></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                  </div>
                </div>
                
                