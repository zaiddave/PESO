<?php
session_start();
require_once('db_con/connect.php');

//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values

$user = clean($_POST['username']);
$pass = clean($_POST['password']);



	$query = "SELECT * FROM  ps_login WHERE l_username = '$user' && l_password = md5('$pass') ";
	$result = mysql_query($query) or die(mysql_error());
	

	if($result) {
		//check if username and password exist
		if(mysql_num_rows($result) > 0) {

		
		$info = mysql_fetch_array($result) or die(mysql_error());
		$_SESSION['fname'] = $info['l_fname'];
		$_SESSION['mname'] = $info['l_mname'];
		$_SESSION['lname'] = $info['l_lname'];
		$_SESSION['user'] = $info['l_username'];
		$_SESSION['type'] = $info['l_type'];
		session_write_close();

		$tquery = "UPDATE ps_login SET l_time = NOW() WHERE l_username = '$user' AND l_password = md5('$pass')";
		mysql_query($tquery);
		header('location:home.php');	
	}
		else	{	
		$err = '<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign"></span> <b>Invalid</b> username or password! </div>';

		$_SESSION['errlog'] = $err;
		header('location:login.php');

	}
	}
	else {
		$err = '<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign"></span> '. die(mysql_error()).'</b></div>';

		$_SESSION['errlog'] = $err;
		header('location:login.php');
	}
?>