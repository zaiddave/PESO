<div class="modal fade" data-keyboard="false" data-backdrop="static" id="update_vacancy" tabindex="-1" role="dialog" aria-labelledby="update_vacancyLabel" aria-hidden="true">
  <div class="modal-dialog ">
    <div class="modal-content">
      <div class="modal-header update">
        <button type="button" data-dismiss="modal" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="update_vacancyLabel" ><center><strong>Update</strong></center></h4>
      </div>

      <div class="modal-body">
      
      <form method="post" action="vacancy_update.php#job" enctype="multipart/form-data">

      <input type="hidden" class="form-control" name="id">
       
          <div class="form-group">
                  <label for="inputForEmployer">Company Name:</label>
                  <input type="text" class="form-control" id="inputForEmployer" placeholder="Company Name" name="employer" autocomplete="off" required>
            </div>
            <div class="form-group">
                  <label for="inputForVacancy">Job Vacancy/ies:</label>
                  <input type="text" class="form-control" id="inputForVacancy" placeholder="Enter Job Name Here" name="vacancy" autocomplete="off" required>
            </div>
            <div class="form-group">
                  <label for="inputForNoVacancy">Number of Available Vacant:</label>
                  <input type="text" class="form-control" id="inputForNoVacancy" placeholder="Number of Available Vacant" name="novacancy" autocomplete="off" required>
                  
            </div>
            <div class="form-group">
                  <label for="gender">Gender:</label>
                  <div class="btn-group" data-toggle="buttons">
                  <label class="btn btn-success btn-enhance-success">
                  <input type="radio" name="gender" value="Male" id="gender">&nbsp;Male
                  </label>
                  <label class="btn btn-success btn-enhance-success">
                  <input type="radio" name="gender" value="Female" id="gender">&nbsp;Female
                  </label>
                  <label class="btn btn-success btn-enhance-success">
                  <input type="radio" name="gender" value="Male & Female" id="gender">&nbsp;Male & Female
                  </label>
                  </div>
            </div>
            <div class="form-group">
                  <label for="inputDatePosting">Date of Posting:</label>
                  <input type="text" class="form-control datepicker" id="inputDatePosting" placeholder="mm/dd/yyyy" name="dateposting" autocomplete="off" required>
            </div>
            <div class="form-group">
                  <label for="inputForStatus">Status:</label>
                  <input type="text" class="form-control" id="inputForStatus" placeholder="Status" name="status" autocomplete="off" required>
            </div>
            <div class="form-group">
                  <label for="inputForDate">Date:</label>
                  <input type="text" class="form-control datepicker" id="inputForDate" placeholder="mm/dd/yyyy" name="date" autocomplete="off" required>
            </div>

            <div class="form-group modal-footer">
                 <input class="btn btn-info btn-update col-xs-3 col-xs-offset-4 col-sm-2 col-sm-offset-5 col-md-2 col-md-offset-5" type="submit" value="Update">
            </div>
        
    </form>

	  </div>

    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->