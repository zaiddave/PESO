     <div class="col-sm-12">
  <?php
  if(isset($_SESSION['result1'])){
    echo $_SESSION['result1'];
    unset($_SESSION['result1']);
  }
  ?>
</div>
	                    <table id="job_table2" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Company Name</th>
									<th>Job Vacancy</th>
									<th>Number of Vacant</th>
									<th>Gender</th>
									<th>Date Posted</th>
									<th>Status</th>
									<th>Date</th>
									<th>Manage</th>
								</tr>
							</thead>
							<tbody>
							<?php 									
									
									$fetch = mysql_query("SELECT * FROM ps_vacancy ") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                  			?>
								<tr>
									<td class="job-fair-year"><?php echo $row['em_company_name'] ?></td>
									<td class="job-fair"><?php echo $row['vac_vacancy'] ?></td>
									<td class="job-fair"><?php echo $row['vac_no_of_vacancy'] ?></td>
									<td class="job-fair"><?php echo $row['vac_gender'] ?></td>
									<td class="job-fair"><?php echo $row['vac_date_posting'] ?></td>
									<td class="job-fair"><?php echo $row['vac_status'] ?></td>
									<td class="job-fair"><?php echo $row['vac_date'] ?></td>
									<td class="job-fair">
									<a data-toggle="tooltip" data-placement="bottom" title="Update.">
									<button class="btn btn-primary" aria-label="Edit" data-toggle="modal" data-target="#update_vacancy" data-vacancy-id="<?php echo $row['vac_id']?>" data-company="<?php echo $row['em_company_name']?>" data-vacancy="<?php echo $row['vac_vacancy']?>" data-novacancy="<?php echo $row['vac_no_of_vacancy']?>" data-dateposting="<?php echo $row['vac_date_posting']?>" data-status="<?php echo $row['vac_status']?>" data-date="<?php echo $row['vac_date']?>"> <span class="glyphicon glyphicon-edit" aria-hidden="true"></span></button></a><br><br>
									<a data-toggle="tooltip" data-placement="top" title="Delete.">
									<button class="btn btn-danger" aria-label="Delete" data-toggle="modal" data-target="#delete_job" data-delete-id="<?php echo $row['vac_id']?>"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></button></a></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                  