<div class="container shadow col-md-10 col-md-offset-1">

<div class="col-sm-12">
  <?php
  if(isset($_SESSION['result'])){
    echo $_SESSION['result'];
    unset($_SESSION['result']);
  }
  ?>
</div>

 <form class="form-horizontal" action="applicant_form.php" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label for="company" class="text-color-2 col-sm-2 control-label">Applicant Name:</label>
    <div class="col-sm-3">
      <input type="text" class="form-control" id="fname" placeholder="First Name" name="fname" autocomplete="off" required>
    </div>
    <div class="col-sm-3">
      <input type="text" class="form-control" id="mname" placeholder="Middle Name" autocomplete="off" name="mname" >
    </div>
    <div class="col-sm-3">
      <input type="text" class="form-control" id="lname" placeholder="Last Name" name="lname" autocomplete="off" required>
    </div>
  </div>

    <div class="form-group">
                  <label for="bdate" class="text-color-2 col-sm-2 control-label">Date of Birth:</label>
                  <div class="col-sm-2">
                  <input type="text" class="form-control datepicker" id="bdate" placeholder="mm/dd/yyyy" name="bdate" autocomplete="off">
                  </div>
                  <div class="col-sm-4">
                  <small><b>Not specified?</b> Copy the text on the right and paste it on the Date of Birth:</small>
                  </div>
                  <div class="col-sm-2">
                  <input type="text" class="form-control" value="Not Specified" readonly="true">
                  </div>
  </div>

  <div class="form-group">
			      		  <label for="gender" class="text-color-2 col-sm-2 control-label">Gender:</label>
			      		  <div class="col-sm-10" style="padding-top:6px;">
                  <div class="btn-group" data-toggle="buttons">
                  <label class="btn btn-primary btn-enhance-primary">
				          <input type="radio" name="gender" value="Male" id="gender" required>Male
                  </label>
                  <label class="btn btn-primary btn-enhance-primary">
                  <input type="radio" name="gender" value="Female" id="gender" required>Female
                  </label>
						      </div>
                  </div>
	</div>

	<div class="form-group">
    <label for="address" class="text-color-2 col-sm-2 control-label">Address:</label>
    <div class="col-sm-10">      
      <textarea rows="2" class="form-control" id="address" placeholder="Address" name="address" required></textarea>      
    </div>
  </div>

  <div class="form-group">
    <label class="text-color-2 col-sm-2 control-label">Status:</label>
    <div class="btn-group" data-toggle="buttons">
    <a data-toggle="tooltip" data-placement="top" title="Select 1 or more of these options that are applicable.">
    <label class="btn btn-warning btn-enhance-warning">
      <input type="checkbox" name="osy" value="Yes">  Out of School Youth &nbsp;&nbsp;
    </label>    
    <label class="btn btn-warning btn-enhance-warning">
      <input type="checkbox" name="inschool" value="Yes">  In School &nbsp;&nbsp;
    </label>    
    <label class="btn btn-warning btn-enhance-warning">
      <input type="checkbox" name="ip" value="Yes">  Indigenuos People &nbsp;&nbsp;
    </label>    
    <label class="btn btn-warning btn-enhance-warning">
      <input type="checkbox" name="pwd" value="Yes">  Person's with Disability &nbsp;&nbsp;
    </label>    
    </a>
    </div>
  </div>

<div class= "form-group">
  <label for="contact" class="text-color-2 col-sm-2 control-label">Contact Details:</label>
  <label for="telephone" class="text-color-2 col-sm-2 control-label">Telephone No.:</label>
   <div class="col-sm-4">      
      <textarea rows="2" class="form-control" id="telephone" placeholder="Telephone No." name="telephone"></textarea>      
   </div>        
</div> 

<div class= "form-group">
<label for="cell" class="col-md-offset-2 text-color-2 col-sm-2 control-label">Cellphone No.:</label>
   <div class="col-sm-4 ">
   <textarea rows="2" class="form-control" id="cell" placeholder="Cellphone No." name="cell"></textarea>      
   </div>
</div>

<div class= "form-group">
<label for="email" class="col-md-offset-2 text-color-2 col-sm-2 control-label">Email Address:</label>
   <div class="col-sm-4 ">      
      <textarea rows="2" class="form-control" id="email" placeholder="Email Address" name="email"></textarea>
    </div>
</div>

<div class="form-group">
    <label for="course" class="text-color-2 col-sm-2 control-label">Course:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="auto_course" placeholder="Course" name="course" autocomplete="off" spellcheck="off">      
    </div>
</div>

<div class="form-group">
    <label for="register" class="text-color-2 col-sm-2 control-label">Registration Date:</label>
    <div class="col-sm-3">      
      <div class="input-group" id="register">      
      <input type="text" class="form-control datepicker" placeholder="mm/dd/yyyy" name="startdate" autocomplete="off" required="true">
      <div class="add-on-primary input-group-addon"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span><span class="sr-only"></span></div>
    </div>
    </div>
</div>

<div class="form-group">
    <label for="job" class="text-color-2 col-sm-2 control-label">Preferred Job:</label>
    <div class="col-sm-10">
      <textarea rows="2" class="form-control" placeholder="Preferred Job" name="job"></textarea>
    </div>
</div>

<div class="form-group">
    <label for="educational" class="text-color-2 col-sm-2 control-label">Highest Educational Attainment:</label><br>
    <div class="col-sm-10">
      <select class="form-control" id="educational" name="educational" required>
        <option value="" selected="selected">SELECT EDUCATIONAL LEVEL</option>
        <option value="Not Specified">Not Specified</option>
        <option value="No Educational Background">No Educational Background</option>
        <option value="Grade 1">Grade 1</option>
        <option value="Grade 2">Grade 2</option>
        <option value="Grade 3">Grade 3</option>
        <option value="Grade 4">Grade 4</option>
        <option value="Grade 5">Grade 5</option>
        <option value="Grade 6">Grade 6</option>
        <option value="Elementary Level">Elementary Level</option>
        <option value="Elementary Graduate">Elementary Graduate</option>
        <option value="Grade 7">Grade 7</option>
        <option value="Grade 8">Grade 8</option>
        <option value="1st Year High School/Grade 7 (For Kto12)">1st Year High School/Grade 7 (For Kto12)</option>
        <option value="2nd Year High School/Grade 8 (For Kto12)">2nd Year High School/Grade 8 (For Kto12)</option>
        <option value="3rd Year High School/Grade 9 (For Kto12)">3rd Year High School/Grade 9 (For Kto12)</option>
        <option value="4th Year High School/Grade 10 (For Kto12)">4th Year High School/Grade 10 (For Kto12)</option>
        <option value="Grade 11 (For Kto12)">Grade 11 (For Kto12)</option>
        <option value="Grade 12 (For Kto12)">Grade 12 (For Kto12)</option>
        <option value="High School Level">High School Level</option>
        <option value="High School Graduate">High School Graduate</option>
        <option value="Technical-Vocational Undergraduate">Technical-Vocational Undergraduate</option>
        <option value="Technical-Vocational Graduate">Technical-Vocational Graduate</option>
        <option value="1st Year College Level">1st Year College Level</option>
        <option value="2nd Year College Level">2nd Year College Level</option>  
        <option value="3rd Year College Level">3rd Year College Level</option> 
        <option value="4th Year College Level">4th Year College Level</option> 
        <option value="5th Year College Level">5th Year College Level</option>
        <option value="College Level">College Level</option>
        <option value="College Graduate">College Graduate</option>        
        <option value="Masteral/Post Graduate Level">Masteral/Post Graduate Level</option>   
        <option value="Masteral/Post Graduate">Masteral/Post Graduate</option>
      </select>
    </div>
</div>

<br>

 <div class= "form-group">
<input class="btn btn-success save col-xs-3 col-xs-offset-4 col-sm-2 col-sm-offset-5 col-md-2 col-md-offset-5" type="submit" value="Save">
</div>

</form>
 </div>