  <?php
session_start();

require_once('db_con/connect.php');

//function to sanitize values received from the form. Prevents SQL injection

  function clean($str){
    $str = @trim($str);
    if(get_magic_quotes_gpc()){
      $str = stripslashes($str);
    }
    return mysql_real_escape_string($str);
  }

$recruit = clean($_POST['recruit']);
if($recruit != ""){
  $result = mysql_query("SELECT * FROM ps_recruitment_type WHERE r_type = '$recruit' ");
  if ($result){
    if(mysql_num_rows($result) > 0){
      $error = '<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign"></span> <b>Oops!</b> This '.$recruit.' must have already been added. </div>';

      $_SESSION['result'] = $error;
      header("location: job_interview.php");
    }
    else{
    mysql_query("INSERT INTO ps_recruitment_type (r_type) VALUES ('$recruit') ") or die(mysql_error());
    $success =  '<div class="alert alert-success" role="alert">'. $recruit .' successfully Added</div>';
    $_SESSION['result'] = $success;
    header("location: job_interview.php");

    }
  }
}
else{
   $error = '<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign"></span> Please fill in the <b>Recruitment Form</b>. </div>';
   $_SESSION['result'] = $error;
   header("location: job_interview.php");
}
  

?>