<?php
session_start();
include('meta.php') ?>
<title>PESO</title>
<?php include('head.php') ?>

<?php include('navbar.php') ?>

<?php include('job_sra_container.php') ?> 


</body>
</html>