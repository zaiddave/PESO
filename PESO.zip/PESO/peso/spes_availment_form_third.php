<?php
session_start();
require_once("db_con/connect.php");
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}
//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values
	$id = clean($_POST['tid']);
	$edu = clean($_POST['educational2']);
	$avail = clean($_POST['tavail']);
	$batch = clean($_POST['tbatch']);
	$year = clean($_POST['tyear']);
	$grade = clean($_POST['tgrade']);

	$query = "UPDATE ps_spes SET sp_edu3 = '$edu', sp_third_availment = '$avail', sp_batch_third_year = '$batch', sp_third_year = '$year', sp_grade_third = '$grade' WHERE sp_id = '$id' ";

	mysql_query($query) or die(mysql_error()); 

	$success = '<div class="alert alert-success" role="alert">Successfully <b>updated</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';
    $_SESSION['result'] = $success;
	header('location:spes_report.php');

?>