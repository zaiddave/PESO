<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>Manage Lists of Hired Applicants On The Spot </b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>
 <div class="col-sm-12">
  <?php
  if(isset($_SESSION['result'])){
    echo $_SESSION['result'];
    unset($_SESSION['result']);
  }
  ?>
</div>
	                    <table id="table1" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Applicant Name</th>
									<th>Gender</th>
									<th>Age</th>
									<th>Contact Number</th>
									<th>Address</th>
									<th>Position Applied</th>
									<th>Company</th>
									<th>Status</th>
									<th>Manage</th>
								</tr>
							</thead>
							<tbody>
							<?php 									
									
									$fetch = mysql_query("SELECT * FROM ps_hots ORDER BY hots_lname ") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                					$id = mysql_real_escape_string($row['j_id']);          						
                  			?>
								<tr>
									<td class="job-fair"><?php echo $row['hots_lname'] .", ".$row['hots_fname']." ".$row['hots_mname']?></td>
									<td class="job-fair"><?php echo $row['hots_gender'] ?></td>
									<td class="job-fair"><?php echo $row['hots_age'] ?></td>
									<td class="job-fair"><?php echo $row['hots_cellphone']?></td>									
									<td class="job-fair"><?php echo $row['hots_address'] ?></td>
									<td class="job-fair"><?php echo $row['hots_applied'] ?></td>
									<td class="job-fair">
									<a href="#!" data-toggle="tooltip" data-placement="top" title="<?php
									$fetch2 = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_id = $id ");
									$tip = mysql_fetch_array($fetch2);
									echo $tip['j_employment_type'];
									 ?>">
									<?php echo $row['hots_company'] ?>
									</a>
									</td>	
									<td class="job-fair"><?php echo $row['hots_employed'] ?></td>
									<td class="job-fair">
									<a data-toggle="tooltip" data-placement="bottom" title="Update.">
									<button class="btn btn-primary" aria-label="Edit" data-toggle="modal" data-target="#update_hots" data-hots-id="<?php echo $row['j_id'] ?>"
									data-fname="<?php echo $row['hots_fname']?>"
									data-mname="<?php echo $row['hots_mname']?>"
									data-lname="<?php echo $row['hots_lname']?>"
									data-age="<?php echo $row['hots_age']?>"
									data-cellphone="<?php echo $row['hots_cellphone']?>"
									data-address="<?php echo $row['hots_address']?>"
									data-applied="<?php echo $row['hots_applied']?>"
									data-sponsor="<?php echo $row['hots_sponsor']?>"
									data-company="<?php echo $row['hots_company']?>"
									data-venue="<?php echo $row['hots_venue']?>"
									><span class="glyphicon glyphicon-edit"></span></button></a><br><br><a data-toggle="tooltip" data-placement="top" title="Delete."><button class="btn btn-danger" aria-label="Delete" data-toggle="modal" data-target="#delete_hots" data-delete-id="<?php echo $row['j_id']?>" ><span class="glyphicon glyphicon-trash"></span></button></td>
								</tr> 
								<?php } ?>
							</tbody>
						</table>
                  </div>
                </div>