<?
session_start();
require_once("db_con/connect.php");
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}
//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

$id = clean($_POST['id']);
$img = clean($_FILES['pic']['name']);
$fname = clean($_POST['fname']);
$mname = clean($_POST['mname']);
$lname = clean($_POST['lname']);
$desig = clean($_POST['desig']);
$email = clean($_POST['email']);
$con = clean($_POST['con']);


$sourcePath = $_FILES['pic']['tmp_name'];
//where the image is to be placed
$path= 'C:/xampp/htdocs/peso/admin/'.$_FILES['pic']['name'];

$info = getimagesize($_FILES["pic"]["tmp_name"]);




//no file uploaded
	if ($_FILES['pic']['error'] == 4)
	{
	$query = ("UPDATE ps_login SET l_fname = '$fname', l_mname = '$mname', l_lname = '$lname', l_desig = '$desig', l_email = '$email', l_con = '$con' WHERE l_id = '$id' ");	

	mysql_query($query);

	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}

	elseif (file_exists($path)) {
    $success = '<div class="alert alert-warning" role="alert"><b>File name</b> already exist <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}

elseif(is_array($_FILES)) {

	if($info === FALSE) {
        $success = '<div class="alert alert-danger" role="alert"><b>Uploaded file</b> is not an image <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
    }

    if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
   		$success = '<div class="alert alert-danger" role="alert"><b>Uploaded file</b> is not a <b>.jpg</b>, <b>.jpeg</b> or <b>.png</b> extension <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}

else{						

	if(is_uploaded_file($_FILES['pic']['tmp_name'])) {

	if(move_uploaded_file($sourcePath,$path)) {
		$query="UPDATE ps_login SET l_fname = '$fname', l_mname = '$mname', l_lname = '$lname', l_desig = '$desig', l_email = '$email', l_con = '$con', l_image = 'admin/$img' WHERE l_id = '$id' ";		
		mysql_query($query);

		$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
		}
	}
	}
}

?>