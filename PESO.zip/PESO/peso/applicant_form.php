<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}

//function to sanitizes values received from the form. Prevents SQL injection

function clean($str){
	$str = @trim($str);
	if(get_magic_quotes_gpc()){
		$str = stripslashes($str);
	}
	return mysql_real_escape_string($str);
}

//sanitize the POST values

$fname = strtoupper(clean($_POST['fname']));
$mname = strtoupper(clean($_POST['mname']));
$lname = strtoupper(clean($_POST['lname']));
$gender = clean($_POST['gender']);
$bdate = clean($_POST['bdate']);
$address = strtoupper(clean($_POST['address']));
$osy = clean($_POST['osy']);
$inschool = clean($_POST['inschool']);
$ip = clean($_POST['ip']);
$pwd = clean($_POST['pwd']);
$telephone = clean($_POST['telephone']);
$cell = clean($_POST['cell']);
$email = clean($_POST['email']);
$course = strtoupper(clean($_POST['course']));
$var = clean($_POST['startdate']);
$date = str_replace('/', '-', $var);
$startdate = date('Y-m-d', strtotime($date));
$job = strtoupper(clean($_POST['job']));
$educational = clean($_POST['educational']);

 


	if($bdate == "Not Specified"){
		$age = "Not Specified";
		$query= "INSERT into ps_applicant_registry (ap_fname, ap_mname, ap_lname, ap_gender, ap_bdate, ap_age, ap_address, ap_osy, ap_inschool, ap_ip, ap_pwd, ap_telephone, ap_cellphone, ap_email, ap_course, ap_from_date, ap_pref_job, ap_educ_bg) VALUES ('$fname', '$mname', '$lname', '$gender', '$bdate', '$age', '$address', '$osy', '$inschool', '$ip', '$pwd', '$telephone', '$cell', '$email', '$course', '$var', '$job', '$educational')" ;

			mysql_query($query) or die(mysql_error());

	$qcourse = "INSERT INTO ps_course (c_course)
	SELECT * FROM (SELECT '$course') AS tmp
	WHERE NOT EXISTS (
    SELECT c_course FROM ps_course WHERE c_course = '$course'
	) LIMIT 1";
	mysql_query($qcourse) or die(mysql_error());

			$success = '<div class="alert alert-success" role="alert">Applicant <b> '.$fname.' '.$mname.' '.$lname.'</b> successfully registered <span class="glyphicon glyphicon-exclamation-sign"></span> </div>';

      	$_SESSION['result'] = $success;
		header('location:applicant.php');		
	}
	else{

	//explode the date to get month, day and year
  $birthDate = explode("/", $bdate);
  //get age from date or birthdate
  $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
    ? ((date("Y") - $birthDate[2]) - 1)
    : (date("Y") - $birthDate[2]));

	$query= "INSERT into ps_applicant_registry (ap_fname, ap_mname, ap_lname, ap_gender, ap_bdate, ap_age, ap_address, ap_osy, ap_inschool, ap_ip, ap_pwd, ap_telephone, ap_cellphone, ap_email, ap_course, ap_from_date, ap_pref_job, ap_educ_bg) VALUES ('$fname', '$mname', '$lname', '$gender', '$bdate', '$age', '$address', '$osy', '$inschool', '$ip', '$pwd', '$telephone', '$cell', '$email', '$course', '$var', '$job', '$educational')" ;

			mysql_query($query) or die(mysql_error());

			$qcourse = "INSERT INTO ps_course (c_course)
	SELECT * FROM (SELECT '$course') AS tmp
	WHERE NOT EXISTS (
    SELECT c_course FROM ps_course WHERE c_course = '$course'
	) LIMIT 1";
	mysql_query($qcourse) or die(mysql_error());

			$success = '<div class="alert alert-success" role="alert">Applicant <b> '.$fname.' '.$mname.' '.$lname.' </b>successfully registered <span class="glyphicon glyphicon-exclamation-sign"></span> </div>';

      	$_SESSION['result'] = $success;
		header('location:applicant.php');	
	}
?>