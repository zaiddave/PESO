
<?php
session_start();
include('meta.php') ?>

<title> PESO </title>

<?php

include('head.php');

include('spes_navbar.php');

include('spes_container.php') ?> 


</body>
</html>
<script type="text/javascript">
$(document).ready(function($){
    $("#brgy").autocomplete({
        source: "json_data/json_brgy.php",
        minLength: 1
    });             
    $("#city").autocomplete({
        source: "json_data/json_city.php",
        minLength: 1
    }); 
    $("#lgu").autocomplete({
        source: "json_data/json_lgu.php",
        minLength: 1
    });  
});
</script>