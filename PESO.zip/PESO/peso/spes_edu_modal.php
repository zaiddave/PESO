<?
//function to sanitize values received from the form. Prevents SQL injection

  function clean($str){
    $str = @trim($str);
    if(get_magic_quotes_gpc()){
      $str = stripslashes($str);
    }
    return mysql_real_escape_string($str);
  }

  $id = clean($_POST['eid']);
  $query = mysql_query("SELECT * FROM ps_spes WHERE sp_id = '$id'");
  $row = mysql_fetch_array($query);

?>

<div class="modal fade bs-example-modal-lg" data-keyboard="false" data-backdrop="static" id="spes_edu" tabindex="-1" role="dialog" aria-labelledby="spes_edulabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header update">
        <a href="spes_report.php">
        <button type="button" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button></a>
        <h4 class="modal-title" id="spes_edulabel" ><strong><center>Manage Educational Level and Grades</center></strong></h4>
      </div>

    <div class="modal-body">
    <center>          
      <blockquote class="blockquote-primary"><p><b>Name:</b> <?php echo $row['sp_fname'].' '.$row['sp_lname']?></p></blockquote>    
    </center>
      <form class="form-horizontal" method="post" action="spes_edu_form.php" enctype="multipart/form-data">
      <input type="hidden" name="id" value="<? echo $id?>">   
      <div class="form-group">
      <label for="educational1">1st Availment Educational Level and Grade:</label>
      <div class="col-sm-12">
            

      
<div class="col-sm-6">
      <select class="form-control" id="educational1" name="educational1" required>
        <option value="" selected="selected">SELECT</option>
        <option value="Not Specified">Not Specified</option>
        <option value="1st Year High School/Grade 7 (For Kto12)">1st Year High School/Grade 7 (For Kto12)</option>
        <option value="2nd Year High School/Grade 8 (For Kto12)">2nd Year High School/Grade 8 (For Kto12)</option>
        <option value="3rd Year High School/Grade 9 (For Kto12)">3rd Year High School/Grade 9 (For Kto12)</option>
        <option value="4th Year High School/Grade 10 (For Kto12)">4th Year High School/Grade 10 (For Kto12)</option>
        <option value="Grade 11 (For Kto12)">Grade 11 (For Kto12)</option>
        <option value="Grade 12 (For Kto12)">Grade 12 (For Kto12)</option>
        <option value="1st Year College">1st Year College</option>
        <option value="2nd Year College">2nd Year College</option>  
        <option value="3rd Year College">3rd Year College</option> 
        <option value="4th Year College">4th Year College</option> 
        <option value="5th Year College">5th Year College</option>        
      </select>
</div>
<div class = "col-sm-4">
      <small><strong>Current Level on First Availment:</strong> <?php echo $row['sp_edu1'];?></small>
</div>     
<div class = "col-sm-2">
    <input type="text" class="form-control" id="fgrade" placeholder="Average Grade" name="fgrade" autocomplete="off" value="<?php echo $row['sp_grade_first'];?>">     
</div>
</div>
</div>

      <div class="form-group">
      <label for="educational2">2nd Availment Educational Level and Grade:</label>
      <div class="col-sm-12">
<div class="col-sm-6">
      <select class="form-control" id="educational2" name="educational2" required>
        <option value="" selected="selected">SELECT</option>
        <option value="Not Yet Availed">Not Yet Availed</option>
        <option value="Not Specified">Not Specified</option>
        <option value="1st Year High School/Grade 7 (For Kto12)">1st Year High School/Grade 7 (For Kto12)</option>
        <option value="2nd Year High School/Grade 8 (For Kto12)">2nd Year High School/Grade 8 (For Kto12)</option>
        <option value="3rd Year High School/Grade 9 (For Kto12)">3rd Year High School/Grade 9 (For Kto12)</option>
        <option value="4th Year High School/Grade 10 (For Kto12)">4th Year High School/Grade 10 (For Kto12)</option>
        <option value="Grade 11 (For Kto12)">Grade 11 (For Kto12)</option>
        <option value="Grade 12 (For Kto12)">Grade 12 (For Kto12)</option>
        <option value="1st Year College">1st Year College</option>
        <option value="2nd Year College">2nd Year College</option>  
        <option value="3rd Year College">3rd Year College</option> 
        <option value="4th Year College">4th Year College</option> 
        <option value="5th Year College">5th Year College</option>        
      </select>
</div>
<div class = "col-sm-4">
      <small><strong>Current Level on Second Availment:</strong> <?php echo $row['sp_edu2'];?></small>
</div>     
<div class = "col-sm-2">
    <input type="text" class="form-control" id="sgrade" placeholder="Average Grade" name="sgrade" autocomplete="off" value="<?php echo $row['sp_grade_second'];?>">     
</div>
</div>
</div>


      <div class="form-group">
      <label for="educational3">3rd Availment Educational Level and Grade:</label>
      <div class="col-sm-12">
<div class="col-sm-6">
      <select class="form-control" id="educational3" name="educational3" required>
        <option value="" selected="selected">SELECT</option>
        <option value="Not Yet Availed">Not Yet Availed</option>
        <option value="Not Specified">Not Specified</option>
        <option value="1st Year High School/Grade 7 (For Kto12)">1st Year High School/Grade 7 (For Kto12)</option>
        <option value="2nd Year High School/Grade 8 (For Kto12)">2nd Year High School/Grade 8 (For Kto12)</option>
        <option value="3rd Year High School/Grade 9 (For Kto12)">3rd Year High School/Grade 9 (For Kto12)</option>
        <option value="4th Year High School/Grade 10 (For Kto12)">4th Year High School/Grade 10 (For Kto12)</option>
        <option value="Grade 11 (For Kto12)">Grade 11 (For Kto12)</option>
        <option value="Grade 12 (For Kto12)">Grade 12 (For Kto12)</option>
        <option value="1st Year College">1st Year College</option>
        <option value="2nd Year College">2nd Year College</option>  
        <option value="3rd Year College">3rd Year College</option> 
        <option value="4th Year College">4th Year College</option> 
        <option value="5th Year College">5th Year College</option>        
      </select>
</div>
<div class = "col-sm-4">
      <small><strong>Current Level on Third Availment:</strong> <?php echo $row['sp_edu3'];?></small>
</div>     
<div class = "col-sm-2">
    <input type="text" class="form-control" id="tgrade" placeholder="Average Grade" name="tgrade" autocomplete="off" value="<?php echo $row['sp_grade_third'];?>">     
</div>
</div>
</div>

    <div class="form-group modal-footer">
       <input class="btn btn-info btn-update col-sm-2 col-sm-offset-5" type="submit" value="Update">
    </div>          
    </form>          
    </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
