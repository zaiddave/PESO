<div class="modal fade" data-keyboard="false" data-backdrop="static" id="certificate_year" tabindex="-1" role="dialog" aria-labelledby="certificate" aria-hidden="true">
  <div class="modal-dialog ">
    <div class="modal-content">
      <div class="modal-header green">
        <button type="button" data-dismiss="modal" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="certificate" style="color:white"><center><strong>Certification Date</strong></center></h4>
      </div>

      <div class="modal-body">
      
      <form class="form-horizontal" method="post" action="certificate.php" enctype="multipart/form-data">

      <div style="margin-right:20px; margin-left:20px;">

      <input type="hidden" class="form-control" name="id">

<div class="form-group">    
    <label for="day" class="text-color-2">Year of Certification:</label></div>
    <div class="col-md-4">
       <select class="form-control" id="day" name="day" required>
        <option value="" selected="selected">SELECT DAY</option>
        <option value="1st">1st</option><option value="2nd">2nd</option><option value="3rd">3rd</option><option value="4th">4th</option><option value="5th">5th</option><option value="6th">6th</option><option value="7th">7th</option><option value="8th">8th</option><option value="9th">9th</option><option value="10th">10th</option><option value="11th">11th</option><option value="12th">12th</option><option value="13th">13th</option><option value="14th">14th</option><option value="15th">15th</option><option value="16th">16th</option><option value="17th">17th</option><option value="18th">18th</option><option value="19th">19th</option><option value="20th">20th</option><option value="21st">21st</option><option value="22nd">22nd</option><option value="23rd">23rd</option><option value="24th">24th</option><option value="25th">25th</option><option value="26th">26th</option><option value="27th">27th</option><option value="28th">28th</option><option value="29th">29th</option><option value="30th">30th</option><option value="31st">31st</option>
      </select>
      </div>
      <div class="col-md-4">
      <select class="form-control" id="month" name="month" required>
        <option value="" selected="selected">SELECT MONTH</option>
        <option value="January">January</option>
        <option value="February">February</option>
        <option value="March">March</option>
        <option value="April">April</option>
        <option value="May">May</option>
        <option value="June">June</option>
        <option value="July">July</option>
        <option value="August">August</option>
        <option value="September">September</option>
        <option value="October">October</option>
        <option value="November">November</option>
        <option value="December">December</option>
      </select>
      </div>
      <div class="col-md-4">
      <select class="form-control" id="year" name="year" required>
        <option value="" selected="selected">SELECT YEAR</option>
        <?php for($i=2000;$i<=2100;$i++){?>
          <option value="<?php echo $i?>"><?php echo $i ?></option>
        <?php }?>
      </select>
      </div>
 </div>
<br><br>
    <div class="form-group modal-footer">
                 <input class="btn btn-success save btn-block" type="submit" value="Get Certificate">
</div>

        </div>
      </form>
      </div>
      </div>
    </div>
  </div>