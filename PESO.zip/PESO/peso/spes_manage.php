<div class="modal fade bs-example-modal-sm" id="spes_manage" tabindex="-1" role="dialog" aria-labelledby="spes" aria-hidden="true">
  <div class="modal-dialog modal-sm ">
    <div class="modal-content">
      <div class="modal-header update">
        <button type="button" data-dismiss="modal" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="spes" ><strong><center>Manage</center></strong></h4>
      </div>

      <div class="modal-body">     
      <p><center>What Do You Want To Update?</center></p>
      <div class="form-group modal-footer">            
      <center>
      <form method="post" action="spes_personal.php" target="_blank">
      <input type="hidden" name="id" >
      <button class="btn btn-primary btn-block" name="btnPersonal" data-toggle="tooltip" data-placement="top" title="Manage SPES Applicant's Personal Information.">Personal Information</button>
      </form></br>
      <form method="post" action="spes_availment.php" target="_blank">
      <input type="hidden" name="sid" >
      <button class="btn btn-info btn-block" name="btnAvail" data-toggle="tooltip" data-placement="top" title="Avail another SPES.">Availment Options</button></form><br>
      <form method="post" action="spes_edu.php" target="_blank">
      <input type="hidden" name="eid" >
      <button class="btn btn-warning btn-block" name="btnEdu" data-toggle="tooltip" data-placement="top" title="Manage educational level and grades.">Educational Level and/or Grade</button></form>
      </center>
      </div>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->