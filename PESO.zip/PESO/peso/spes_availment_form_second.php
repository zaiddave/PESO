<?php
session_start();
require_once("db_con/connect.php");
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}
//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values
	$id = clean($_POST['id']);
	$edu = clean($_POST['educational1']);
	$avail = clean($_POST['avail']);
	$batch = clean($_POST['batch']);
	$year = clean($_POST['year']);
	$grade = clean($_POST['grade']);



	$query = "UPDATE ps_spes SET sp_edu2 = '$edu', sp_second_availment = '$avail', sp_batch_second_year = '$batch', sp_second_year = '$year', sp_grade_second = '$grade' WHERE sp_id = '$id' ";

	mysql_query($query) or die(mysql_error()); 

	$success = '<div class="alert alert-success" role="alert">Successfully <b>updated</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';
    $_SESSION['result'] = $success;
	header('location:spes_report.php');	


?>