<?php
session_start();
require_once("db_con/connect.php");
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values
	$id = clean($_POST['id']);
	
	$query = "DELETE ps_ffi, ps_job_interview_form
			FROM ps_ffi
			JOIN ps_job_interview_form ON ps_job_interview_form.j_id = ps_ffi.j_id
			WHERE ps_ffi.j_id = $id" ;

	mysql_query($query) or die(mysql_error());


	$warning = '<div class="alert alert-warning" role="alert"><b>Delete</b> successful <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

    $_SESSION['result'] = $warning;
	header('location:ffi_manage.php');
?>