<div class="col-md-12">
 <div class="container shadow col-md-12">
    <? include('qualified_total_table.php') ?> 
</div>
</div>