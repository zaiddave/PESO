<?php
session_start();
include('meta.php') ?>

<title> PESO </title>

<?php include('head.php');

include('applicant_navbar.php');

//include('side_container.php');

include('applicant_container.php') ?>

 </body>
 <script type="text/javascript">
$(document).ready(function($){
    $("#auto_course").autocomplete({
        source: "json_data/json_course.php",
        minLength: 1
    });  
});
</script>
 <script src="assets/scrollable_menu.js" type="text/javascript"></script>
 </html>