<?php
session_start();
include('meta.php') ?>

<title> PESO </title>

<?php include('head.php');

include('navbar.php');

include('employer_manage_container.php') ?> 



</body>
<script type="text/javascript">
//this script is responsible for the tab location to stay in place after submission
var hash = document.location.hash;
var prefix = "tab_";
if (hash) {
    $('.nav-tabs a[href="'+hash.replace(prefix,"")+'"]').tab('show');
} 

// Change hash for page-reload
$('.nav-tabs a').on('shown.bs.tab', function (e) {
    window.location.hash = e.target.hash.replace("#", "#" + prefix);
});
</script>
</html>
