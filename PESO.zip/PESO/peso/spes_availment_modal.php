<?
//function to sanitize values received from the form. Prevents SQL injection

  function clean($str){
    $str = @trim($str);
    if(get_magic_quotes_gpc()){
      $str = stripslashes($str);
    }
    return mysql_real_escape_string($str);
  }

  $id = clean($_POST['sid']);
  $query = mysql_query("SELECT * FROM ps_spes WHERE sp_id = '$id'");
  $row = mysql_fetch_array($query);

?>

<div class="modal fade bs-example-modal-sm" data-keyboard="false" data-backdrop="static" id="spes_availment" tabindex="-1" role="dialog" aria-labelledby="spes_availlabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header update">
        <a href="spes_report.php">
        <button type="button" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button></a>
        <h4 class="modal-title" id="spes_availlabel" ><strong><center>Avail Another SPES</center></strong></h4>
      </div>

    <div class="modal-body">
    <?
    if($row['sp_second_availment'] == "Not Yet Availed"){ ?>
      <form class="form-horizontal" method="post" action="spes_availment_form_second.php" enctype="multipart/form-data">
      <div class="form-group">
        <div class="col-sm-12">
        <center>
      <div class="alert alert-info" role="alert">
      <h5><strong>Second Availment</strong></h5>
      </div>
      <input type="hidden" name="id" value="<? echo $id?>">
      <input type="hidden" name="avail" value="Second Availment">
      <blockquote class="blockquote-primary"><p><b>Name:</b> <?php echo $row['sp_fname'].' '.$row['sp_lname']?></p></blockquote>

      <select class="form-control" id="educational1" name="educational1" required>
        <option value="" selected="selected">SELECT EDUCATIONAL LEVEL</option>        
        <option value="Not Specified">Not Specified</option>
        <option value="1st Year High School/Grade 7 (For Kto12)">1st Year High School/Grade 7 (For Kto12)</option>
        <option value="2nd Year High School/Grade 8 (For Kto12)">2nd Year High School/Grade 8 (For Kto12)</option>
        <option value="3rd Year High School/Grade 9 (For Kto12)">3rd Year High School/Grade 9 (For Kto12)</option>
        <option value="4th Year High School/Grade 10 (For Kto12)">4th Year High School/Grade 10 (For Kto12)</option>
        <option value="Grade 11 (For Kto12)">Grade 11 (For Kto12)</option>
        <option value="Grade 12 (For Kto12)">Grade 12 (For Kto12)</option>
        <option value="1st Year College">1st Year College</option>
        <option value="2nd Year College">2nd Year College</option>  
        <option value="3rd Year College">3rd Year College</option> 
        <option value="4th Year College">4th Year College</option> 
        <option value="5th Year College">5th Year College</option>        
      </select><br>

      <select class="form-control" id="batch" name="batch" required>
        <option value="" selected="selected">Select Batch</option>        
        <option value="Batch 1">First Batch</option>        
        <option value="Batch 2">Second Batch</option>
        <option value="Batch 3">Third Batch</option>                
        <option value="Batch 4">Fourth Batch</option>
      </select><br>
    

         
      <select class="form-control" id="year" name="year" required>
        <option value="" selected="selected">Select Year</option>        
        <?php 
        for ($i=2000; $i <=2100 ; $i++) { 
        echo "<option value='$i'>$i</option>";
        }
        ?>        
      </select><br>
              
    <input type="text" class="form-control" id="grade" placeholder="Average Grade" name="grade" autocomplete="off"> 
    </center><br><br>

    <div class="form-group modal-footer">
       <input class="btn btn-info btn-update btn-block" type="submit" value="Update">
    </div>          
    </div>
    </div>          
    </form>      
    <? }
    elseif($row['sp_second_availment'] == "Second Availment" && $row['sp_third_availment'] == "Not Yet Availed"){ ?>
      <form class="form-horizontal" method="post" action="spes_availment_form_third.php" enctype="multipart/form-data">
      <div class="form-group">
        <div class="col-sm-12">
        <center>
      <div class="alert alert-info" role="alert">
      <h5><strong>Third Availment</strong></h5>
      </div>
      <input type="hidden" name="tid" value="<? echo $id?>">
      <input type="hidden" name="tavail" value="Third Availment">
      <blockquote class="blockquote-primary"><p><b>Name:</b> <?php echo $row['sp_fname'].' '.$row['sp_lname']?></p></blockquote>

      <select class="form-control" id="educational2" name="educational2" required>
        <option value="" selected="selected">SELECT EDUCATIONAL LEVEL</option>        
        <option value="Not Specified">Not Specified</option>
        <option value="1st Year High School/Grade 7 (For Kto12)">1st Year High School/Grade 7 (For Kto12)</option>
        <option value="2nd Year High School/Grade 8 (For Kto12)">2nd Year High School/Grade 8 (For Kto12)</option>
        <option value="3rd Year High School/Grade 9 (For Kto12)">3rd Year High School/Grade 9 (For Kto12)</option>
        <option value="4th Year High School/Grade 10 (For Kto12)">4th Year High School/Grade 10 (For Kto12)</option>
        <option value="Grade 11 (For Kto12)">Grade 11 (For Kto12)</option>
        <option value="Grade 12 (For Kto12)">Grade 12 (For Kto12)</option>
        <option value="1st Year College">1st Year College</option>
        <option value="2nd Year College">2nd Year College</option>  
        <option value="3rd Year College">3rd Year College</option> 
        <option value="4th Year College">4th Year College</option> 
        <option value="5th Year College">5th Year College</option>        
      </select><br>

      <select class="form-control" id="tbatch" name="tbatch" required>
        <option value="" selected="selected">Select Batch</option>        
        <option value="Batch 1">First Batch</option>        
        <option value="Batch 2">Second Batch</option>
        <option value="Batch 3">Third Batch</option>                
        <option value="Batch 4">Fourth Batch</option>
      </select><br>
    

         
      <select class="form-control" id="tyear" name="tyear" required>
        <option value="" selected="selected">Select Year</option>        
        <?php 
        for ($i=2000; $i <=2100 ; $i++) { 
        echo "<option value='$i'>$i</option>";
        }
        ?>        
      </select><br>
              
    <input type="text" class="form-control" id="tgrade" placeholder="Average Grade" name="tgrade" autocomplete="off"> 
    </center><br><br>

    <div class="form-group modal-footer">
       <input class="btn btn-info btn-update btn-block" type="submit" value="Update">
    </div>          
    </div>
    </div>          
    </form>      
    <? }
    else{ ?>
      <blockquote class="blockquote-primary"><p><b>Name:</b> <?php echo $row['sp_fname'].' '.$row['sp_lname']?></p></blockquote>
      <div class="alert alert-warning" role="alert">
      <p><center><span class="glyphicon glyphicon-exclamation-sign"></span><br>Maximum <strong>SPES</strong> availment reach.<br>Cannot have another 4th availment SPES program.</center></p>
      </div>
    <? }  ?>
    </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
