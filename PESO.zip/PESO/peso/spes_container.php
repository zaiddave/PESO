 <div class="container shadow col-md-10 col-md-offset-1">

<div class="col-md-12">
<?php
  if(isset($_SESSION['result'])){
    echo $_SESSION['result'];
    unset($_SESSION['result']);
  }
?>
</div>

 <form class="form-horizontal" method="post" action="spes_form.php" enctype="multipart/form-data">
       
<div class="form-group">
    <label for="company" class="text-color-2 col-sm-2 control-label">Applicant Name:</label>
    <div class="col-sm-3">
      <input type="text" class="form-control" id="fname" placeholder="First Name" name="fname" autocomplete="off" required>
    </div>
    <div class="col-sm-3">
      <input type="text" class="form-control" id="mname" placeholder="Middle Name" autocomplete="off" name="mname" >
    </div>
    <div class="col-sm-3">
      <input type="text" class="form-control" id="lname" placeholder="Last Name" name="lname" autocomplete="off" required>
    </div>
</div>

<div class="form-group">
    <label for="bdate" class="text-color-2 col-sm-2 control-label">Date of Birth:</label>
    <div class="col-sm-2">
    <input type="text" class="form-control datepicker" id="bdate" placeholder="mm/dd/yyyy" name="bdate" autocomplete="off">
    </div>
</div>
            
<div class="form-group">
    <label for="gender" class="text-color-2 col-sm-2 control-label">Gender:</label>
    <div class="col-sm-3">
    <div class="btn-group" data-toggle="buttons">
    <label class="btn btn-primary btn-enhance-primary">
    <input type="radio" name="gender" value="Male" id="gender" required>Male
    </label>
    <label class="btn btn-primary btn-enhance-primary">
    <input type="radio" name="gender" value="Female" id="gender" required>Female
    </label>
    </div>
    </div>
</div>

<div class="form-group">
    <label for="barangay" class="text-color-2 col-sm-2 control-label">Barangay:</label>
    <div class="col-md-2">
    <input type="text" class="form-control" id="brgy" placeholder="Barangay" name="brgy" autocomplete="off">
    </div>
    <label for="city" class="text-color-2 col-sm-1 control-label">City:</label>
    <div class="col-md-2">
    <input type="text" class="form-control" id="city" placeholder="City" name="city" autocomplete="off">
    </div>
    <label for="lgu" class="text-color-2 col-sm-1 control-label">LGU:</label>
    <div class="col-md-2">      
    <input type="text" class="form-control" id="lgu" placeholder="Name of LGU" name="lgu" autocomplete="off" > 
    </div>
</div>

<div class="form-group">
    <label for="favailment" class="text-color-2 col-sm-2 control-label">First Availment:</label>
    
    <input type="hidden" name="favailment" value="First Availment">

    <div class="col-sm-3">
      <select class="form-control" id="fbatch" name="fbatch" required>
        <option value="" selected="selected">SELECT BATCH</option>        
        <option value="Batch 1">First Batch</option>        
        <option value="Batch 2">Second Batch</option>
        <option value="Batch 3">Third Batch</option>                
        <option value="Batch 4">Fourth Batch</option>
      </select>
    </div>

    <div class="col-sm-3">      
      <select class="form-control" id="fyear" name="fyear" required>
        <option value="" selected="selected">SELECT YEAR</option>         
        <?php 
        for ($i=2000; $i <=2100 ; $i++) { 
          echo "<option value='$i'>$i</option>";
        }
        ?>        
      </select>
    </div>
    <div class="col-md-3">      
    <input type="text" class="form-control" id="fgrade" placeholder="Average Grade" name="fgrade" autocomplete="off"> 
    </div>
</div>

<div class="form-group">
    <label for="educational1" class="text-color-2 col-sm-2 control-label">Educational Level:</label>
    <div class="col-sm-4">
      <select class="form-control" id="educational1" name="educational1" required>
        <option value="" selected="selected">SELECT EDUCATIONAL LEVEL</option>
        <option value="Not Specified">Not Specified</option>
        <option value="1st Year High School/Grade 7 (For Kto12)">1st Year High School/Grade 7 (For Kto12)</option>
        <option value="2nd Year High School/Grade 8 (For Kto12)">2nd Year High School/Grade 8 (For Kto12)</option>
        <option value="3rd Year High School/Grade 9 (For Kto12)">3rd Year High School/Grade 9 (For Kto12)</option>
        <option value="4th Year High School/Grade 10 (For Kto12)">4th Year High School/Grade 10 (For Kto12)</option>
        <option value="Grade 11 (For Kto12)">Grade 11 (For Kto12)</option>
        <option value="Grade 12 (For Kto12)">Grade 12 (For Kto12)</option>
        <option value="Technical-Vocational">Technical-Vocational</option>
        <option value="Out of School Youth">OSY</option>
        <option value="1st Year College">1st Year College</option>
        <option value="2nd Year College">2nd Year College</option>  
        <option value="3rd Year College">3rd Year College</option> 
        <option value="4th Year College">4th Year College</option> 
        <option value="5th Year College">5th Year College</option>                
      </select>
    </div>
</div>

<hr>

<div class="form-group">
    <label for="savailment" class="text-color-2 col-sm-2 control-label">Second Availment:</label>
    <div class="col-sm-3">
      <select class="form-control" id="savailment" name="savailment" required>
        <option value="" selected="selected">SELECT AVAILMENT</option>   
        <option value="Not Yet Availed">Not Yet Availed</option>   
        <option value="Second Availment">Second Availment</option>        
      </select>
    </div>

    <div class="col-sm-3">
      <select class="form-control" id="sbatch" name="sbatch" required>
        <option value="" selected="selected">SELECT BATCH</option>   
        <option value="Not Yet Availed">Not Yet Availed</option>   
        <option value="Batch 1">First Batch</option>        
        <option value="Batch 2">Second Batch</option>
        <option value="Batch 3">Third Batch</option>                
        <option value="Batch 4">Fourth Batch</option>
      </select>
    </div>

    <div class="col-sm-2">      
      <select class="form-control" id="syear" name="syear" required>
        <option value="" selected="selected">SELECT YEAR</option>   
        <option value="Not Yet Availed">Not Yet Availed</option>        
        <?php 
        for ($i=2000; $i <=2100 ; $i++) { 
          echo "<option value='$i'>$i</option>";
        }
        ?>        
      </select>
    </div>
    <div class="col-md-2">      
    <input type="text" class="form-control" id="sgrade" placeholder="Average Grade" name="sgrade" autocomplete="off"> 
    </div>
</div>

<div class="form-group">
    <label for="educational2" class="text-color-2 col-sm-2 control-label">Educational Level:</label>
    <div class="col-sm-4">
      <select class="form-control" id="educational2" name="educational2" required>
        <option value="" selected="selected">SELECT  EDUCATIONAL LEVEL</option>
        <option value="Not Yet Availed">Not Yet Availed</option>
        <option value="Not Specified">Not Specified</option>
        <option value="1st Year High School/Grade 7 (For Kto12)">1st Year High School/Grade 7 (For Kto12)</option>
        <option value="2nd Year High School/Grade 8 (For Kto12)">2nd Year High School/Grade 8 (For Kto12)</option>
        <option value="3rd Year High School/Grade 9 (For Kto12)">3rd Year High School/Grade 9 (For Kto12)</option>
        <option value="4th Year High School/Grade 10 (For Kto12)">4th Year High School/Grade 10 (For Kto12)</option>
        <option value="Grade 11 (For Kto12)">Grade 11 (For Kto12)</option>
        <option value="Grade 12 (For Kto12)">Grade 12 (For Kto12)</option>
        <option value="Technical-Vocational">Technical-Vocational</option>
        <option value="Out of School Youth">OSY</option>
        <option value="1st Year College">1st Year College</option>
        <option value="2nd Year College">2nd Year College</option>  
        <option value="3rd Year College">3rd Year College</option> 
        <option value="4th Year College">4th Year College</option> 
        <option value="5th Year College">5th Year College</option>        
      </select>
    </div>
</div>

<hr>

<div class="form-group">
    <label for="savailment" class="text-color-2 col-sm-2 control-label">Third Availment:</label>
    <div class="col-sm-3">
      <select class="form-control" id="tavailment" name="tavailment" required>
        <option value="" selected="selected">SELECT AVAILMENT</option>   
        <option value="Not Yet Availed">Not Yet Availed</option>        
        <option value="Third Availment">Third Availment</option>        
      </select>
    </div>

    <div class="col-sm-3">
      <select class="form-control" id="tbatch" name="tbatch" required>
        <option value="" selected="selected">SELECT BATCH</option>   
        <option value="Not Yet Availed">Not Yet Availed</option>        
        <option value="Batch 1">First Batch</option>        
        <option value="Batch 2">Second Batch</option>
        <option value="Batch 3">Third Batch</option>                
        <option value="Batch 4">Fourth Batch</option>
      </select>
    </div>

    <div class="col-sm-2">      
      <select class="form-control" id="tyear" name="tyear" required>
        <option value="" selected="selected">SELECT YEAR</option>   
        <option value="Not Yet Availed">Not Yet Availed</option>        
        <?php 
        for ($i=2000; $i <=2100 ; $i++) { 
          echo "<option value='$i'>$i</option>";
        }
        ?>        
      </select>
    </div>
    <div class="col-md-2">      
    <input type="text" class="form-control" id="tgrade" placeholder="Average Grade" name="tgrade" autocomplete="off"> 
    </div>
</div>

<div class="form-group">
    <label for="educational3" class="text-color-2 col-sm-2 control-label">Educational Level:</label>
    <div class="col-sm-4">
      <select class="form-control" id="educational3" name="educational3" required>
        <option value="" selected="selected">SELECT EDUCATIONAL LEVEL</option>
        <option value="Not Yet Availed">Not Yet Availed</option>
        <option value="Not Specified">Not Specified</option>
        <option value="1st Year High School/Grade 7 (For Kto12)">1st Year High School/Grade 7 (For Kto12)</option>
        <option value="2nd Year High School/Grade 8 (For Kto12)">2nd Year High School/Grade 8 (For Kto12)</option>
        <option value="3rd Year High School/Grade 9 (For Kto12)">3rd Year High School/Grade 9 (For Kto12)</option>
        <option value="4th Year High School/Grade 10 (For Kto12)">4th Year High School/Grade 10 (For Kto12)</option>
        <option value="Grade 11 (For Kto12)">Grade 11 (For Kto12)</option>
        <option value="Grade 12 (For Kto12)">Grade 12 (For Kto12)</option>
        <option value="Technical-Vocational">Technical-Vocational</option>
        <option value="Out of School Youth">OSY</option>
        <option value="1st Year College">1st Year College</option>
        <option value="2nd Year College">2nd Year College</option>  
        <option value="3rd Year College">3rd Year College</option> 
        <option value="4th Year College">4th Year College</option> 
        <option value="5th Year College">5th Year College</option>        
      </select>
    </div>
</div>
<hr>
<div class="form-group">
    <label for="remark" class="text-color-2 col-sm-2 control-label">Remarks:</label>
    <div class="col-sm-4">
    <textarea rows="2" class="form-control" name="remark" id="remark"></textarea>
    </div>
</div>
<br><br><br>

            <div class= "form-group">
            <input class="btn btn-success save col-xs-3 col-xs-offset-4 col-sm-2 col-sm-offset-5 col-md-2 col-md-offset-5" type="submit" value="Save">
            </div>

            <br>
            <br>
        
    </form>
</div>