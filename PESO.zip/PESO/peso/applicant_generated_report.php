<?php
session_start();
include('meta.php') ?>
<title>PESO</title>
<?php include('head.php') ?>

<?php include('navbar.php') ?>

<?php include('applicant_generated_report_container.php') ?> 

</body>
</html>