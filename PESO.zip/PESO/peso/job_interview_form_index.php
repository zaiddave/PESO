<?php
session_start();
require_once('db_con/connect.php');


//function to sanitizes values received from the form. Prevents SQL injection

function clean($str){
	$str = @trim($str);
	if(get_magic_quotes_gpc()){
		$str = stripslashes($str);
	}
	return mysql_real_escape_string($str);
}

//sanitize the POST values

$fname = clean($_POST['fname']);
$mname = clean($_POST['mname']);
$lname = clean($_POST['lname']);
$gender = clean($_POST['gender']);
$position = clean($_POST['position']);
$age = clean ($_POST['age']);
//$telephone = clean($_POST['telephone']);
$cell = clean($_POST['cell']);
//$email = clean($_POST['email']);
$address = clean($_POST['address']);
$company = clean($_POST['company']);
$sponsor = clean($_POST['sponsor']);
$venue = clean($_POST['venue']);
$ryear = clean($_POST['ryear']);
$rmonth = clean($_POST['rmonth']);
$recruitment = clean($_POST['recruitment']);
$date = clean($_POST['date']);
$employment_type = clean($_POST['employmentType']);
$status = clean($_POST['status']);

$dates = explode("/", $date);

$year = $dates[2];



if($ryear == "default" || $rmonth == "default" || $recruitment == "default" || $employment_type == "default"){
	$error = '<div class="alert alert-danger" role="alert">You did not select an appropriate options from either <b>Recruitment Type</b> or <b>Employment Type</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result1'] = $error;
		header('location:job_interview_index.php');	
}
elseif($ryear != $year){
	$error = '<div class="alert alert-danger" role="alert">You have input an invalid value from either <b>Year</b> from <b>Recruitment Type</b> or <b>Date</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result1'] = $error;
		header('location:job_interview_index.php');	
}
else{
	$qsponsor = "INSERT INTO ps_sponsor (s_name)
	SELECT * FROM (SELECT '$sponsor') AS tmp
	WHERE NOT EXISTS (
    SELECT s_name FROM ps_sponsor WHERE s_name = '$sponsor'
	) LIMIT 1";
	mysql_query($qsponsor) or die(mysql_error());

	$qvenue = "INSERT INTO ps_venue (v_name)
	SELECT * FROM (SELECT '$venue') AS tmp
	WHERE NOT EXISTS (
    SELECT v_name FROM ps_venue WHERE v_name = '$venue'
	) LIMIT 1";
	mysql_query($qvenue) or die(mysql_error());

	$query1 = " INSERT INTO ps_job_interview_form (j_year, j_month, j_type, j_recruitment_type, j_date, j_venue, j_activity_date, j_employment_type, j_company_name, j_position_applied, j_gender, j_status) VALUES ('$ryear', '$rmonth', '$recruitment', '$ryear-$rmonth-$recruitment', '$date', '$venue', '$date - $venue', '$employment_type', '$company', '$position', '$gender', '$status') " ;
	mysql_query($query1) or die(mysql_error());

if($status == "HOTS"){

	$query= "INSERT into ps_hots (j_id, hots_fname, hots_mname, hots_lname, hots_applied, hots_gender, hots_age, hots_cellphone, hots_address, hots_company, hots_recruitment_type, hots_activity_date, hots_sponsor, hots_venue) VALUES (LAST_INSERT_ID(), '$fname', '$mname', '$lname', '$position', '$gender', '$age', '$cell', '$address', '$company', '$ryear-$rmonth-$recruitment', '$date', '$sponsor', '$venue')" ;

mysql_query($query) or die(mysql_error());

$success = '<div class="alert alert-success" role="alert"><b>Successfully</b> added <b>'.$fname.' '.$mname.' '.$lname.'</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result1'] = $success;
header('location:job_interview_index.php');	
}

elseif($status == "Qualified"){
	$query= "INSERT into ps_qualified (j_id, q_fname, q_mname, q_lname, q_applied, q_gender, q_age, q_cellphone, q_address, q_company, q_recruitment_type, q_activity_date, q_sponsor, q_venue) VALUES (LAST_INSERT_ID(), '$fname', '$mname', '$lname', '$position', '$gender', '$age', '$cell', '$address', '$company', '$ryear-$rmonth-$recruitment', '$date', '$sponsor', '$venue')" ;

mysql_query($query) or die(mysql_error());

$success = '<div class="alert alert-success" role="alert"><b>Successfully</b> added <b>'.$fname.' '.$mname.' '.$lname.'</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result1'] = $success;
header('location:job_interview_index.php');	
}

elseif($status == "Not Qualified"){
	$query= "INSERT into ps_not_qualified (j_id, qn_fname, qn_mname, qn_lname, qn_applied, qn_gender, qn_age, qn_cellphone, qn_address, qn_company, qn_recruitment_type, qn_activity_date, qn_sponsor, qn_venue) VALUES (LAST_INSERT_ID(),'$fname', '$mname', '$lname', '$position', '$gender', '$age', '$cell', '$address', '$company', '$ryear-$rmonth-$recruitment', '$date', '$sponsor', '$venue')" ;

mysql_query($query) or die(mysql_error());

$success = '<div class="alert alert-success" role="alert"><b>Successfully</b> added <b>'.$fname.' '.$mname.' '.$lname.'</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result1'] = $success;
header('location:job_interview_index.php');	
}

elseif($status == "FFI"){
	$query= "INSERT into ps_ffi (j_id, ffi_fname, ffi_mname, ffi_lname, ffi_applied, ffi_gender, ffi_age, ffi_cellphone, ffi_address, ffi_company, ffi_recruitment_type, ffi_activity_date, ffi_sponsor, ffi_venue) VALUES (LAST_INSERT_ID(), '$fname', '$mname', '$lname', '$position', '$gender', '$age', '$telephone', '$cell', '$email', '$address', '$company', '$ryear-$rmonth-$recruitment', '$date', '$sponsor', '$venue')" ;

mysql_query($query) or die(mysql_error());

$success = '<div class="alert alert-success" role="alert"><b>Successfully</b> added <b>'.$fname.' '.$mname.' '.$lname.'</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result1'] = $success;
		header('location:job_interview_index.php');	
}

}

?>