<?php
$mquery = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_gender = 'Male' AND j_status = 'Qualified' ");
$wMale = mysql_num_rows($mquery);
$fquery = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_gender = 'Female' AND j_status = 'Qualified' ");
$wFemale = mysql_num_rows($fquery);
$tQualifiedQuery = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_status = 'Qualified' ");
$tQualified = mysql_num_rows($tQualifiedQuery);
?>
<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>Total Qualified</b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>
	                    <table id="table0" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Recruitment Type</th>
									<th>Date/Venue</th>
									<th>Employment Type</th>
									<th>Company Name</th>
									<th>Male</th>
									<th>Female</th>
									<th>Qualified</th>
								</tr>
							</thead>

							<tbody>
								<tr>
									<th></th>
									<th></th>
									<th></th>
									<th></th>
									<th><h4><strong><?php echo $wMale?></strong></h4></th>
									<th><h4><strong><?php echo $wFemale?></strong></h4></th>
									<th><h4><strong><?php echo $tQualified?></strong></h4></th>
								</tr>
								<?php 
									$status = 'Qualified';
									$fetch = mysql_query("SELECT DISTINCT j_recruitment_type FROM ps_job_interview_form WHERE j_status = '$status' ORDER BY j_recruitment_type DESC ") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                					$recr = mysql_real_escape_string($row['j_recruitment_type']);	
                  				?>
                  				<tr>
									<td class="report-recruitment"><h4><strong><?php echo $row['j_recruitment_type']?></h4></strong></td>
									<td class="report-recruitment"></td>
									<td class="report-recruitment"></td>
									<td class="report-recruitment"></td>	
									<td class="report-recruitment"><h4><strong>
									<?php
										$total_male = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_gender = 'Male' AND j_status = '$status' ") or die(mysql_error());
										echo mysql_num_rows($total_male);
									?></strong></h4>
									</td>
									<td class="report-recruitment">
									<h4><strong>
									<?php
										$total_female = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_gender = 'Female' AND j_status = '$status' ") or die(mysql_error());
										echo mysql_num_rows($total_female);
									?></strong></h4>
									</td>
									<td class="report-recruitment">
									<h4><strong>
									<?php
										$total_gender = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_status = '$status' ") or die(mysql_error());
										echo mysql_num_rows($total_gender);
									?></strong></h4>
									</td>
								</tr>
									<?php 																		
									$fetch1 = mysql_query("SELECT DISTINCT j_activity_date FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_status = '$status' ORDER BY j_activity_date DESC") or die(mysql_error());
                					while($row1 = mysql_fetch_array($fetch1)){
                					$date = $row1['j_activity_date'];
                  				?>
								<tr>
									<td></td>
									<td class="report-date"><h5><strong><?php echo $row1['j_activity_date'] ?></strong></h5></td>
									<td class="report-date"></td>
									<td class="report-date"></td>
									<td class="report-date"><h5><strong>
									<?php
										$total_male_per_date = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_gender = 'Male' AND j_status = '$status' AND j_activity_date = '$date' ") or die(mysql_error());
										echo mysql_num_rows($total_male_per_date);
									?></strong></h5>
									</td>
									<td class="report-date">
									<h5><strong>
									<?php
										$total_female_per_date = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_gender = 'Female' AND j_status = '$status' AND j_activity_date = '$date' ") or die(mysql_error());
										echo mysql_num_rows($total_female_per_date);
									?></strong></h5>
									</td>
									<td class="report-date">
									<h5><strong>
									<?php
										$total_gender_per_date = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_status = '$status' AND j_activity_date = '$date' ") or die(mysql_error());
										echo mysql_num_rows($total_gender_per_date);
									?></strong></h5>
									</td>
								</tr>
									<?php 																		
									$fetch2 = mysql_query("SELECT DISTINCT j_employment_type FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_status = '$status' ") or die(mysql_error());
                					while($row2 = mysql_fetch_array($fetch2)){
                					$employment = mysql_real_escape_string($row2['j_employment_type']);
                  				?>
								<tr>
									<td></td>
									<td></td>									
									<td class="report-employment"><h5><strong><?php echo $row2['j_employment_type']?><h5><strong></td>
									<td class="report-employment"></td>
									<td class="report-employment"><h5><strong>
									<?php
										$total_male_per_employment_type = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_gender = 'Male' AND j_status = '$status' AND j_activity_date = '$date' AND j_employment_type = '$employment' ") or die(mysql_error());
										echo mysql_num_rows($total_male_per_employment_type);
									?></strong></h5>
									</td>
									<td class="report-employment"><h5><strong>
									<?php
										$total_female_per_employment_type = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_gender = 'Female' AND j_status = '$status' AND j_activity_date = '$date' AND j_employment_type = '$employment' ") or die(mysql_error());
										echo mysql_num_rows($total_female_per_employment_type);
									?></strong></h5>
									</td>
									<td class="report-employment">
									<h5><strong>
									<?php
										$total_gender_per_employment_type = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_status = '$status' AND j_activity_date = '$date' AND j_employment_type = '$employment' ") or die(mysql_error());
										echo mysql_num_rows($total_gender_per_employment_type);
									?></strong></h5>
									</td>
								</tr>
									<?php 																		
									$fetch3 = mysql_query("SELECT DISTINCT j_company_name FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_status = '$status' ") or die(mysql_error());
                					while($row3 = mysql_fetch_array($fetch3)){
                						$company = mysql_real_escape_string($row3['j_company_name']);
                  				?>
								<tr>
									<td></td>
									<td></td>									
									<td></td>
									<td class="report-company"><?php echo $row3['j_company_name']?></td>
									<td  class="report-gender">
									<?php
										$r_male = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_status = '$status' AND j_company_name = '$company' AND j_gender = 'Male' ") or die(mysql_error());
										echo mysql_num_rows($r_male);
									?>
									</td>
									<td class="report-gender">
									<?php
										$r_female = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_status = '$status' AND j_company_name = '$company' AND j_gender = 'Female' ") or die(mysql_error());
										echo mysql_num_rows($r_female);
									?>
									</td>
									<td class="report-status">
									<?php
										$r_gender = mysql_query("SELECT j_gender FROM ps_job_interview_form WHERE j_recruitment_type = '$recr' AND j_activity_date = '$date' AND j_employment_type = '$employment' AND j_status = '$status' AND j_company_name = '$company' ") or die(mysql_error());
										echo mysql_num_rows($r_gender);
									?>
									</td>
								</tr>
								<?php } ?>
								<?php } ?>
								<?php } ?>

								<tr>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<?php } ?>
								</tbody>

						</table>
					</div>
	</div>