<div class="col-md-12">
 <div class="container shadow col-md-12">
    <? include('not_qualified_total_table.php') ?> 
</div>
</div>