<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>Hired On The Spot Report</b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>
	                    <table id="table" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Recruitment Type</th>
									<th>Date</th>
									<th><center>Sponsor<br>or<br>Organization</center></th>
									<th>Applicant Name</th>
									<th>Position Applied</th>
									<th>Gender</th>
									<th>Age</th>
									<th>Contact Number</th>
									<th>Address</th>
									<th>Company</th>
									<th>Employed</th>
									<th>Total</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th class="job-fair-year"></th>
									<th class="job-fair-year"></th>
									<th class="job-fair-year"></th>
									<th class="job-fair-year"></th>
									<th class="job-fair-year"></th>
									<th class="job-fair-year"></th>
									<th class="job-fair-year"></th>
									<th class="job-fair-year"></th>
									<th class="job-fair-year"></th>
									<th class="job-fair-year"></th>
									<th class="job-fair-year"></th>
									<th class="job-fair-year">
									<?php
									$total = mysql_query("SELECT * FROM ps_hots");
									echo "<h4><center><b> ".mysql_num_rows($total)." </b></center></h4>";
									?>
									</th>
								</tr>
							<?php 									
									
									$fetch = mysql_query("SELECT DISTINCT hots_recruitment_type FROM ps_hots  ORDER BY hots_recruitment_type DESC ") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                						$recruit = mysql_real_escape_string($row['hots_recruitment_type']);
                  			?>
								<tr>
									<td class="report-employment"><?php echo $row['hots_recruitment_type']?></td>
									<td class="report-employment"></td>
									<td class="report-employment"></td>
									<td class="report-employment"></td>
									<td class="report-employment"></td>
									<td class="report-employment"></td>
									<td class="report-employment"></td>
									<td class="report-employment"></td>
									<td class="report-employment"></td>
									<td class="report-employment"></td>
									<td class="report-employment"></td>									
									<td class="report-employment"></td>
									
								</tr>
								<tr>
								<?php 																		
									$fetch1 = mysql_query("SELECT * FROM ps_hots WHERE hots_recruitment_type = '$recruit' ") or die(mysql_error());
                					while($row1 = mysql_fetch_array($fetch1)){
                					$id = mysql_real_escape_string($row1['j_id']);          						
                  			?>
									<td></td>
									<td class="job-fair"><?php echo $row1['hots_activity_date']." - ".$row1['hots_venue']?></td>
									<td class="job-fair"><?php echo $row1['hots_sponsor']?></td>
									<td class="job-fair"><?php echo $row1['hots_lname'] .", ".$row1['hots_fname']." ".$row1['hots_mname']?></td>
									<td class="job-fair"><?php echo $row1['hots_applied']?></td>
									<td class="job-fair"><?php echo $row1['hots_gender'] ?></td>
									<td class="job-fair"><?php echo $row1['hots_age'] ?></td>
									<td class="job-fair"><?php echo $row1['hots_cellphone']?></td>
									<td class="job-fair"><?php echo $row1['hots_address'] ?></td>
									<td class="job-fair">
									<a href="#!" data-toggle="tooltip" data-placement="top" title="<?php
									$fetch2 = mysql_query("SELECT * FROM ps_job_interview_form WHERE j_id = $id ");
									$tip = mysql_fetch_array($fetch2);
									echo $tip['j_employment_type'];
									 ?>">
									<?php echo $row1['hots_company'] ?>
									</a>
									</td>
									<td class="job-fair"><?php echo $row1['hots_employed'] ?></td>
									<td class="job-fair"></td>
								</tr>
								<?php } ?>
								<?php } ?>
							</tbody>
						</table>
                  </div>
                </div>
