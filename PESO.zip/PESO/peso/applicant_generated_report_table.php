<?php
$var1 = '08/08/2014';
$date1 = str_replace('/', '-', $var1);
$start = date('Y-m-d', strtotime($date1));
$var2 = '09/09/2017';
$date2 = str_replace('/', '-', $var2);
$end = date('Y-m-d', strtotime($date2));
if(isset($_POST['submit'])){
$a = $_POST['startdate'];
$a1 = str_replace('/', '-', $a);
$start = date('Y-m-d', strtotime($a1));
$b = $_POST['enddate'];
$b1 = str_replace('/', '-', $b);
$end = date('Y-m-d', strtotime($b1));
}
?>
<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>Applicant Report Table</b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>
                  <form class="form-inline" method="post">
                  	<div class="form-group">
					    <label for="register" class="text-color-2 col-sm-2 control-label">Filter Date:</label>
					    <div class="col-sm-8">      
					      <div class="input-group" id="register">      
					      <div class="input-group-addon">From:</div>
					      <input type="text" class="form-control datepicker" placeholder="mm/dd/yyyy" name="startdate" autocomplete="off" required="true">
					      <div class="add-on-primary input-group-addon"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span><span class="sr-only"></span></div>
					      <div class="input-group-addon">To:</div>
					      <input type="text" class="form-control datepicker" placeholder="mm/dd/yyyy" name="enddate" autocomplete="off" required="true">
					      <div class="add-on-warning input-group-addon"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span><span class="sr-only"></span></div>
					      <button type="submit" class="btn btn-success form-control" name="submit">Search</button>
					    </div>
					    </div>
					</div>
                  </form>
                  <br><br>
	                    <table id="table" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Applicant Name</th>
									<th>Gender</th>
									<th>Birthdate</th>
									<th>Age</th>
									<th>Address</th>
									<th>Contact Number/s</th>
									<th>Email</th>
									<th>Course</th>
									<th>Preferred Job</th>
									<th>Highest Educational Attainment</th>
									<th>Date Registered</th>
								</tr>
							</thead>
							<tbody>
							<?php 									
									 //NOT (ap_from_date < '$end' OR ap_from_date > '$start')
									$fetch = mysql_query("SELECT * FROM ps_applicant_registry WHERE ap_from_date >= '$start' OR ap_from_date <= '$end' ORDER BY ap_lname ASC") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                  			?>
								<tr>
									<td class="job-fair"><?php echo $row['ap_lname'] .", ".$row['ap_fname']." ".$row['ap_mname']?></td>
									<td class="job-fair"><?php echo $row['ap_gender'] ?></td>
									<td class="job-fair"><?php echo $row['ap_bdate'] ?></td>
									<td class="job-fair"><?php echo $row['ap_age'] ?></td>
									<td class="job-fair"><?php echo $row['ap_address'] ?></td>
									<td class="job-fair"><?php echo nl2br($row['ap_telephone'] ."\n"). nl2br($row['ap_cellphone']."\n") ?></td>
									<td class="job-fair"><?php echo nl2br($row['ap_email']."\n") ?></td>
									<td class="job-fair"><?php echo $row['ap_course'] ?></td>
									<td class="job-fair"><?php echo nl2br($row['ap_pref_job'] ."\n") ?></td>
									<td class="job-fair"><?php echo $row['ap_educ_bg'] ?></td>
									<td class="job-fair"><?php echo $row['ap_from_date']?></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                  </div>
                </div>
                
                