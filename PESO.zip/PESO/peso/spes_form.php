<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}

//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values
$fname = strtoupper(clean($_POST['fname']));
$mname = strtoupper(clean($_POST['mname']));
$lname = strtoupper(clean($_POST['lname']));
$bdate = clean($_POST['bdate']);
$gender = clean($_POST['gender']);
$educational1 = clean($_POST['educational1']);
$educational2 = clean($_POST['educational2']);
$educational3 = clean($_POST['educational3']);
$brgy = strtoupper(clean($_POST['brgy']));
$city = strtoupper(clean($_POST['city']));
$lgu = strtoupper(clean($_POST['lgu']));
$remark = strtoupper(clean($_POST['remark']));
$favail = clean($_POST['favailment']);
$fbatch = clean($_POST['fbatch']);
$fyear = clean($_POST['fyear']);
$fgrade = clean($_POST['fgrade']);
$savail = clean($_POST['savailment']);
$sbatch = clean($_POST['sbatch']);
$syear = clean($_POST['syear']);
$sgrade = clean($_POST['sgrade']);
$tavail = clean($_POST['tavailment']);
$tbatch = clean($_POST['tbatch']);
$tyear = clean($_POST['tyear']);
$tgrade = clean($_POST['tgrade']);

	//explode the date to get month, day and year
  $birthDate = explode("/", $bdate);
  //get age from date or birthdate
  $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
    ? ((date("Y") - $birthDate[2]) - 1)
    : (date("Y") - $birthDate[2]));

$query = "SELECT * FROM  ps_spes WHERE sp_fname = '$fname' AND sp_mname='$mname' AND sp_lname='$lname' ";
$result = mysql_query($query) or die(mysql_error());
	
if($result) {
//returns an error if there already exist another name
if(mysql_num_rows($result) > 0) {		
$error = '<div class="alert alert-warning" role="alert">SPES applicant <b>'.$fname.' '.$lname.' </b> already exist. Please update it instead if you want to add another availment <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

$_SESSION['result'] = $error;
header('location:spes.php');	
}
else{
if($fbatch == "Not Yet Availed" || $fyear == "Not Yet Availed"){
	$error = '<div class="alert alert-danger" role="alert">Please appropriately fill in the <b>First Availment Form</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result'] = $error;
		header('location:spes.php');	
}
elseif(($savail == "Not Yet Availed" || $sbatch == "Not Yet Availed" || $syear == "Not Yet Availed") && $sgrade !=""){
	$error = '<div class="alert alert-danger" role="alert">Please appropriately fill in the <b>Second Availment Form</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result'] = $error;
		header('location:spes.php');	
}
elseif(($savail == "Not Yet Availed" && $sbatch == "Not Yet Availed" && $syear == "Not Yet Availed" && $sgrade =="") && ($tavail != "Not Yet Availed" && $tbatch != "Not Yet Availed" && $tyear != "Not Yet Availed")){
	$error = '<div class="alert alert-danger" role="alert">Please appropriately fill in the <b>Second Availment Form</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result'] = $error;
		header('location:spes.php');	

}
elseif(($savail == "Not Yet Availed" && $sbatch == "Not Yet Availed" && $syear == "Not Yet Availed" && $sgrade =="") || ($savail != "Not Yet Availed" && $sbatch != "Not Yet Availed" && $syear != "Not Yet Availed")){

	if(($tavail == "Not Yet Availed" || $tbatch == "Not Yet Availed" || $tyear == "Not Yet Availed") && $tgrade != ""){
		$error = '<div class="alert alert-danger fade in" role="alert">Please appropriately fill in the <b>Third Availment Form</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	      	$_SESSION['result'] = $error;
			header('location:spes.php');	
	}
	elseif($tavail == "Not Yet Availed" && $tbatch == "Not Yet Availed" && $tyear == "Not Yet Availed" && $tgrade == ""){
	$qbrgy = "INSERT INTO ps_brgy (b_name)
	SELECT * FROM (SELECT '$brgy') AS tmp
	WHERE NOT EXISTS (
    SELECT b_name FROM ps_brgy WHERE b_name = '$brgy'
	) LIMIT 1";
	mysql_query($qbrgy) or die(mysql_error());

	$qcity = "INSERT INTO ps_city (c_name)
	SELECT * FROM (SELECT '$city') AS tmp
	WHERE NOT EXISTS (
    SELECT c_name FROM ps_city WHERE c_name = '$city'
	) LIMIT 1";
	mysql_query($qcity) or die(mysql_error());

	$qlgu = "INSERT INTO ps_lgu (l_name)
	SELECT * FROM (SELECT '$lgu') AS tmp
	WHERE NOT EXISTS (
    SELECT l_name FROM ps_lgu WHERE l_name = '$lgu'
	) LIMIT 1";
	mysql_query($qlgu) or die(mysql_error());


	$query = "INSERT INTO ps_spes (sp_fname, sp_mname, sp_lname, sp_gender, sp_edu1, sp_edu2, sp_edu3, sp_brgy, sp_city, sp_date_of_birth, sp_age, sp_lgu, sp_remark, sp_first_year, sp_second_year, sp_third_year, sp_batch_first_year, sp_batch_second_year, sp_batch_third_year, sp_first_availment, sp_second_availment, sp_third_availment, sp_grade_first, sp_grade_second, sp_grade_third) VALUES( '$fname', '$mname', '$lname', '$gender', '$educational1', '$educational2', '$educational3', '$brgy', '$city', '$bdate', '$age', '$lgu', '$remark', '$fyear', '$syear', '$tyear', '$fbatch', '$sbatch', '$tbatch', '$favail', '$savail', '$tavail', '$fgrade', '$sgrade', '$tgrade')";

	mysql_query($query);
	$success = '<div class="alert alert-success" role="alert"><b>Successfully</b> added <b> '.$fname.' '.$mname.' '.$lname.' </b> <span class="glyphicon glyphicon-exclamation-sign"></div>';

    $_SESSION['result'] = $success;
		header('location:spes.php');
	}

	else{	

	$qbrgy = "INSERT INTO ps_brgy (b_name)
	SELECT * FROM (SELECT '$brgy') AS tmp
	WHERE NOT EXISTS (
    SELECT b_name FROM ps_brgy WHERE b_name = '$brgy'
	) LIMIT 1";
	mysql_query($qbrgy) or die(mysql_error());

	$qcity = "INSERT INTO ps_city (c_name)
	SELECT * FROM (SELECT '$city') AS tmp
	WHERE NOT EXISTS (
    SELECT c_name FROM ps_city WHERE c_name = '$city'
	) LIMIT 1";
	mysql_query($qcity) or die(mysql_error());

	$qlgu = "INSERT INTO ps_lgu (l_name)
	SELECT * FROM (SELECT '$lgu') AS tmp
	WHERE NOT EXISTS (
    SELECT l_name FROM ps_lgu WHERE l_name = '$lgu'
	) LIMIT 1";
	mysql_query($qlgu) or die(mysql_error());

	$query = "INSERT INTO ps_spes (sp_fname, sp_mname, sp_lname, sp_gender, sp_edu1, sp_edu2, sp_edu3, sp_brgy, sp_city, sp_date_of_birth, sp_age, sp_lgu, sp_remark, sp_first_year, sp_second_year, sp_third_year, sp_batch_first_year, sp_batch_second_year, sp_batch_third_year, sp_first_availment, sp_second_availment, sp_third_availment, sp_grade_first, sp_grade_second, sp_grade_third) VALUES( '$fname', '$mname', '$lname', '$gender', '$educational1', '$educational2', '$educational3', '$brgy', '$city', '$bdate', '$age', '$lgu', '$remark', '$fyear', '$syear', '$tyear', '$fbatch', '$sbatch', '$tbatch', '$favail', '$savail', '$tavail', '$fgrade', '$sgrade', '$tgrade')";

	mysql_query($query);
	$success = '<div class="alert alert-success" role="alert"><b>Successfully</b> added <b> '.$fname.' '.$mname.' '.$lname.' </b> <span class="glyphicon glyphicon-exclamation-sign"></div>';

    $_SESSION['result'] = $success;
		header('location:spes.php');
	}
}
}
}
?>