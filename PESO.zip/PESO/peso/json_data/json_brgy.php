<?
	include("../db_con/connect.php");
	$term = $_GET["term"];
	$query = "SELECT b_name FROM ps_brgy WHERE b_name LIKE '%$term%' ORDER BY b_name LIMIT 5";
	$result = mysql_query($query);
	
	$response = array();
	
	while ($row = mysql_fetch_array($result)){
		
		$data[] = $row['b_name'];
	}

	mysql_close($con);
	
	echo json_encode($data);
	
?>