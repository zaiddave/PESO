<?
	include("../db_con/connect.php");
	$term = $_GET["term"];
	$query = "SELECT DISTINCT vac_vacancy FROM ps_vacancy WHERE vac_vacancy LIKE '%$term%' ORDER BY vac_vacancy LIMIT 5";
	$result = mysql_query($query);
	
	$response = array();
	
	while ($row = mysql_fetch_array($result)){
		
		$data[] = $row['vac_vacancy'];
	}

	mysql_close($con);
	
	echo json_encode($data);
	
?>