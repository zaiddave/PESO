<?
	include("../db_con/connect.php");
	$term = $_GET["term"];
	$query = "SELECT DISTINCT r_type FROM ps_recruitment_type WHERE r_type LIKE '%$term%' ORDER BY r_type ASC LIMIT 5";
	$result = mysql_query($query);
	
	$response = array();
	
	while ($row = mysql_fetch_array($result)){
		
		$data[] = $row['r_type'];
	}

	mysql_close($con);
	
	echo json_encode($data);
	
?>