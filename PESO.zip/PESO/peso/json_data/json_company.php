<?
	include("../db_con/connect.php");
	$term = $_GET["term"];
	$query = "SELECT DISTINCT em_company_name FROM ps_employer_registry WHERE em_company_name LIKE '%$term%' ORDER BY em_company_name ASC LIMIT 5 ";
	$result = mysql_query($query);
	
	$response = array();
	
	while ($row = mysql_fetch_array($result)){
		
		$data[] = $row['em_company_name'];
	}

	mysql_close($con);
	
	echo json_encode($data);
	
?>