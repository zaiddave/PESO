<?
	include("../db_con/connect.php");
	$term = $_GET["term"];
	$query = "SELECT DISTINCT c_course FROM ps_course WHERE c_course LIKE '%$term%' ORDER BY c_course LIMIT 5";
	$result = mysql_query($query);
	
	$response = array();
	
	while ($row = mysql_fetch_array($result)){
		
		$data[] = $row['c_course'];
	}

	mysql_close($con);
	
	echo json_encode($data);
	
?>