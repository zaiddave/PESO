<?
	include("../db_con/connect.php");
	$term = $_GET["term"];
	$query = "SELECT l_name FROM ps_lgu WHERE l_name LIKE '%$term%' ORDER BY l_name LIMIT 5";
	$result = mysql_query($query);
	
	$response = array();
	
	while ($row = mysql_fetch_array($result)){
		
		$data[] = $row['l_name'];
	}

	mysql_close($con);
	
	echo json_encode($data);
	
?>