<?
	include("../db_con/connect.php");
	$term = $_GET["term"];
	$query = "SELECT s_name FROM ps_sponsor WHERE s_name LIKE '%$term%' ORDER BY s_name LIMIT 5";
	$result = mysql_query($query);
	
	$response = array();
	
	while ($row = mysql_fetch_array($result)){
		
		$data[] = $row['s_name'];
	}

	mysql_close($con);
	
	echo json_encode($data);
	
?>