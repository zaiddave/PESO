<?
	include("../db_con/connect.php");
	$term = $_GET["term"];
	$query = "SELECT c_name FROM ps_city WHERE c_name LIKE '%$term%' ORDER BY c_name LIMIT 5";
	$result = mysql_query($query);
	
	$response = array();
	
	while ($row = mysql_fetch_array($result)){
		
		$data[] = $row['c_name'];
	}

	mysql_close($con);
	
	echo json_encode($data);
	
?>