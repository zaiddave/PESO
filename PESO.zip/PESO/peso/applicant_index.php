<?php
session_start();
include('meta-index.php') ?>

<title> PESO </title>

<?php include('head.php');

include('navbar_applicant.php');

include('applicant_container_index.php') ?>

 </body>
 <script type="text/javascript">
$(document).ready(function($){
    $("#auto_course").autocomplete({
        source: "json_data/json_course.php",
        minLength: 1
    });                
    $("#auto_job").autocomplete({
        source: "json_data/json_preferred.php",
        minLength: 1
    });  
});
</script>
 <script src="assets/scrollable_menu.js" type="text/javascript"></script>
 </html>