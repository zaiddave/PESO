<?php
session_start();
include('meta.php') ?>
<title>PESO</title>
<?php include('head.php') ?>

<body class="bg">


<?php include('navbar.php') ?>

<?php include('general_total_container.php') ?> 


<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();   
});
</script>

</body>
</html>