<?php
$_SESSION['$queryYear'] = "sp_first_year";
$a1=	$_SESSION['$queryAvail'] = "sp_first_availment";
$a2=	$_SESSION['$avail'] = "First Availment";
$_SESSION['$queryEdu'] = "sp_edu1";
$_SESSION['$queryBatch'] = "sp_batch_first_year";
if(isset($_POST['submit'])){
	if($_POST['avail'] == "First Availment"){
		$_SESSION['$queryAvail'] = "sp_first_availment";
		$_SESSION['$queryYear'] = "sp_first_year";
		$_SESSION['$queryBatch'] = "sp_batch_first_year";
		$_SESSION['$queryEdu'] = "sp_edu1";
		$_SESSION['$avail'] = $_POST['avail'];		

	}
	elseif ($_POST['avail'] == "Second Availment") {
		$_SESSION['$queryAvail'] = "sp_second_availment";
		$_SESSION['$queryYear'] = "sp_second_year";
		$_SESSION['$queryBatch'] = "sp_batch_second_year";
		$_SESSION['$queryEdu'] = "sp_edu2";
		$_SESSION['$avail'] = $_POST['avail'];
	}
	elseif($_POST['avail'] == "Third Availment"){
		$_SESSION['$queryAvail'] = "sp_third_availment";
		$_SESSION['$queryYear'] = "sp_third_year";
		$_SESSION['$queryBatch'] = "sp_batch_third_year";
		$_SESSION['$queryEdu'] = "sp_edu3";
		$_SESSION['$avail'] = $_POST['avail'];
	}
}

?>
<div class="panel panel-info col-md-12">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <center><h4><b>SPES Generated Report Table</b></h4></center>
                    </h4>
                  </div>
                  <div >
                  <br><br>                  
                  <form class="form-inline" method="post">
					  <div class="form-group">
					    <label class="sr-only" for="year">Filter Search:</label>
					    <div class="input-group">					    					      
					      <select class="form-control" name="avail" id="avail" required>
					      	<option value="" selected="selected">SELECT AVAILMENT</option>
					      	<option value="First Availment">First Availment</option>
					      	<option value="Second Availment">Second Availment</option>
					      	<option value="Third Availment">Third Availment</option>
					      </select>					      					      					      
					    </div>
					  </div>					  
					  <button type="submit" class="btn btn-primary" name="submit">Search</button>
					</form>                  
                  <br><br>
	                    <table id="table" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
							<thead>
								<tr class="head-color">
									<th>Name</th>
									<th>Gender</th>
									<th>Birthdate</th>
									<th>Age</th>
									<th>Address</th>
									<th>LGU</th>
									<th>Educational Level</th>
									<th>Availment</th>
									<th>Year</th>
									<th>Batch</th>
									<th>Remark</th>
								</tr>
							</thead>
							<tbody>
							<?php 																	
									$fetch = mysql_query("SELECT * FROM ps_spes ORDER BY sp_lname ASC") or die(mysql_error());
                					while($row = mysql_fetch_array($fetch)){
                  			?>
								<tr>
									<td class="job-fair"><?php echo $row['sp_lname'] .", ".$row['sp_fname']." ".$row['sp_mname']?></td>
									<td class="job-fair"><?php echo $row['sp_gender'] ?></td>
									<td class="job-fair"><?php echo $row['sp_date_of_birth'] ?></td>
									<td class="job-fair"><?php echo $row['sp_age'] ?></td>
									<td class="job-fair"><?php echo $row['sp_brgy'].', '.$row['sp_city'] ?></td>
									<td class="job-fair"><?php echo $row['sp_lgu'] ?></td>
									<td class="job-fair"><?php echo $row[$_SESSION['$queryEdu']] ?></td>
									<td class="job-fair"><?php echo $row[$_SESSION['$queryAvail']] ?></td>
									<td class="job-fair"><?php echo $row[$_SESSION['$queryYear']] ?></td>
									<td class="job-fair"><?php echo $row[$_SESSION['$queryBatch']] ?></td>
									<td class="job-fair"><?php echo $row['sp_remark']?></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                  </div>
                </div>
  
  