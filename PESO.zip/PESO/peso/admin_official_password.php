<?php
session_start();
require_once("db_con/connect.php");
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}
//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values
	$id = clean($_GET['id']);
	$user = clean($_POST['user']);
	$prev = md5(clean($_POST['prev']));
	$pass = clean($_POST['pass']);
	$confirm = clean($_POST['confirm']);

$query = mysql_query("SELECT * FROM ps_login WHERE l_id = '$id' ");
$fetch = mysql_fetch_array($query);
$uname = $fetch['l_username'];
$cpass = $fetch['l_password'];

if($user == $uname){
	if($prev != $cpass){
		$success = '<div class="alert alert-danger" role="alert"><b>Previous Password</b> does not match <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}
	elseif($pass != $confirm){
		$success = '<div class="alert alert-danger" role="alert"><b>Confirmation Password</b> does not match <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}
	else{
	$query = ("UPDATE ps_login SET l_password = md5('$pass') WHERE l_id = '$id' ");

	mysql_query($query) or die(mysql_error());

	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated. Re-login to view your profile <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}
}
elseif($user != $uname){
	$query1 = mysql_query("SELECT * FROM ps_login WHERE l_username = '$user' ");
	$fetch1 = mysql_num_rows($query1);
	if($fetch1 > 0){
	$success = '<div class="alert alert-danger" role="alert"><b>Username</b> already exist <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}
	elseif($prev != $cpass){
		$success = '<div class="alert alert-danger" role="alert"><b>Previous Password</b> does not match <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}
	elseif($pass != $confirm){
		$success = '<div class="alert alert-danger" role="alert"><b>Confirmation Password</b> does not match <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}
	else{
	$query = ("UPDATE ps_login SET l_username = '$user', l_password = md5('$pass') WHERE l_id = '$id' ");

	mysql_query($query) or die(mysql_error());

	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated. Re-login to view your profile <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

	    $_SESSION['result'] = $success;
		header('location:admin.php');
	}
}

?>

