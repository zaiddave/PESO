<?php
session_start();
require_once('db_con/connect.php');
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}

//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

	/*function checkmydate($petsa) {
 	$tempDate = explode('/', $petsa);
  	return checkdate($tempDate[0], $tempDate[1], $tempDate[2]);
  }*/

//sanitize the POST values

$employer = clean($_POST['employer']);
$vacancy = clean($_POST['vacancy']);
$novacancy = clean($_POST['novacancy']);
$gender = clean($_POST['gender']);
$dateposting = clean($_POST['dateposting']);
$status = strtoupper(clean($_POST['status']));
$date = clean($_POST['date']);

if($employer == "default"){
	$error = '<div class="alert alert-danger" role="alert">Please select the <b>Company Name</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result'] = $error;
		header('location:add_job_vacancy.php');

}
else{
	if(is_numeric($novacancy)){
		$qjob = "INSERT INTO ps_preferred (p_name)
		SELECT * FROM (SELECT '$job') AS tmp
		WHERE NOT EXISTS (
    	SELECT p_name FROM ps_preferred WHERE p_name = '$job'
		) LIMIT 1";
		mysql_query($qjob) or die(mysql_error());

		$query = "INSERT INTO ps_vacancy (em_company_name, vac_vacancy, vac_no_of_vacancy, vac_gender, vac_date_posting, vac_status, vac_date) VALUES  ('$employer', '$vacancy', '$novacancy', '$gender', '$dateposting', '$status', '$date')";

			mysql_query($query) or die(mysql_error());
		
		$success = '<div class="alert alert-success" role="alert">Successfully added <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result'] = $success;
		header('location:add_job_vacancy.php');
	}
	else{
		$error = '<div class="alert alert-danger" role="alert">Enter a <b>valid number</b> <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

      	$_SESSION['result'] = $error;
		header('location:add_job_vacancy.php');		
	}
			
}

?>