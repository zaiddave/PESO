<?php
session_start();
require_once("db_con/connect.php");
if(isset($_SESSION['fname'])=="" ) {
  header("location: login.php");
}

//function to sanitize values received from the form. Prevents SQL injection

	function clean($str){
		$str = @trim($str);
		if(get_magic_quotes_gpc()){
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

//sanitize the POST values
	$id = clean($_POST['id']);
	$type = clean($_POST['type']);
	$company = strtoupper(clean($_POST['company']));
	$business = clean($_POST['business']);
	$mayor = clean($_POST['mayor']);
	$bir = clean($_POST['bir']);
  	$representative = clean($_POST['representative']);
  	$designation = clean($_POST['designation']);
	$telephone = clean($_POST['telephone']);
	$cell = clean($_POST['cell']);
	$email = clean($_POST['email']);

	if($type == "default"){
		$error = '<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign"></span> Select the appropriate <b>Employment Type</b> under the company name <b>'.$company.'</b>.</div>';

      	$_SESSION['result'] = $error;
      	header('location:employer_manage.php');
	}
	else{
	$query = "UPDATE ps_employer_registry SET em_employment_type = '$type', em_company_name = '$company', em_business = '$business', em_mayor = '$mayor', em_bir = '$bir', em_representative = '$representative', em_designation = '$designation', em_telephone = '$telephone', em_cellphone = '$cell', em_email = '$email' WHERE em_id = $id";

	mysql_query($query) or die(mysql_error());

	$success = '<div class="alert alert-info" role="alert"><b>Successfully</b> updated '.$company.' <span class="glyphicon glyphicon-exclamation-sign"></span></div>';

    $_SESSION['result'] = $success;
	header('location:employer_manage.php');
	}

	?>